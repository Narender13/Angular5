import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { FeedbackService } from '../shared/feedback.service';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('FeedbackFormComponent')
export class FeedbackFormComponent implements Configurable, OnInit {
  config: any;
  categories: string[] = ['Design', 'Function', 'Performance', 'General'];
  ratings: number[] = [1, 2, 3, 4, 5];
  feedbackForm: FormGroup;
  localized: any;

  errors = {
    title: null,
    category: null,
    rating: null,
    comments: null
  };
  submitted = false;
  usable: boolean;

  constructor(
    private fb: FormBuilder,
    private service: FeedbackService,
    private location: Location) { }

  ngOnInit() {
    this.feedbackForm = this.fb.group({
      title: ['', [Validators.required, Validators.maxLength(25)]],
      category: ['', Validators.required],
      rating: ['', Validators.required],
      comments: ['', [Validators.required, Validators.maxLength(250)]]
    });
    this.feedbackForm.valueChanges.pipe(
      debounceTime(500)
    ).subscribe(() => this.compileErrors(this.feedbackForm));
    this.localized = this.config.translated;

  }

  compileErrors(form: FormGroup, ignoreDirty?: boolean) {
    for (const field of Object.keys(this.errors)) {
      const control = form.get(field);
      if (ignoreDirty !== null) {
        this.errors[field] = '';
      }
      if (form.contains(field) && (control && control.dirty || ignoreDirty)) {
        if (!control.valid) {
          for (const key of Object.keys(control.errors)) {
            this.errors[field] += this.localized.messages[field][key];
          }
        }
      }
    }
  }

  submit() {
    const form = this.feedbackForm;
    if (!form.valid) {
      return this.compileErrors(form, true);
    }
    this.submitted = true;
    this.service.save(form.value).subscribe();
  }
}
