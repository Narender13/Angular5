import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class FeedbackService {
  private apiUrl = 'feedback/';

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  save(data: any): Observable<boolean> {
    return this.http.authPost(this.apiUrl, data).pipe(
      map(res => this.extractData(res)),
      catchError(this.loggingService.handleError));
  }

  private extractData(res: Response): boolean {
    return res.ok;
  }
}
