import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { FeedbackFormComponent } from './feedback-form/feedback-form.component';
import { FeedbackRoutingModule } from './feedback-routing.module';
import { FeedbackService } from 'app/feedback/shared/feedback.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [FeedbackFormComponent],
  imports: [
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    FeedbackRoutingModule
  ],
  providers: [FeedbackService]
})
export class FeedbackModule { }
