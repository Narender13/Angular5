import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { SendCodeConfirmRoutingModule } from './send-code-confirm-routing.module';
import { SendCodeConfirmComponent } from './send-code-confirm.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [SendCodeConfirmComponent],
  imports: [CommonModule, SharedModule, ReactiveFormsModule, SendCodeConfirmRoutingModule],
  exports: [SendCodeConfirmComponent]
})
export class SendCodeConfirmModule { }