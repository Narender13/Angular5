import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './send-code-confirm.html',
  styleUrls: ['./send-code-confirm.component.scss']

})
export class SendCodeConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() { }
}