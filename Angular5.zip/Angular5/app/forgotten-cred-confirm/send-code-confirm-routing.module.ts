import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SendCodeConfirmComponent } from './send-code-confirm.component';

const routes: Routes = [
    { path: 'sendcodeconfirm', component: SendCodeConfirmComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SendCodeConfirmRoutingModule { }
