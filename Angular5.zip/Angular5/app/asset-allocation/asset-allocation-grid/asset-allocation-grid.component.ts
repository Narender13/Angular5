import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { AssetAllocation } from '../../shared/models/asset-allocation.model';
import { AssetAllocationService } from '../shared/asset-allocation.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-asset-allocation-grid',
  templateUrl: './asset-allocation-grid.component.html',
  styleUrls: ['./asset-allocation-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('AssetAllocationGridComponent')
export class AssetAllocationGridComponent implements Configurable, OnInit {
  config: any;
  assetAllocations: Observable<AssetAllocation[]>;
  count: Observable<number>;
  showAssetSourceColumn: boolean;
  loading = true;
  settings = {
    paginationAtTop: true,
    paginationAtBottom: true,
    pageSize: 10
  };
  sortFields: string[] = [
    'allocationType Asc',
    'allocationType Desc',
    'fundName Asc',
    'fundName Desc'
  ];
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: AssetAllocationService
  ) { }

  ngOnInit() {
    this.assetAllocations = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { contractId: string, orderby: string }) => {
        this.config.orderby = params.orderby || this.config.orderby || this.sortFields[0];
        return this.service.list(params.contractId, null, this.config.orderby);
      }),
      tap(() => this.loading = false)
    );
    this.service.containsAssetSources().subscribe(data => {
      this.showAssetSourceColumn = data;
    });
    this.count = this.service.count().pipe(share());
  }
}
