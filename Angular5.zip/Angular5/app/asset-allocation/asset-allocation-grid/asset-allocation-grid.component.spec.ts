import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationGridComponent } from './asset-allocation-grid.component';

describe('AssetAllocationGridComponent', () => {
  let component: AssetAllocationGridComponent;
  let fixture: ComponentFixture<AssetAllocationGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetAllocationGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetAllocationGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
