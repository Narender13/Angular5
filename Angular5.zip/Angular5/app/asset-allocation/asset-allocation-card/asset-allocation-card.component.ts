import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AssetAllocation } from '../../shared/models/asset-allocation.model';
import { AuthGuardService } from '../../shared/services/auth-guard.service';
import { AssetAllocationService } from '../shared/asset-allocation.service';

@Component({
  selector: 'app-asset-allocation-card',
  templateUrl: './asset-allocation-card.component.html',
  styleUrls: ['./asset-allocation-card.component.scss']
})
@AutoUnsubscribe()
@Configure('AssetAllocationCardComponent')
export class AssetAllocationCardComponent implements Configurable, OnInit {
  assetAllocations: Observable<AssetAllocation[]>;
  config: any;
  count: Observable<number>;
  limit = 5;
  usable: any;

  constructor(
    private route: ActivatedRoute,
    private service: AssetAllocationService,
    private guardService: AuthGuardService) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;
    this.limit = this.config.cardLimit || this.limit;
    this.config.orderby = this.config.orderby || '';
    this.assetAllocations = this.service.list(contractId, this.limit, this.config.orderby).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
