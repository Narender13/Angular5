import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationCardComponent } from './asset-allocation-card.component';

describe('AssetAllocationCardComponent', () => {
  let component: AssetAllocationCardComponent;
  let fixture: ComponentFixture<AssetAllocationCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetAllocationCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetAllocationCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
