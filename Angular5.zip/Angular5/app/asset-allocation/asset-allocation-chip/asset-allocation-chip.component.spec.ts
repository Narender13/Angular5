import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetAllocationChipComponent } from './asset-allocation-chip.component';

describe('AssetAllocationChipComponent', () => {
  let component: AssetAllocationChipComponent;
  let fixture: ComponentFixture<AssetAllocationChipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetAllocationChipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetAllocationChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
