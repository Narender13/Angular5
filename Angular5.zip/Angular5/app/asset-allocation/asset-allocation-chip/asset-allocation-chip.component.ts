import { Component, Input } from '@angular/core';
import { AssetAllocation } from '../../shared/models/asset-allocation.model';

@Component({
  selector: 'app-asset-allocation-chip',
  templateUrl: './asset-allocation-chip.component.html',
  styles: [':host{width:100%;}']
})
export class AssetAllocationChipComponent {
  @Input() assetAllocation: AssetAllocation;

  constructor() { }
}
