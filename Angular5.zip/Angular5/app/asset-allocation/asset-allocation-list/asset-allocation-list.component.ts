import { Component, OnInit, Input } from '@angular/core';
import { AssetAllocation } from '../../shared/models/asset-allocation.model';

@Component({
  selector: 'app-asset-allocation-list',
  templateUrl: './asset-allocation-list.component.html',
  styleUrls: ['./asset-allocation-list.component.scss']
})
export class AssetAllocationListComponent implements OnInit {
  @Input() assetAllocations: AssetAllocation[];
  componentName = 'assetAllocations';
  constructor() { }

  ngOnInit() {
  }

}
