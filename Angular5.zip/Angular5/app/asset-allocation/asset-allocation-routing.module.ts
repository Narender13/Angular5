import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssetAllocationGridComponent } from './asset-allocation-grid/asset-allocation-grid.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const routes: Routes = [
  {
    path: 'contracts/:contractId/asset-allocations',
    component: AssetAllocationGridComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AssetAllocationRoutingModule { }
