import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { AssetAllocationCardComponent } from './asset-allocation-card/asset-allocation-card.component';
import { AssetAllocationChipComponent } from './asset-allocation-chip/asset-allocation-chip.component';
import { AssetAllocationGridComponent } from './asset-allocation-grid/asset-allocation-grid.component';
import { AssetAllocationListComponent } from './asset-allocation-list/asset-allocation-list.component';
import { AssetAllocationRoutingModule } from './asset-allocation-routing.module';
import { SharedModule } from '../shared/shared.module';
import { AssetAllocationService } from './shared/asset-allocation.service';

@NgModule({
  declarations: [
    AssetAllocationCardComponent,
    AssetAllocationChipComponent,
    AssetAllocationGridComponent,
    AssetAllocationListComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AssetAllocationRoutingModule
  ],
  exports: [
    AssetAllocationCardComponent,
    AssetAllocationChipComponent
  ],
  providers: [AssetAllocationService]
})
export class AssetAllocationModule { }
