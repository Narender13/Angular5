import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { UWHttp } from '../../UWHttp';
import { LoggingService } from '../../shared/logging/logging.service';
import { AssetAllocation } from '../../shared/models/asset-allocation.model';

@Injectable()
export class AssetAllocationService {
  private apiUrl = 'AssetAllocations/';
  private containsAssetSources$ = new Subject<boolean>();
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  containsAssetSources(): Observable<boolean> {
    return this.containsAssetSources$.asObservable();
  }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, limit: number, orderby: string): Observable<AssetAllocation[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('contractId', search);
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      map(data => this.sort(data, orderby)),
      map(data => data.slice(0, limit || data.length)),
      catchError(this.loggingService.handleError)
    );
  }

  sort(assetAllocations: AssetAllocation[], orderby: string): AssetAllocation[] {
    const orderbyFragments = orderby.toLowerCase().split(' ');
    const f = orderbyFragments[0];
    const dir = orderbyFragments[1];

    switch (f) {
      case 'allocationtype':
        assetAllocations = assetAllocations.sort((a: AssetAllocation, b: AssetAllocation): number => {
          if (a.allocationType < b.allocationType) { return -1; }
          if (a.allocationType > b.allocationType) { return 1; }
          return 0;
        });
        break;
      default:
        assetAllocations = assetAllocations.sort((a: AssetAllocation, b: AssetAllocation): number => {
          if (a.fundName < b.fundName) { return -1; }
          if (a.fundName > b.fundName) { return 1; }
          return 0;
        });
        break;
    }

    if (dir === 'desc') {
      assetAllocations = assetAllocations.reverse();
    }
    return assetAllocations;
  }
  private extractData(res: Response) {
    const data = res.json() as AssetAllocation[];
    this.lastCount.next(data.length);
    this.containsAssetSources$.next(data.some(a => a.assetSource && a.assetSource.toLowerCase() !== 'nana'));
    return data || [];
  }
}
