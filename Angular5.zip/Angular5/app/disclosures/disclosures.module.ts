import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DisclosuresRoutingModule } from './disclosures-routing.module';
import { DisclosuresComponent } from './disclosures.component';


@NgModule({
  imports: [
    CommonModule,
    DisclosuresRoutingModule
  ],
  declarations: [DisclosuresComponent],
    exports: [DisclosuresComponent]
})
export class DisclosuresModule { }
