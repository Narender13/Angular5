import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisclosuresComponent } from './disclosures.component';

const routes: Routes = [
  { path: 'disclosures', component: DisclosuresComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DisclosuresRoutingModule { }
