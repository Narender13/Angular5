import { Component, OnInit } from '@angular/core';
import { LoggingService } from '../shared/logging/logging.service';
import { Configure, Configurable } from '../shared/decorators/configurable';


@Component({
  selector: 'app-disclosures',
  templateUrl: './disclosures.component.html',
  styleUrls: ['./disclosures.component.scss']
})
@Configure('DisclosuresComponent')
export class DisclosuresComponent implements Configurable, OnInit {
  config: any;
  disclosuresHtml = 'no disclosures information found';
  usable: boolean;

  constructor(
    private loggingService: LoggingService
  ) { }

  ngOnInit() {
    this.disclosuresHtml = this.config.text;
  }
}
