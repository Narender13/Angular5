import { Component, Input } from '@angular/core';

import { EDelivery } from 'app/shared/models/e-delivery.model';
import { EDeliveryStatus } from '../../shared/models/e-delivery.model';

@Component({
  selector: 'app-e-delivery-chip',
  templateUrl: './e-delivery-chip.component.html',
  styles: [':host { width: 100%}']
})
export class EDeliveryChipComponent {
  @Input() eDelivery: EDelivery;
  STATUS: typeof EDeliveryStatus = EDeliveryStatus;

  constructor() { }
}
