import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';


import { EDelivery } from '../../shared/models/e-delivery.model';
import { EDeliveryService } from '../shared/e-delivery.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-e-delivery-form',
  templateUrl: './e-delivery-form.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('EDeliveryFormComponent')
export class EDeliveryFormComponent implements Configurable, OnInit {
  config: any;
  eDelivery: Observable<EDelivery>;
  providerUrl: Observable<string>;
  localized: any;
  usable: boolean;

  constructor(
    private service: EDeliveryService
  ) { }

  get hasProvider(): boolean {
    return this.service.hasProvider;
  }

  ngOnInit() {
    this.eDelivery = this.service.get().pipe(share());
    this.localized = this.config.translated;
    if (this.hasProvider) {
      this.providerUrl = this.eDelivery.switchMap(data => this.service.getProviderUrl(data.todo));
    }

  }
}
