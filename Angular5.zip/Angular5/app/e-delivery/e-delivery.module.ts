import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { EDeliveryActionComponent } from './e-delivery-action/e-delivery-action.component';
import { EDeliveryCardComponent } from 'app/e-delivery/e-delivery-card/e-delivery-card.component';
import { EDeliveryChipComponent } from 'app/e-delivery/e-delivery-chip/e-delivery-chip.component';
import { EDeliveryFormComponent } from './e-delivery-form/e-delivery-form.component';
import { EDeliveryRoutingModule } from './e-delivery-routing.module';
import { EDeliveryService } from './shared/e-delivery.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    EDeliveryActionComponent,
    EDeliveryCardComponent,
    EDeliveryChipComponent,
    EDeliveryFormComponent
  ],
  imports: [
    CommonModule,
    EDeliveryRoutingModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [
    EDeliveryCardComponent
  ],
  providers: [EDeliveryService]
})
export class EDeliveryModule { }
