import { Injectable } from '@angular/core';
import { Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';

import { ConfigService } from '../../shared/services/config.service';
import { EDelivery, EDeliveryAction, EDeliverySettings, EDeliveryStatus } from '../../shared/models/e-delivery.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class EDeliveryService {
  private apiUrl = 'edelivery/';
  private globalsKey = 'eDelivery';
  private settings: EDeliverySettings;

  constructor(
    private http: UWHttp,
    private configService: ConfigService
  ) {
    this.settings = this.configService.globals.get(this.globalsKey) as EDeliverySettings;
  }

  get hasProvider(): boolean {
    return Boolean(this.settings.provider);
  }

  get(): Observable<EDelivery> {
    return this.http.authGet(this.apiUrl).pipe(
      map(res => this.extractData(res))
    );
  }

  getProviderUrl(action: EDeliveryAction): Observable<string> {
    const headers = new Headers({ 'Accept': this.settings.mediaType });
    const options = new RequestOptions({ 'headers': headers });

    return this.http.authGet(this.apiUrl, options).pipe(
      map(res => {
        const data = res.text();
        switch (action) {
          case EDeliveryAction.Consent: return this.settings.consentUrl + data;
          case EDeliveryAction.Disenroll: return this.settings.disenrollUrl + data;
          case EDeliveryAction.Enroll: return this.settings.enrollUrl + data;
          case EDeliveryAction.SetEmail: return this.settings.emailUrl + data;
          case EDeliveryAction.Options: return this.settings.optionsUrl + data;
          default: return this.settings.optionsUrl + data;
        }
      })
    );
  }

  infer(value: EDelivery): EDeliveryAction {
    switch (value.status) {
      case EDeliveryStatus.Consented: return EDeliveryAction.Options;
      case EDeliveryStatus.Enrolled: return EDeliveryAction.Consent;
      case EDeliveryStatus.NotEnrolled: return EDeliveryAction.Enroll;
      default: return EDeliveryAction.Options;
    }
  }

  private extractData(res: Response): EDelivery {
    const body = res.json() as EDelivery;
    if (body) {
      body.todo = this.infer(body);
    }
    return body;
  }
}
