import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { EDelivery } from '../../shared/models/e-delivery.model';
import { EDeliveryService } from '../shared/e-delivery.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-e-delivery-card',
  templateUrl: './e-delivery-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('EDeliveryCardComponent')
export class EDeliveryCardComponent implements Configurable, OnInit {
  config: any;
  eDelivery: Observable<EDelivery>;
  usable: any;

  constructor(
    private service: EDeliveryService
  ) { }

  ngOnInit() {
    this.eDelivery = this.service.get().pipe(share());
  }
}
