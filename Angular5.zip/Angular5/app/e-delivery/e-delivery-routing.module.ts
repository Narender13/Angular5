import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { EDeliveryFormComponent } from './e-delivery-form/e-delivery-form.component';

const routes: Routes = [
  { path: 'e-delivery-form', component: EDeliveryFormComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EDeliveryRoutingModule { }
