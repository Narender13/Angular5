import { Component, Input, OnInit } from '@angular/core';
import { EDeliveryAction } from '../../shared/models/e-delivery.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-e-delivery-action',
  templateUrl: './e-delivery-action.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('EDeliveryActionComponent')
export class EDeliveryActionComponent implements Configurable, OnInit {
  @Input() action: EDeliveryAction;
  config: any;
  localized: any;
  ACTION: typeof EDeliveryAction = EDeliveryAction;
  usable: boolean;

  constructor() {
  }

  ngOnInit() {
    this.localized = this.config.translated;
  }
}
