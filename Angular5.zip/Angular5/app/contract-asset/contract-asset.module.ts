import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContractAssetCardComponent } from './contract-asset-card/contract-asset-card.component';
import { ContractAssetChipComponent } from './contract-asset-chip/contract-asset-chip.component';
import { ContractAssetGridComponent } from './contract-asset-grid/contract-asset-grid.component';
import { ContractAssetListComponent } from './contract-asset-list/contract-asset-list.component';
import { ContractAssetRoutingModule } from './contract-asset-routing.module';
import { ContractAssetService } from './shared/contract-asset.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ContractAssetRoutingModule
  ],
  declarations: [
    ContractAssetChipComponent,
    ContractAssetCardComponent,
    ContractAssetListComponent,
    ContractAssetGridComponent
  ],
  exports: [
    ContractAssetChipComponent,
    ContractAssetCardComponent
  ],
  providers: [ContractAssetService]
})
export class ContractAssetModule { }
