import { Injectable } from '@angular/core';
import { Response, ResponseContentType, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { map } from 'rxjs/operators';

import { ContractAsset } from '../../shared/models/contract-asset.model';
import { Paginated } from '../../shared/models/paginated.interface';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ContractAssetService {
  private apiUrl = 'ContractAssets/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search?: string, limit?: number, offset?: number, orderby?: string): Observable<ContractAsset[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('searchvalue', search);
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this)
    );
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.apiUrl}export?format=csv`, 'contract-asset.csv', options);
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<ContractAsset>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }
}
