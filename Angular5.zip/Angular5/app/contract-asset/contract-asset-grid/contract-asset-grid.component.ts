import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { ContractAsset } from '../../shared/models/contract-asset.model';
import { ContractAssetService } from '../shared/contract-asset.service';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { ToolbarActionable, ToolbarActionHandlers } from '../../shared/services/toolbar-action-handler';
import { PageParams } from '../../shared/models/paginated.interface';

@Component({
  selector: 'app-contract-asset-grid',
  templateUrl: './contract-asset-grid.component.html',
  styles: []
})
@Configure('ContractAssetGridComponent')
export class ContractAssetGridComponent implements Configurable, OnInit, ToolbarActionable {
  activeTool: string;
  config: any;
  count: Observable<number>;
  list: Observable<ContractAsset[]>;
  loading = true;
  sortFields: string[] = [
    'contractNumber Asc',
    'contractNumber Desc',
    'personName Asc',
    'personName Desc',
    'cashValue Asc',
    'cashValue Desc'];
  tools = ['print', 'export'];

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: ContractAssetService) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.list = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap(params => this.load(params as PageParams)),
      tap(() => this.loading = false)
    );
    ToolbarActionHandlers.handle(this);
  }

  load(query: PageParams) {
    const { q, limit = this.config.limit, offset = 0, orderby = this.config.orderby } = query;
    this.config.limit = limit;
    this.config.offset = offset;
    this.config.orderby = orderby;
    return this.service.list(q, limit, offset, orderby);
  }

  onExport(): Observable<any> {
    return this.service.export();
  }
}
