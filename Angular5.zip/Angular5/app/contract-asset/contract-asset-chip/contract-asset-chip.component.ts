import { Component, Input } from '@angular/core';
import { ContractAsset } from '../../shared/models/contract-asset.model';

@Component({
  selector: 'app-contract-asset-chip',
  templateUrl: './contract-asset-chip.component.html',
  styles: [':host{width:100%;}']
})
export class ContractAssetChipComponent {
  @Input() data: ContractAsset;

  constructor() { }
}
