import { Component, Input } from '@angular/core';

import { ContractAsset } from '../../shared/models/contract-asset.model';

@Component({
  selector: 'app-contract-asset-list',
  templateUrl: './contract-asset-list.component.html',
  styles: []
})
export class ContractAssetListComponent {
  @Input() list: ContractAsset[];

  constructor() { }
}
