import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { ContractAssetGridComponent } from './contract-asset-grid/contract-asset-grid.component';

const routes: Routes = [{
  path: 'contract-assets/action/:action',
  component: ContractAssetGridComponent,
  canActivate: [AuthGuardService]
}, {
  path: 'contract-assets',
  component: ContractAssetGridComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractAssetRoutingModule { }
