import { ActivatedRoute } from '@angular/router/';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AuthGuardService } from 'app/shared/services/auth-guard.service';
import { AutoUnsubscribe } from 'app/shared/decorators/autounsubscribe';
import { CashValueService } from 'app/cash-value/shared/cash-value.service';
import { Configurable, Configure } from 'app/shared/decorators/configurable';
import { ContractService } from 'app/contract/shared/contract.service';
import { ContractValue } from 'app/shared/models/contractValue.model';

@Component({
  selector: 'app-cash-value-card',
  templateUrl: './cash-value-card.html',
  styleUrls: ['./cash-value-card.component.scss']
})
@AutoUnsubscribe()
@Configure('CashValueCardComponent')
export class CashValueCardComponent implements Configurable, OnInit {
  cashValues: Observable<ContractValue[]>;
  config: any;
  count: Observable<number>;
  currentProduct: any;
  limit = 5;
  usable: any;

  constructor(
    private route: ActivatedRoute,
    private service: CashValueService,
    private guardService: AuthGuardService,
    private contractService: ContractService
  ) { }

  ngOnInit() {
    this.usable = this.guardService.canUse(this.config);
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;
    this.limit = this.config.cardLimit || this.limit;
    this.count = this.service.count().pipe(share());
    this.cashValues = this.service.list(contractId, this.limit).pipe(share());
  }
}
