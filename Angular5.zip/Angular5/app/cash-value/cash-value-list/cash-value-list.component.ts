import { Component, Input } from '@angular/core';

import { ContractValue } from 'app/shared/models/contractValue.model';

@Component({
    selector: 'app-cash-value-list',
    templateUrl: './cash-value-list.html',
    styleUrls: ['./cash-value-list.component.scss']
})

export class CashValueListComponent {
    @Input() cashValues: ContractValue[];

    constructor() { }

}