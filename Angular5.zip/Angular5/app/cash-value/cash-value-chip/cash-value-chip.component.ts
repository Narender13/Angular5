import { OnInit, Component, Input } from '@angular/core';

import { ContractValue } from 'app/shared/models/contractValue.model';

@Component({
    selector: 'app-cash-value-chip',
    templateUrl: './cash-value-chip.html',
    styles: [':host{width:100%;}']
  })

export class CashValueChipComponent implements OnInit {
    @Input() cashValue: ContractValue;
    ngOnInit() {
    }
}