import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { CashValueGridComponent } from './cash-value-grid/cash-value-grid.component';

const routes: Routes = [{
  path: 'contracts/:contractId/cash-values',
  component: CashValueGridComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CashValueRoutingModule { }
