import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router/';
import { Observable } from 'rxjs/Observable';
import { share, tap, map } from 'rxjs/operators';

import { ContractService } from 'app/contract/shared/contract.service';
import { ContractValue } from 'app/shared/models/contractValue.model';
import { CashValueService } from '../shared/cash-value.service';

@Component({
  selector: 'app-cash-value-grid',
  templateUrl: './cash-value-grid.component.html',
  styles: []
})
export class CashValueGridComponent implements OnInit {
  count: Observable<number>;
  loading = true;
  cashValues: Observable<ContractValue[]>;
  currentProduct: any;

  constructor(
    private route: ActivatedRoute,
    private service: CashValueService,
    private contractService: ContractService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;
    this.count = this.service.count().pipe(share());

    this.cashValues = this.service.list(contractId).pipe(
      tap(() => this.loading = true),
      map(list => list),
      tap(() => this.loading = false),
      share()
    );
  }
}
