import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { CashValueService } from './shared/cash-value.service';
import { CashValueCardComponent } from 'app/cash-value/cash-value-card/cash-value-card.component';
import { CashValueChipComponent } from 'app/cash-value/cash-value-chip/cash-value-chip.component';
import { CashValueListComponent } from 'app/cash-value/cash-value-list/cash-value-list.component';
import { CashValueGridComponent } from './cash-value-grid/cash-value-grid.component';
import { CashValueRoutingModule } from './cash-value-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    CashValueCardComponent,
    CashValueListComponent,
    CashValueChipComponent,
    CashValueGridComponent
  ],
  imports: [
    CashValueRoutingModule,
    CommonModule,
    SharedModule
  ],
  exports: [CashValueCardComponent],
  providers: [CashValueService]
})
export class CashValueModule { }
