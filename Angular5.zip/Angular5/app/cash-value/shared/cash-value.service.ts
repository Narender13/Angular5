import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { ContractService } from 'app/contract/shared/contract.service';
import { ContractValue } from 'app/shared/models/contractValue.model';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { map, tap } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class CashValueService {
  private apiUrl = 'cashvalues/';
  private count$ = new Subject<number>();

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService,
    private contractService: ContractService
  ) { }

  count(): Observable<number> {
    return this.count$.asObservable();
  }

  list(contractId: string, limit?: number): Observable<ContractValue[]> {
    const params = new URLSearchParams();
    params.set('id', contractId);
    const contract$ = this.contractService.find(contractId);
    const values$ = this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => res.json() as ContractValue[]),
    );
    return forkJoin(contract$, values$).pipe(
      map(data => {
        const contract = data[0];
        return data[1].filter(v => {
          if (!v.description) { return false; }
          const desc = v.description.toLowerCase();
          if (desc === 'glwb' && contract.productId !== '733') { return false; }
          if ((desc === 'guaranteedminimumdeathbenefit' || desc === 'deathbenefitamount')
            && ['540', '574'].includes(contract.productId)) { return false; }
          return true;
        });
      }),
      tap(values => this.count$.next(values.length)),
      map(values => values.slice(0, limit || values.length))
    );
  }

}
