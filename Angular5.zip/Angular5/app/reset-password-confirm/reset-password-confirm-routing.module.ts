import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ResetPasswordConfirmComponent } from './reset-password-confirm.component';

const routes: Routes = [
    { path: 'resetpasswordconfirm', component: ResetPasswordConfirmComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ResetPasswordConfirmRoutingModule { }
