import { NgModule } from '@angular/core';
import { ResetPasswordConfirmRoutingModule } from './reset-password-confirm-routing.module';
import { ResetPasswordConfirmComponent } from './reset-password-confirm.component';

@NgModule({
  declarations: [ResetPasswordConfirmComponent],
  imports: [ResetPasswordConfirmRoutingModule],
  exports: [ResetPasswordConfirmComponent]
})
export class ResetPasswordConfirmModule { }