import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: './reset-password-confirm.html',
  styleUrls: ['./reset-password-confirm.component.scss']

})
export class ResetPasswordConfirmComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() { }
}