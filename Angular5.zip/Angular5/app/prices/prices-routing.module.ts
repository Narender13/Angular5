import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PricesDetailComponent } from './prices-detail/prices-detail.component';
import { PricesProductsCardComponent } from './prices-products-card/prices-products-card.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';
import { PricesFormsGridComponent } from './prices-forms-grid/prices-forms-grid.component';

const pricesAndPerformanceRoutes: Routes = [
  {
    path: 'products', component: PricesProductsCardComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'products/:id/prices', component: PricesProductsCardComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'products/:id/prices', component: PricesFormsGridComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'products/:id/prices/:fundId', component: PricesDetailComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(pricesAndPerformanceRoutes)],
  exports: [RouterModule]
})
export class PricesRoutingModule { }
