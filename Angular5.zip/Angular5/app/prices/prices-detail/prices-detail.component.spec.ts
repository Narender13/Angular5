import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesAndPerformanceDetailComponent } from './prices-detail.component';

describe('PricesAndPerformanceDetailComponent', () => {
  let component: PricesAndPerformanceDetailComponent;
  let fixture: ComponentFixture<PricesAndPerformanceDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesAndPerformanceDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesAndPerformanceDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
