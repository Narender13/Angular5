import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { Price } from '../../shared/models/price.model';
import { PricesService } from '../shared/prices.service';

@Component({
  selector: 'app-prices-detail',
  templateUrl: './prices-detail.component.html',
  styleUrls: ['./prices-detail.component.scss']
})
export class PricesDetailComponent implements OnInit {
  prices: Observable<Price[]>;
  chartData: Array<{ data: number[], label: string }>;
  chartLabels: Date[];
  hPrices: Price[];
  chartOptions: any = {
    legend: {
      display: false
    },
    scales: {
      xAxes: [{
        type: 'time'
      }]
    },
    ticks: {
      source: 'labels'
    },
    elements: {
      point: {
        radius: 0
      }
    }
  };
  chartColors: Array<any> = [
    {
      backgroundColor: 'rgba(197,220,247,.3)',
      borderColor: '#2f82e3'
    }
  ];
  count: number;
  mode = false;
  startDate: Date;
  endDate: Date;
  startPrice: number;
  endPrice: number;
  percentChange: number;
  lowDate: Date;
  highDate: Date;
  lowPrice = 999999.99;
  highPrice: number = -999999.99;
  rangePercentChange: number;
  fundName: string;

  constructor(private route: ActivatedRoute, private service: PricesService) { }

  ngOnInit() {
    this.prices = this.route.params
      .switchMap((params: { id: string, fundId: string }) => {
        return this.service.pricehistory(params.id, params.fundId)
          .map(p => {
            if (p && p.length) {
              this.chartData = [{ data: p.map(v => v.unitValue), label: 'Price' }];
              this.chartLabels = p.map(v => new Date(v.accountingDate));
              this.fundName = p[0].fundName;
              this.count = p.length;
              if (p[0].accountingDate < p[p.length - 1].accountingDate) {
                this.startDate = p[0].accountingDate;
                this.endDate = p[p.length - 1].accountingDate;
                this.startPrice = p[0].unitValue;
                this.endPrice = p[p.length - 1].unitValue;
              } else {
                this.endDate = p[0].accountingDate;
                this.startDate = p[p.length - 1].accountingDate;
                this.endPrice = p[0].unitValue;
                this.startPrice = p[p.length - 1].unitValue;
              }
              this.percentChange = ((this.endPrice - this.startPrice) / this.startPrice);
              p.forEach(element => {
                if (element.unitValue < this.lowPrice) {
                  this.lowPrice = element.unitValue;
                  this.lowDate = element.accountingDate;
                }
                if (element.unitValue > this.highPrice) {
                  this.highPrice = element.unitValue;
                  this.highDate = element.accountingDate;
                }

              });
              this.rangePercentChange = ((this.highPrice - this.lowPrice) / this.highPrice);
            }
            this.hPrices = p;
            return p;
          });
      })
      .pipe(share());
  }

  togglePrices() {
    this.mode = !this.mode;
  }

}
