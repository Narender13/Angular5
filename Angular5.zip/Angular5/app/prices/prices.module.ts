import { ChartsModule } from 'ng2-charts';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { PricesCardComponent } from './prices-card/prices-card.component';
import { PricesChipComponent } from './prices-chip/prices-chip.component';
import { PricesDetailComponent } from './prices-detail/prices-detail.component';
import { PricesListComponent } from './prices-list/prices-list.component';
import { PricesRoutingModule } from './prices-routing.module';
import { PricesService } from './shared/prices.service';
import { PricesGridComponent } from './prices-grid/prices-grid.component';
import { PricesProductsListComponent } from './prices-products-list/prices-products-list.component';
import { PricesProductsChipComponent } from './prices-products-chip/prices-products-chip.component';
import { PricesProductsCardComponent } from './prices-products-card/prices-products-card.component';
import { PricesFormsGridComponent } from './prices-forms-grid/prices-forms-grid.component';

@NgModule({
  declarations: [
    PricesCardComponent,
    PricesChipComponent,
    PricesDetailComponent,
    PricesListComponent,
    PricesGridComponent,
    PricesProductsListComponent,
    PricesProductsChipComponent,
    PricesProductsCardComponent,
    PricesFormsGridComponent
  ],
  imports: [
    ChartsModule,
    CommonModule,
    SharedModule,
    PricesRoutingModule
  ],
  exports: [PricesCardComponent],
  providers: [PricesService]
})
export class PricesModule { }
