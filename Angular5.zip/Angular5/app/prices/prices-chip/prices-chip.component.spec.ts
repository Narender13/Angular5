import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesAndPerformanceChipComponent } from './prices-chip.component';

describe('PricesAndPerformanceChipComponent', () => {
  let component: PricesAndPerformanceChipComponent;
  let fixture: ComponentFixture<PricesAndPerformanceChipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesAndPerformanceChipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesAndPerformanceChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
