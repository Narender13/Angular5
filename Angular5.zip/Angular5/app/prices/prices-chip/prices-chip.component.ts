import { Component, OnInit, Input } from '@angular/core';
import { Price } from '../../shared/models/price.model';

@Component({
  selector: 'app-prices-chip',
  templateUrl: './prices-chip.component.html',
  styles: [':host{width:100%;}']
})
export class PricesChipComponent implements OnInit {
  @Input() price: Price;

  constructor() { }

  ngOnInit() {
  }

}
