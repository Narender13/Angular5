import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';


import { PricesService } from '../shared/prices.service';
import { Price } from '../../shared/models/price.model';
import { Product } from '../../shared/models/product.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-prices-grid',
  templateUrl: './prices-grid.component.html',
  styleUrls: ['./prices-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('PricesGridComponent')
export class PricesGridComponent implements Configurable, OnInit {
  config: any;
  products: Observable<Product[]>;
  prices: Observable<Price[]>;
  accountingDate: Date;
  productName: string;
  count: Observable<number>;
  settings = {
    paginationAtTop: true,
    paginationAtBottom: true,
    pageSize: 10
  };
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: PricesService
  ) { }

  ngOnInit() {
    this.products = this.service.products().pipe(share());
    this.prices = this.route.params
      .switchMap((params: { id: string, limit: number, offset: number }) => {
        const limit = params.limit || this.settings.pageSize;
        return this.service.list(params.id, null, limit, params.offset)
          .map(prices => {
            if (prices && prices.length) {
              this.productName = prices[0].productName;
              this.accountingDate = prices[0].accountingDate;
            }
            return prices;
          });
      })
      .pipe(share());

    this.count = this.service.count().pipe(share());
  }
}
