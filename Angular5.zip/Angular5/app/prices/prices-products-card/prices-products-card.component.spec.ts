import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesProductsCardComponent } from './prices-products-card.component';

describe('PricesProductsCardComponent', () => {
  let component: PricesProductsCardComponent;
  let fixture: ComponentFixture<PricesProductsCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesProductsCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesProductsCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
