import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';


import { PricesService } from '../shared/prices.service';
import { Product } from '../../shared/models/product.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-prices-products-card',
  templateUrl: './prices-products-card.component.html',
  styleUrls: ['./prices-products-card.component.scss']
})
@AutoUnsubscribe()
@Configure('PricesProductsCardComponent')
export class PricesProductsCardComponent implements Configurable, OnInit {
  config: any;
  selected: Observable<string>;
  products: Observable<Product[]>;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: PricesService
  ) { }

  ngOnInit() {
    this.selected = this.route.params
      .map((params: { id: string }) => params.id)
      .pipe(share());
    this.products = this.service.products().pipe(share());
  }
}
