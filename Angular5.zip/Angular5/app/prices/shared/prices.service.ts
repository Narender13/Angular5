import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { Paginated } from '../../shared/models/paginated.interface';
import { Price } from '../../shared/models/price.model';
import { Product } from '../../shared/models/product.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class PricesService {
  private apiUrl = 'fundprices/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  products(): Observable<Product[]> {
    return this.http.authGet('products/').pipe(
      map(this.extractProductsData, this),
      catchError(this.loggingService.handleError));
  }

  list(productCode: string, search: string, limit: number, offset: number): Observable<Price[]> {
    const params = new URLSearchParams();

    params.set('productid', productCode);

    if (search) {
      params.set('fundname', search);
    }

    // todo: include ui pagination, until then get everything
    // if (offset) {
    offset = 0;
    params.set('skip', offset.toString());
    // }

    // if (limit) {
    limit = 32768;
    params.set('take', limit.toString());
    // }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError));
  }

  pricehistory(productId: string, fundId: string): Observable<Price[]> {
    const params = new URLSearchParams();

    params.set('productid', productId);

    return this.http.authGet(this.apiUrl + fundId + '/detail', { search: params }).pipe(
      map(res => this.extractHistory(res)),
      map(prices => this.extractHistoricalStats(prices)),
      catchError(this.loggingService.handleError));
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<Price>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }

  private extractHistory(res: Response) {
    const data = res.json() as Price[];
    return data;
  }

  private extractProductsData(res: Response) {
    const body = res.json() as Paginated<Product>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }

  private extractHistoricalStats(data: Price[]) {
    // todo: aggregate stats and expose as subject
    return data;
  }
}
