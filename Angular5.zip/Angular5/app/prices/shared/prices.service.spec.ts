import { TestBed, inject } from '@angular/core/testing';

import { PricesAndPerformanceService } from './prices.service';

describe('PricesAndPerformanceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PricesAndPerformanceService]
    });
  });

  it('should be created', inject([PricesAndPerformanceService], (service: PricesAndPerformanceService) => {
    expect(service).toBeTruthy();
  }));
});
