import { Component, Input } from '@angular/core';

import { Price } from '../../shared/models/price.model';
import { Product } from '../../shared/models/product.model';

@Component({
  selector: 'app-prices-list',
  templateUrl: './prices-list.component.html',
  styleUrls: ['./prices-list.component.scss']
})
export class PricesListComponent {
  @Input() currentProduct: Product;
  @Input() prices: Price[];

  constructor() { }
}
