import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesAndPerformanceListComponent } from './prices-list.component';

describe('PricesAndPerformanceListComponent', () => {
  let component: PricesAndPerformanceListComponent;
  let fixture: ComponentFixture<PricesAndPerformanceListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesAndPerformanceListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesAndPerformanceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
