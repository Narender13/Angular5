import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../../shared/models/product.model';

@Component({
  selector: 'app-prices-products-chip',
  templateUrl: './prices-products-chip.component.html',
  styles: [':host{width:100%;}']
})
export class PricesProductsChipComponent implements OnInit {
  @Input() product: Product;
  constructor() { }

  ngOnInit() {
  }

}
