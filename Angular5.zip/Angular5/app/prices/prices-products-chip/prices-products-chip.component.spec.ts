import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesProductsChipComponent } from './prices-products-chip.component';

describe('PricesProductsChipComponent', () => {
  let component: PricesProductsChipComponent;
  let fixture: ComponentFixture<PricesProductsChipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesProductsChipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesProductsChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
