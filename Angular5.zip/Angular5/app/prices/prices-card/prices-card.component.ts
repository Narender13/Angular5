import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { Price } from '../../shared/models/price.model';
import { PricesService } from '../shared/prices.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-prices-card',
  templateUrl: './prices-card.component.html',
  styleUrls: ['./prices-card.component.scss']
})
@AutoUnsubscribe()
@Configure('PricesCardComponent')
export class PricesCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  prices: Observable<Price[]>;
  limit = 5;
  usable: boolean;

  constructor(
    private service: PricesService
  ) { }

  ngOnInit() { }
}
