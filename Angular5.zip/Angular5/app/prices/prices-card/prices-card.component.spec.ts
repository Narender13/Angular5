import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PricesAndPerformanceCardComponent } from './prices-card.component';

describe('PricesAndPerformanceCardComponent', () => {
  let component: PricesAndPerformanceCardComponent;
  let fixture: ComponentFixture<PricesAndPerformanceCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PricesAndPerformanceCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PricesAndPerformanceCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
