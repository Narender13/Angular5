import { Component, Input } from '@angular/core';
import { Product } from '../../shared/models/product.model';

@Component({
  selector: 'app-prices-products-list',
  templateUrl: './prices-products-list.component.html',
  styleUrls: ['./prices-products-list.component.scss']
})
export class PricesProductsListComponent {
  @Input() products: Product[];

  constructor() { }
}
