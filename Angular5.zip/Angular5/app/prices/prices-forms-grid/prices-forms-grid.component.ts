import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';
import { ProductForm } from '../../shared/models/product-form.model';
import { ProductFormService } from '../../product-form/shared/product-form.service';
import { PricesService } from '../shared/prices.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-prices-forms-grid',
  templateUrl: './prices-forms-grid.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('PricesFormsGridComponent')
export class PricesFormsGridComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  productName: string;
  productForms: Observable<ProductForm[]>;
  downloading: boolean;
  usable: boolean;
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private productFormsService: ProductFormService,
    private pricesService: PricesService
  ) { }

  ngOnInit() {
    this.productForms = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { id: string }) => {
        return this.productFormsService.list(params.id, null, null);
      }),
      tap(() => this.loading = false),
      share()
    );
    this.count = this.productFormsService.count().pipe(share());
  }

  download(form) {
    if (form.external) {
      this.downloadExt(form);
    } else {
      this.downloading = true;
      this.productFormsService.download(form).subscribe(() => this.downloading = false);
    }
  }

  downloadExt(form) {
    const a = document.createElement('a');
    a.hidden = true;
    a.href = form.fileName;
    a.download = form.title;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

}
