import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ReportBuilderService, Report } from './shared/report-builder.service';

import { Observable } from 'rxjs/Observable';
import { share, tap, map } from 'rxjs/operators';
import { ContractAsset } from './../shared/models/contract-asset.model';
import { ContractActivityService } from '../contract-activity/shared/contract-activity.service';
import { ContractOwnerService } from '../contract-owner/shared/contract-owner.service';
import { ContractAssetService } from '../contract-asset/shared/contract-asset.service';
import { SurrenderService } from '../surrender/shared/surrender.service';
import { PurchaseService, PurchaseType, PurchaseTimespan } from '../purchase/shared/purchase.service';
import { PendingNewBusinessService } from '../pending-new-business/shared/pending-new-business.service';
import { TerminatedContractService } from '../terminated-contract/shared/terminated-contract.service';
import { Configure, Configurable } from '../shared/decorators/configurable';
import { ToolbarActionHandlers, ToolbarActionable } from '../shared/services/toolbar-action-handler';

@Component({
    selector: 'app-report-builder',
    templateUrl: './report-builder.component.html',
    styleUrls: ['./report-builder.component.scss']
})
@Configure('ReportBuilderComponent')
export class ReportBuilderComponent implements Configurable, OnInit, ToolbarActionable {
    @Input() activeTool: string;
    reportBuilderForm: FormGroup;
    reportType: ReportType = new ReportType();
    reportCriteriaBuilderForm: FormGroup;
    reportName = true;
    productTypeList: any[];
    qualificationTypeList: any[];
    fromDate: string;
    toDate: string;
    reportTypeList: any[];
    transactionList: any[];
    sortBy: any[];
    format: string;
    count: Observable<number>;
    list: Observable<any[]>;
    contractAssetList: Observable<ContractAsset[]>;
    loading = false;
    request: any;
    config: any;
    sortOrder: any[];
    purchaseTypeEnum: typeof PurchaseType = PurchaseType;
    Report: typeof Report = Report;
    purchaseTimespanEnum: typeof PurchaseTimespan = PurchaseTimespan;
    filterTimeFields: any[] =
        [
            { name: 'Last Business Day', value: 'lastBusinessDay', startDate: '06/19/2018', endDate: '06/19/2018' },
            { name: 'Last 7 Days', value: 'last7Days', startDate: '06/15/2018', endDate: '06/19/2018' },
            { name: 'Previous Month', value: 'previousMonth', startDate: '05/01/2018', endDate: '06/19/2018' },
            { name: 'Previous Quarter', value: 'previousQuarter', startDate: '04/01/2018', endDate: '06/19/2018' }
        ];

    product: any[] = [
        { name: 'Ascending', value: 'Asc' },
        { name: 'Descending', value: 'Desc' }
    ];
    purchaseType: any[] = [
        { purchaseType: 'Contributing', value: 'contributing' },
        { purchaseType: 'Non Contributing', value: 'non_contributing' }
    ];
    morningstarList: any;
    reportFormat: any[] = [
        { name: 'PDF', value: 'pdf' },
        { name: 'Excel', value: 'excel' },
        { name: 'In Browser', value: 'inBrowser' }
    ];
    constructor(
        private fb: FormBuilder,
        public route: ActivatedRoute,
        public router: Router,
        private service: ReportBuilderService,
        private caService: ContractActivityService,
        private contractAssetService: ContractAssetService,
        private contractOwnerService: ContractOwnerService,
        private terminatedContractService: TerminatedContractService,
        private surrenderService: SurrenderService,
        private pendingNewBusinessService: PendingNewBusinessService,
        private purchaseService: PurchaseService
    ) { }

    ngOnInit() {
        this.reportBuilderForm = this.fb.group({
            reportStatus: 'newReport',
            reportType: 'activity',
            fromDate: null,
            toDate: null,
            sortBy: 'transactionDate',
            sortOrder: 'Asc',
            reportFormat: 'pdf',
            reportName: '',
            product: null,
            morningstarStatus: 'mgdbymorningstar',
            assetPerson: null,
            purchaseType: 'contributing',
            productList: this.fb.array([
                this.fb.group({
                    ProductType: 'null',
                    ProductId: 'null',
                    status: false
                })
            ]),
            transactionList: this.fb.array([
                this.fb.group({
                    TransactionDescType: 'null',
                    TransactionId: 'null',
                    status: false
                })
            ]),
            qualificationList: this.fb.array([
                this.fb.group({
                    QualType: null,
                    status: false
                })
            ]),
            mgdbyMorningstarList: this.fb.array([
                this.fb.group({
                    mgdbyMorningstarType: 'All',
                    value: 'null',
                    status: false
                })
            ]),
        });
        this.productTypeList = this.service.getProductTypeList();
        this.qualificationTypeList = this.service.getQualificationTypeList();
        this.transactionList = this.service.getTransactionList();
        this.reportTypeList = this.service.getReportypeList();
        this.sortOrder = this.service.sortOptions.sortOrder;
        this.morningstarList = this.service.getMorningstarOptions();

        this.setCriteria(this.reportBuilderForm.get('reportType').value);
        this.setListValue(this.productTypeList, 'productList');
        this.setListValue(this.transactionList, 'transactionList');
        this.setListValue(this.qualificationTypeList, 'qualificationList');
        this.setListValue(this.morningstarList.morningstarOptions, 'mgdbyMorningstarList');
        ToolbarActionHandlers.handle(this);
    }
    setListValue(listItem, control) {
        const list = listItem.map(item => this.fb.group(item));
        const arrayList = this.fb.array(list);
        this.reportBuilderForm.setControl(control, arrayList);
    }

    displayCriteria(selectedItem: any) {
        this.reportType = {
            activity: false,
            assetsByPerson: false,
            bookofBusinessByProduct: false,
            clientReport: false,
            closedClientAccounts: false,
            contributingAndNonContributing: false,
            loansAndWithdrawalsAndSurrenders: false,
            morningstar: false,
            pendingContracts: false
        };
        this.reportType[selectedItem] = true;
    }
    setCriteria(reportType) {
        const selectedReport = reportType;
        switch (selectedReport) {
            case Report.activity:
                this.displayCriteria(Report.activity);
                this.sortBy = this.service.sortOptions.activityOrderBy;
                break;
            case Report.assetsByPerson:
                this.displayCriteria('assetsByPerson');
                this.sortBy = this.service.sortOptions.contractAssetOrderBy;
                break;
            // case 'book_of_business_by_product':
            case Report.clientReport:
                this.displayCriteria(Report.clientReport);
                this.sortBy = this.service.sortOptions.clientReportOrderBy;
                break;
            case Report.closedClientAccounts:
                this.displayCriteria('closedClientAccounts');
                this.sortBy = this.service.sortOptions.closedClientAccounts;
                break;
            case Report.contributions:
                this.displayCriteria('contributingAndNonContributing');
                this.sortBy = this.service.sortOptions.purchasesOrderBy;
                break;
            case Report.morningstar:
                this.displayCriteria(Report.morningstar);
                break;
            case Report.contracts:
                this.displayCriteria('pendingContracts');
                this.sortBy = this.service.sortOptions.pendingContractsOrderBy;
                break;
            case Report.surrenders:
                this.displayCriteria('loansAndWithdrawalsAndSurrenders');
                this.sortBy = this.service.sortOptions.surrendersOrderBy;
                break;
        }
        this.reportBuilderForm.patchValue({ sortBy: this.sortBy[0].value });
    }
    changeCriteria(value: any) {
        this.setCriteria(value);
    }
    setCriteriaName() {
        this.reportName = !this.reportName;
    }
    updatedItemList(): UpdatedItemList {
        const productTypeList = this.reportBuilderForm.controls.productList.value.filter(item => item.status === true)
            .map(list => list.ProductType).join(',');
        const transactionList = this.reportBuilderForm.controls.transactionList.value.filter(item => item.status === true)
            .map(list => list.TransactionDescType).join(',');
        const qualificationTypeList = this.reportBuilderForm.controls.qualificationList.value.filter(item => item.status === true)
            .map(list => list.QualType).join(',');
        const mgdbyMorningstar = this.reportBuilderForm.controls.mgdbyMorningstarList.value.filter(item => item.status === true)
            .map(list => list.mgdbyMorningstarType).join(',');
        return {
            productTypeList: productTypeList,
            transactionList: transactionList,
            qualificationTypeList: qualificationTypeList,
            mgdbyMorningstarList: mgdbyMorningstar
        };
    }
    saveReport() {
        const reportype = this.reportBuilderForm.get('reportType').value;
        this.reportRequest(reportype);
    }

    runReport() {
        const reportype = this.reportBuilderForm.get('reportType').value;
        const reportFormat = this.reportBuilderForm.get('reportFormat').value;
        this.request = this.reportRequest(reportype);
        const sortOrder = this.request.sortOrder;
        const orderBy = sortOrder ? this.request.sortBy + ' ' + sortOrder : this.request.sortBy;
        if (reportFormat === Report.browser) {
            this.runReportInBrowser(orderBy);
        }
        if (reportFormat === Report.excel) {
            this.router.navigate([Report.reportBuilber],
                { queryParams: { action: Report.export, type: Report.excel }, skipLocationChange: true });
        }
        if (reportFormat === Report.pdf) {
            console.log('Init pdf');
            this.router.navigate([Report.reportBuilber],
                { queryParams: { action: Report.export, type: Report.pdf }, skipLocationChange: true });

        }
    }
    onExport(format: string): Observable<any> {
        this.format = format;
        this.loading = true;
        const reportype = this.reportBuilderForm.controls.reportType.value;
        if (reportype === Report.activity) {
            return this.exportToExcel(this.caService);
        }
        if (reportype === Report.assetsByPerson) {
            return this.exportToExcel(this.contractAssetService);
        }
        if (reportype === Report.clientReport) {
            return this.exportToExcel(this.contractOwnerService);
        }
        if (reportype === Report.closedClientAccounts) {
            return this.exportToExcel(this.terminatedContractService);
        }
        if (reportype === Report.surrenders) {
            return this.exportToExcel(this.surrenderService);
        }
        if (reportype === Report.contracts) {
            return this.exportToExcel(this.pendingNewBusinessService);
        }
        if (reportype === Report.contributions) {
            return this.exportToExcel(this.purchaseService);
        }
    }

    exportToExcel(service) {
        return service.export(this.format).pipe(
            map(data => data),
            tap(() => {
                this.loading = false;
            }),
        );
    }
    runReportInBrowser(orderBy: string) {
        this.loading = true;
        if (this.request.reportType === Report.activity) {
            this.getfiltereddata(this.caService, orderBy);
        }
        if (this.request.reportType === Report.assetsByPerson) {
            this.getfiltereddata(this.contractAssetService, orderBy);
        }
        if (this.request.reportType === Report.clientReport) {
            this.getfiltereddata(this.contractOwnerService, orderBy);
        }
        if (this.request.reportType === Report.closedClientAccounts) {
            this.getfiltereddata(this.terminatedContractService, orderBy);
        }
        if (this.request.reportType === Report.surrenders) {
            this.getfiltereddata(this.surrenderService, orderBy);
        }
        if (this.request.reportType === Report.contracts) {
            this.getfiltereddata(this.pendingNewBusinessService, orderBy);
        }
        if (this.request.reportType === Report.contributions) {
            this.getfiltereddata(this.purchaseService, orderBy);
        }
    }

    getfiltereddata(service, sortByoption) {
        this.count = service.count().pipe(share());
        if (this.request.reportType === Report.contributions) {
            const cfg = this.config;
            cfg.purchaseType = PurchaseType.Contributing;
            cfg.timespan = PurchaseTimespan.Days365;
            cfg.limit = cfg.limit;
            cfg.offset = 0;
            cfg.orderby = sortByoption || cfg.orderby;
            this.list = service.list(cfg.purchaseType, cfg.timespan, null, cfg.limit, cfg.offset, cfg.orderby).pipe(
                map(data => data),
                tap(() => {
                    this.loading = false;
                }),
                share()
            );
        } else {
            this.config.limit = this.config.limit;
            this.config.offset = this.config.offset || 0;
            this.config.orderby = sortByoption || this.config.orderby;
            this.list = service.list(null, this.config.limit, this.config.offset, this.config.orderby).pipe(
                map(data => data),
                tap(() => {
                    this.loading = false;
                }),
                share()
            );
        }
    }
    reportRequest(reportype: string): any {
        let saveReportRequest: any = {};
        saveReportRequest = {
            reportStatus: this.reportBuilderForm.get('reportStatus').value,
            reportType: reportype,
            sortBy: this.reportBuilderForm.get('sortBy').value || 'contractNumber',
            reportFormat: this.reportBuilderForm.get('reportFormat').value,
            reportName: this.reportBuilderForm.get('reportName').value,
        };
        switch (reportype) {
            case Report.activity:
                saveReportRequest.productTypeList = this.updatedItemList().productTypeList;
                saveReportRequest.TransactionTypeList = this.updatedItemList().transactionList;
                saveReportRequest.TransactionTypeList = this.updatedItemList().transactionList;
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                break;
            case Report.assetsByPerson:
                saveReportRequest.productTypeList = this.updatedItemList().productTypeList;
                saveReportRequest.qualificationTypeList = this.updatedItemList().qualificationTypeList;
                saveReportRequest.mgdbyMorningstarList = this.updatedItemList().mgdbyMorningstarList;
                saveReportRequest.product = this.reportBuilderForm.get('product').value;
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                break;
            case Report.clientReport:
                saveReportRequest.productTypeList = this.updatedItemList().productTypeList;
                break;
            case Report.closedClientAccounts:
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                break;
            case Report.contributions:
                saveReportRequest.productTypeList = this.updatedItemList().productTypeList;
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                saveReportRequest.purchaseType = this.reportBuilderForm.get('purchaseType').value;
                break;
            case Report.surrenders:
                saveReportRequest.productTypeList = this.updatedItemList().productTypeList;
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                break;
            case Report.morningstar:
                saveReportRequest.status = this.reportBuilderForm.get('morningstarStatus').value;
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                break;
            case Report.contracts:
                saveReportRequest.sortOrder = this.reportBuilderForm.get('sortOrder').value;
                break;
            default:
        }
        return saveReportRequest;
    }
}
export class ReportType {
    activity?: boolean;
    assetsByPerson?: boolean;
    bookofBusinessByProduct?: boolean;
    clientReport?: boolean;
    closedClientAccounts?: boolean;
    contributingAndNonContributing?: boolean;
    loansAndWithdrawalsAndSurrenders?: boolean;
    morningstar?: boolean;
    pendingContracts?: boolean;

}
export class UpdatedItemList {
    productTypeList: string;
    transactionList: string;
    qualificationTypeList: string;
    mgdbyMorningstarList: string;
}
