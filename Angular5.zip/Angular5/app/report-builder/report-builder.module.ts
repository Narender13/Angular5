import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PendingNewBusinessModule } from '../pending-new-business/pending-new-business.module';
import { ReportBuilderRoutingModule } from './report-builder-routing.module';
import { ReportBuilderComponent } from './report-builder.component';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { ReportBuilderService } from './shared/report-builder.service';

@NgModule({
    declarations: [ReportBuilderComponent],
    imports: [CommonModule, SharedModule, FormsModule, ReactiveFormsModule, ReportBuilderRoutingModule, PendingNewBusinessModule],
    exports: [ReportBuilderComponent],
    providers: [ReportBuilderService]
})
export class ReportBuilderModule { }
