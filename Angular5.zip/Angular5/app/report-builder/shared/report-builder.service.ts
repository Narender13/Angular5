import { Injectable } from '@angular/core';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ReportBuilderService {
    constructor(
        private http: UWHttp,
    ) { }

    getProductTypeList() {
        return [
            { ProductType: 'Retirement Plans', ProductId: '1', status: true },
            { ProductType: 'Fixed Annuities', ProductId: '2', status: false },
            { ProductType: 'Variable Annuities', ProductId: '3', status: false },
            { ProductType: 'Fixed Index Annuities', ProductId: '4', status: false },
            { ProductType: 'Other(VUL,etc)', ProductId: '5', status: false }

        ];
    }
    getQualificationTypeList() {
        return [
            { QualType: 'HRA', status: true },
            { QualType: 'Qualified Plan Distributed Annuity', status: false },
            { QualType: '403(b)/403(b)(7)', status: false },
            { QualType: 'Keogh', value: 'keogh', status: false },
            { QualType: 'SEP/SARSEP/Simple IRA', status: false },
            { QualType: '401a/Def Cntb', status: 'false' },
            { QualType: 'Money Purchase Plan', status: false },
            { QualType: 'Trad/Roth IRA', status: false },
            { QualType: '457/DEF Comp', status: false },
            { QualType: 'Non-Qual', status: false },
            { QualType: 'Other', status: false },
            { QualType: 'Defined Benifit Plan', status: false },
            { QualType: 'Profit Sharing Plan', status: false }

        ];
    }
    getReportypeList() {
        return [
            { ReportType: 'Activity', value: 'activity' },
            { ReportType: 'Assets By Person', value: 'assets_by_person' },
            { ReportType: 'Book of Business by Product', value: 'book_of_business_by_product' },
            { ReportType: 'Client Report', value: 'clientReport' },
            { ReportType: 'Closed Client Accounts', value: 'closed_client_accounts' },
            { ReportType: 'Contributing/Non Contributing', value: 'contributing_non_contributing' },
            { ReportType: 'Loans/Withdrawals/Surrenders', value: 'loans_withdrawals_surrenders' },
            { ReportType: 'Morningstar', value: 'morningstar' },
            { ReportType: 'Pending Contracts', value: 'pending_contracts' }

        ];
    }
    getTransactionList() {
        return [
            { TransactionDescType: 'Miscellaneous', TransactionId: '1', status: false },
            { TransactionDescType: 'Dividents/Capital Gains', TransactionId: '2', status: true },
            { TransactionDescType: 'Purchases', TransactionId: '3', status: false },
            { TransactionDescType: 'Exchanges', TransactionId: '4', status: false },
            { TransactionDescType: 'Withdrawals', TransactionId: '5', status: false },
            { TransactionDescType: 'Loans', TransactionId: '6', status: false },
            { TransactionDescType: 'Other', TransactionId: '7', status: false }
        ];
    }

    get sortOptions() {
        const options = {
            activityOrderBy: [
                { name: 'Date', value: 'transactionDate' },
                { name: 'Contract/Account', value: 'contractNumber' },
                { name: 'Account Holder', value: 'personName' },
                { name: 'Description', value: 'transactionDescription' },
                { name: 'Product', value: 'product' },
                { name: 'Amount', value: 'grossAmount' }
            ],
            contractAssetOrderBy: [
                { name: 'Contract/Account', value: 'contractNumber' },
                { name: 'Account Holder', value: 'personName' },
                { name: 'Product Investment', value: 'productName' },
                { name: 'Qual Type', value: 'qualificationType' },
                { name: 'Value', value: 'cashValue' }
            ],
            clientReportOrderBy: [
                { name: 'Account', value: 'contractNumber' },
                { name: 'Account Holder', value: 'personName' },
                { name: 'Tax Id', value: 'taxIdLast4' },
                { name: 'Address', value: 'address' },
                { name: 'Date of Birth', value: 'birthYear' },
                { name: 'Product', value: 'productName' },
                { name: 'Transaction Type', value: 'qualificationType' },
                { name: 'Value', value: 'cashValue' }
            ],
            closedClientAccounts: [
                { name: 'Account Holder', value: 'personName' },
                { name: 'Contract / Account', value: 'contractNumber' },
                { name: 'Issue Date', value: 'issueDate' },
                { name: 'Termination Date', value: 'terminationDate' }
            ],
            surrendersOrderBy: [
                { name: 'Account Holder', value: 'personName' },
                { name: 'Contract / Account', value: 'contractNumber' },
                { name: 'Date', value: 'transactionDate' },
                { name: 'Description', value: 'transactionType' },
                { name: 'Payee', value: 'payeeName' },
                { name: 'Gross Amount', value: 'grossAmount' },
                { name: 'Net Amount', value: 'netAmount' }
            ],
            pendingContractsOrderBy: [
                { name: 'Account Holder', value: 'contractNumber' },
                { name: 'Contract / Account', value: 'personName' },
                { name: 'Application Date', value: 'applicationDate' },
            ],
            purchasesOrderBy: [
                { name: 'Account Holder', value: 'personName' },
                { name: 'Contract / Account', value: 'contractNumber' },
                { name: 'Date', value: 'transactionDate' },
                { name: 'Gross Amount', value: 'grossAmount' },
                { name: 'Product', value: 'productName' }
            ],
            sortOrder:
                [
                    { name: 'Ascending', value: 'Asc' },
                    { name: 'Descending', value: 'Desc' }
                ]
        };
        return options;
    }
    getMorningstarOptions() {
        const options = {
            morningstarOptions:
                [
                    { mgdbyMorningstarType: 'All', value: 'all', status: true },
                    { mgdbyMorningstarType: 'Yes', value: 'yes', status: false },
                    { mgdbyMorningstarType: 'No', value: 'no', status: false }
                ],
            morningstarStatusList: [
                { name: 'Managed By Morningstar', value: 'mgdbymorningstar' },
                { name: 'Not Managed By Morningstar', value: 'notmgdbymorningstar' },
                { name: 'Not Eligible for Morningstar', value: 'notEligibleforMorningstar' }

            ]
        };
        return options;
    }

}
export enum Report {
    activity = 'activity',
    assetsByPerson = 'assets_by_person',
    clientReport = 'clientReport',
    closedClientAccounts = 'closed_client_accounts',
    surrenders = 'loans_withdrawals_surrenders',
    contracts = 'pending_contracts',
    contributions = 'contributing_non_contributing',
    morningstar = 'morningstar',
    browser = 'inBrowser',
    excel = 'excel',
    pdf = 'pdf',
    export = 'export',
    reportBuilber = 'reportbuilder'

}
