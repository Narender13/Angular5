import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../shared/services/auth-guard.service';

import { ReportBuilderComponent } from './report-builder.component';

const routes: Routes = [
    { path: 'reportbuilder', component: ReportBuilderComponent, canActivate: [AuthGuardService] }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ReportBuilderRoutingModule { }
