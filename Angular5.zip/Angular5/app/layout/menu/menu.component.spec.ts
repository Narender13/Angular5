
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../../shared/shared.module';
import { CommonModule } from '@angular/common';

import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { MenuComponent } from '../menu/menu.component';

import { DashboardComponent } from '../../dashboard/dashboard.component';

describe('MenuComponent', () => {
  let component: MenuComponent;
  let fixture: ComponentFixture<MenuComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, SharedModule, HttpModule],
      declarations: [
        HeaderComponent,
        FooterComponent,
        DashboardComponent,
        MenuComponent
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuComponent);
    component = fixture.componentInstance;
    // query for the layout items
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.navbar'));
    el = de.nativeElement;
    expect(el.textContent.substr(0, 16)).toEqual('Application Menu');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
