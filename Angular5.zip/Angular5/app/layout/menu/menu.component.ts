import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { tap, map } from 'rxjs/operators';



import { Contract } from '../../shared/models/contract.model';
import { ContractService } from '../../contract/shared/contract.service';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { ComponentConfigService } from '../../shared/services/component-config.service';
import { Observable } from 'rxjs/Observable';

export class MenuItem {
  name: string;
  route: string;
  items: MenuItem[];
  matrix: any;
}
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
@AutoUnsubscribe()
@Configure('MenuComponent')
export class MenuComponent implements Configurable, OnInit {
  primaryItems = [];
  secondaryItems = [];
  contextItems = [];
  config: any;
  activeComponent: any;
  currentContract: Contract;
  usable: boolean;
  contextBusy = false;
  mainBusy = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private contractService: ContractService,
    private componentConfigService: ComponentConfigService) {
    router.events
      .filter(e => e instanceof NavigationEnd)
      .forEach(e => {
        this.contextItems = [];
        // Such as in the case when the browser is refreshed menu is going to have to request this contract for the sake of the context menu
        const contid = route.root.firstChild.snapshot.paramMap.get('contractId');
        if (!this.currentContract && contid) {
          this.contextBusy = true;
          this.contractService.find(contid).pipe(
            tap(_ => this.contextBusy = true),
            map(data => {
              this.currentContract = data;
              this.setContextMenu((this.route.root.firstChild.snapshot.component as any).name);
            }),
            tap(_ => this.contextBusy = false)
          ).subscribe();
        } else {
          this.setContextMenu((route.root.firstChild.snapshot.component as any).name);
        }
      });
  }

  ngOnInit() {
    this.contractService.contract.pipe(
      tap(_ => this.contextBusy = true),
      map(data => {
        this.currentContract = data;
        this.setContextMenu((this.route.root.firstChild.snapshot.component as any).name);
      }),
      tap(_ => this.contextBusy = false)
    ).subscribe();
    // go busy when the user service notifies of an impending user change (e.g. impersonation)
    this.userService.userChanging().subscribe(_ => this.mainBusy = true);
    this.userService.userLoaded().subscribe(user => {
      this.componentConfigService.configure(this);
      this.mainBusy = false;
    });
  }

  configView() {
    this.primaryItems = this.setMenuItems(this.config.items.primary);
    this.secondaryItems = this.setMenuItems(this.config.items.secondary);
  }

  userCanAccess(component: string): boolean {
    const user = this.userService.user;
    if (user && component) {
      const compConfig = this.componentConfigService.components.get(component);
      if (!compConfig) { return false; }

      const componentRoles = compConfig.roles as string[];
      // a component must have at least one role to be available, a component without a role is an error
      if (componentRoles && componentRoles.length > 0) {
        // a component will be available if it has a public role, no reason to check further
        if (componentRoles.includes('public')) {
          return true;
        }
        // it will be available if a users user_type matches a role
        const userTypes = user.profile.user_type as string[];
        const intersectedRoles = componentRoles.filter(r => userTypes.includes(r));
        if (intersectedRoles.length > 0) {
          return true;
        }
      } else {
        throw new Error(`component ${component} has no roles.`);
      }
    }
    return false;
  }

  setContextMenu(componentName: string) {
    this.activeComponent = this.componentConfigService.components.get(componentName);
    console.info(`Active component ${componentName}`, this.activeComponent);
    if (this.activeComponent && this.activeComponent.items) {
      this.contextItems = this.setMenuItems(this.activeComponent.items);
      console.info(`setting context menu items`, this.contextItems);
    }
  }

  setMenuItems(items) {
    const menuItems = [];
    items.forEach(item => {
      // TODO: do this better
      let mergedTitle = item.title as string;
      if (this.currentContract) {
        mergedTitle = mergedTitle.replace(':contractNumber', this.currentContract.contractNumber);
        mergedTitle = mergedTitle.replace(':personName', this.currentContract.personName);
        mergedTitle = mergedTitle.replace(':productName', this.currentContract.productName);
      }
      // each item is either a root primary menu link...
      if (item.component && this.componentConfigService.components.get(item.component).route && this.userCanAccess(item.component)) {
        const theRoute = this.componentConfigService.components.get(item.component).route;
        const mergedRoute = theRoute.replace(':key', mergedTitle);
        console.log("Pushing route ", mergedRoute);
        menuItems.push({ name: mergedTitle, route: mergedRoute, items: [] });
      } else {
        // ... or, its a menu group header that has child items.
        // First figure out if the group will even show in the menu
        // by checking to see if this user has access to any of the
        // child items.  If the user does then add the group to the primary menu.
        if (!item.items) { return; }
        const childItems = (item.items as Array<any>).filter(i => this.userCanAccess(i.component));
        if (childItems.length > 0) {
          const menuItem = { name: mergedTitle, route: null, items: [] };
          childItems.forEach(ci => {
            const ciConfig = this.componentConfigService.components.get(ci.component);
            let mergedRoute = ciConfig.route;
            if (this.currentContract) {
              mergedRoute = mergedRoute.replace(':id', this.currentContract.id);
            }
            mergedRoute = mergedRoute.replace(':key', ci.title);
            menuItem.items.push({ name: ci.title, route: mergedRoute, items: [], matrix: ciConfig.matrix });
          });
          menuItems.push(menuItem);
        }
      }
    });
    return menuItems;
  }
}
