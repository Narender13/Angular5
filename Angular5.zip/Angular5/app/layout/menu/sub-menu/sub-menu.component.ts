import { Component, HostBinding, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { MenuItem } from '../menu.component';

@Component({
  selector: 'app-sub-menu',
  templateUrl: './sub-menu.component.html',
  styleUrls: ['./sub-menu.component.scss']
})
export class SubMenuComponent {
  @HostBinding('class.active') active = false;
  @Input() items: MenuItem[];
  constructor() { }

  toggleActive(e: Event, state: boolean) {
    if (typeof state === 'boolean') {
      this.active = state;
    } else {
      this.active = !this.active;
    }

    e.stopPropagation();
  }

}
