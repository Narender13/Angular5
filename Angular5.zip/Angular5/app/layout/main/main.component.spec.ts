
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../../shared/shared.module';
import { CommonModule } from '@angular/common';

import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { MenuComponent } from '../menu/menu.component';
import { MenuService } from '../menu/menu.service';
import { MainComponent } from './main.component';
import { DashboardComponent } from '../../dashboard/dashboard.component';

describe('MainComponent', () => {
  let component: MainComponent;
  let fixture: ComponentFixture<MainComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, SharedModule, HttpModule],
      declarations: [
        MainComponent,
        HeaderComponent,
        FooterComponent,
        DashboardComponent,
        MenuComponent
      ],
      providers: [MenuService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MainComponent);
    component = fixture.componentInstance;
    // query for the layout items
    fixture.detectChanges();
    de = fixture.debugElement.query(By.css('.navbar'));
    el = de.nativeElement;
    expect(el.textContent.substr(0, 6)).toEqual('Header');
    de = fixture.debugElement.query(By.css('footer'));
    el = de.nativeElement;

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
