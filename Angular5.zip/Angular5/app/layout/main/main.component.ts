import { Component, OnInit, HostBinding } from '@angular/core';
import { Router } from '@angular/router';
import { share, switchMap, debounceTime } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

import { Menu } from '../../shared/models/menu.model';
import { SubscriptionService } from '../../subscription/shared/subscription.service';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss'],
  host: {
    '(window:resize)': 'onResize($event)'
  }
})
@AutoUnsubscribe()
@Configure('MainComponent')
export class MainComponent implements Configurable, OnInit {
  @HostBinding('class.active') active = false;
  config: any;
  menuItems: Menu[];
  isBusy = false;
  usable: boolean;
  collapseMenu: Observable<boolean>;
  resizeChanges = new Subject<number>();

  constructor(
    private userService: UserService,
    private subscriptionService: SubscriptionService,
    private router: Router
  ) { }

  ngOnInit() {
    this.userService.userLoaded()
      .subscribe(user => {
        if (user) {
          // register with pubsub
          this.subscriptionService.register().subscribe((res) => {
            console.info('Registered with subscription service:' + res);
          });
          // check for mandated user action and reroute if any.
          // its here in main component because this needs to be "globally" applied, I was going to put it in the
          // authguard service but a redirect to '/profile' there causes infinate loop.
          //
          if (this.userService.user && this.userService.user.profile.convert_validation) {
            this.router.navigate(['/profile']);
          }
        }
      });
      
    this.config.menuBreakpoint = this.config.menuBreakpoint || 768;
    this.collapseMenu = this.resizeChanges.pipe(
      debounceTime(400),
      switchMap(size => Observable.of(size < this.config.menuBreakpoint)),
      share()
    );
  }
    
  onResize(event) {
    this.resizeChanges.next(event.target.innerWidth);
  }

  toggleActive(e: Event, state?: boolean) {
    if (typeof state === 'boolean') {
      this.active = state;
    } else {
      this.active = !this.active;
    }
    e.stopPropagation();
  }
}
