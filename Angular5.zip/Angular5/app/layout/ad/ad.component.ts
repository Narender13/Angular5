import { Component, OnInit } from '@angular/core';



import { LoggingService } from '../../shared/logging/logging.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-ad',
  templateUrl: './ad.component.html',
  styles: []
})
@Configure('AdComponent')
export class AdComponent implements Configurable, OnInit {
  config: any;
  adHtml = 'no ad content found';
  usable: boolean;

  constructor(
    private loggingService: LoggingService
  ) { }

  ngOnInit() {
    this.adHtml = this.config.text;
  }
}
