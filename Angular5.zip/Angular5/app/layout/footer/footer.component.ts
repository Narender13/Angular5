import { Component, OnInit } from '@angular/core';



import { LoggingService } from '../../shared/logging/logging.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
@AutoUnsubscribe()
@Configure('FooterComponent')
export class FooterComponent implements Configurable, OnInit {
  config: any;
  footerHtml = 'no footer content found';
  usable: boolean;

  constructor(
    private loggingService: LoggingService
  ) { }

  ngOnInit() {
    this.footerHtml = this.config.text;
  }
}
