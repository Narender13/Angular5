import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

import { UserService } from '../../shared/services/user.service';
import { StorageService } from '../../shared/services/storage.service';
import { AliasService } from '../../shared/services/alias.service';
import { Alias } from '../../shared/models/alias.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
@AutoUnsubscribe()
@Configure('HeaderComponent')
export class HeaderComponent implements Configurable, OnInit {
  @Input() showMenu: boolean;
  config: any;
  userFirstName: string;
  userEmail: string;
  showSignIn: boolean;
  showRegister: boolean;
  alias: Alias;
  usable: boolean;
  isUserSso: boolean;

  constructor(
    private userService: UserService,
    private router: Router,
    private location: Location,
    private storageService: StorageService,
    private aliasService: AliasService) { }

  ngOnInit() {

    this.aliasService.observeCurrent.subscribe(a => {
      this.alias = a;
    });

    this.userService.userLoaded()
      .subscribe(user => {
        if (user) {
          this.userFirstName = user.profile.given_name;
          this.userEmail = user.profile.email;
          this.isUserSso = user.profile.is_saml_sso === 'true'; // safe for when it isn't present
        }
      });
  }

  logout() {
    this.userService.startSignoutMainWindow();
  }

  clearStorage() {
    this.storageService.clear();
  }

}
