import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { ContractModule } from '../contract/contract.module';
import { HomeModule } from '../home/home.module';
import { DashboardModule } from '../dashboard/dashboard.module';
import { EmbedModule } from '../shared/components/embed/embed.module';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { MainComponent } from './main/main.component';
import { MenuComponent } from './menu/menu.component';
import { SubMenuComponent } from './menu/sub-menu/sub-menu.component';
import { ForgottenCredModule } from '../forgotten-cred/forgotten-cred.module';
import { RegisterCompleteModule } from '../register-complete/register-complete.module';
import { RegisterConfirmModule } from '../register-confirm/register-confirm.module';
import { ResetPasswordModule } from '../reset-password/reset-password.module';
import { ResetPasswordConfirmModule } from '../reset-password-confirm/reset-password-confirm.module';
import { SendCodeConfirmModule } from '../forgotten-cred-confirm/send-code-confirm.module';
import { MessageModule } from '../message/message.module';
import { SharedModule } from '../shared/shared.module';
import { MessageBusComponent } from '../shared/message-bus/message-bus.component';
import { SubscriptionService } from '../subscription/shared/subscription.service';
import { ProductFormModule } from '../product-form/product-form.module';
import { AdComponent } from './ad/ad.component';
import { ExternalLinkComponent } from './external-link/external-link.component';
import { GTPHandshakeModule } from '../gtp-handshake/gtp-handshake.module';
import { GtpManageGroupsModule } from '../gtp-manage-groups/gtp-manage-groups.module';

@NgModule({
  declarations: [
    FooterComponent,
    HeaderComponent,
    MainComponent,
    MenuComponent,
    SubMenuComponent,
    MessageBusComponent,
    AdComponent,
    ExternalLinkComponent
  ],
  imports: [
    CommonModule,
    ContractModule,
    DashboardModule,
    EmbedModule,
    ForgottenCredModule,
    RegisterCompleteModule,
    RegisterConfirmModule,
    ResetPasswordModule,
    ResetPasswordConfirmModule,
    SendCodeConfirmModule,
    MessageModule,
    ProductFormModule,
    HttpModule,
    RouterModule,
    SharedModule,
    HomeModule,
    GTPHandshakeModule,
    GtpManageGroupsModule
  ],
  providers: [
    SubscriptionService
  ],
  exports: [MainComponent]
})
export class LayoutModule { }
