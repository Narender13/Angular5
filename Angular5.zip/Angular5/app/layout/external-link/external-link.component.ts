import { Component, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-external-link',
  templateUrl: './external-link.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ExternalLinkComponent')
export class ExternalLinkComponent implements Configurable, OnInit {
  config: any;
  externalLink: any[];
  usable: any;
  userEmail: string;

  constructor(
    private userService: UserService
  ) { }

  ngOnInit() {
    if (this.config.externalLink && this.userService.loggedIn) {
      this.config.externalLink.forEach(element => {
        element.url = (element.url as string).replace('{userId}', this.userService.user.profile.sub);
      });
      this.externalLink = this.config.externalLink;
    }
  }

}
