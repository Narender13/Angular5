import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MessageGridComponent } from './message-grid/message-grid.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';


const messageRoutes: Routes = [
  { path: 'messages/:id', component: MessageGridComponent,
  canActivate: [AuthGuardService] },
  { path: 'messages', component: MessageGridComponent,
  canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(messageRoutes)],
  exports: [RouterModule]
})
export class MessageRoutingModule { }
