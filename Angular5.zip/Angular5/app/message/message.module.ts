import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MessageBadgeComponent } from './message-badge/message-badge.component';
import { MessageCardComponent } from './message-card/message-card.component';
import { MessageDetailComponent } from './message-detail/message-detail.component';
import { MessageListComponent } from './message-list/message-list.component';
import { MessageChipComponent } from './message-chip/message-chip.component';
import { MessageGridComponent } from './message-grid/message-grid.component';
import { MessageRoutingModule } from './message-routing.module';
import { MessageWidgetComponent } from './message-widget/message-widget.component';
import { PopoverModule } from 'ngx-popover';
import { SharedModule } from '../shared/shared.module';
import { MessageService } from './shared/message.service';

@NgModule({
  declarations: [
    MessageBadgeComponent,
    MessageCardComponent,
    MessageChipComponent,
    MessageDetailComponent,
    MessageGridComponent,
    MessageListComponent,
    MessageWidgetComponent
  ],
  imports: [
    CommonModule,
    MessageRoutingModule,
    PopoverModule,
    SharedModule
  ],
  exports: [
    MessageBadgeComponent,
    MessageCardComponent,
    MessageChipComponent,
    MessageDetailComponent,
    MessageGridComponent,
    MessageListComponent,
    MessageWidgetComponent
  ],
  providers: [
    MessageService
  ]
})
export class MessageModule { }
