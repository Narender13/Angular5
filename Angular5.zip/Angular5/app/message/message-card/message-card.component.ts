import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { MessageBusService } from '../../shared/message-bus/shared/message-bus.service';
import { MessageService } from '../../message/shared/message.service';
import { UserService } from '../../shared/services/user.service';
import { Message } from '../../shared/models/message.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-message-card',
  templateUrl: './message-card.component.html',
  styleUrls: ['./message-card.component.scss']
})
@AutoUnsubscribe()
@Configure('MessageCardComponent')
export class MessageCardComponent implements Configurable, OnInit {
  // componentName = 'messages';
  config: any;
  count: Observable<number>;
  @Input() limit = 5;
  messages: Message[];
  offset = 0;
  prevCount: number;
  usable: any;

  constructor(
    private userService: UserService,
    private service: MessageService,
    private messageBusService: MessageBusService
  ) { }

  ngOnInit() {
    this.userService.userLoaded()
      .subscribe(user => {
        this.config.limit = this.config.cardLimit || this.limit;
        this.config.offset = this.offset;
        this.init();
      });
  }

  init() {
    this.count = this.service.countNew().pipe(share());
    this.service.newMessages$.subscribe(
      count => {
        if (count === undefined) { return; }
        if (count === this.prevCount) { return; }
        this.prevCount = count;
        // when count changes, refresh here
        this.service.list('', this.config.limit, this.config.offset, '', ['New'])
          .subscribe((res: Message[]) => {
            this.messages = res;
          });
      });
    this.messageBusService.messageUpdateEmitter.subscribe(() => {
      this.service.list('', this.config.limit, this.config.offset, '', ['New'])
        .subscribe((res: Message[]) => {
          this.messages = res;
        });
    });
  }

}
