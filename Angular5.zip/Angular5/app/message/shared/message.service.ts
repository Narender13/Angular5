import { RequestOptions, Response, Headers, URLSearchParams } from '@angular/http';
import { UWHttp } from '../../UWHttp';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';



import { Message } from '../../shared/models/message.model';
import { Paginated } from '../../shared/models/paginated.interface';
import { LoggingService } from '../../shared/logging/logging.service';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class MessageService {
  private path = 'messages';
  private countNewMessages = new BehaviorSubject<number>(undefined);
  // tslint:disable-next-line:member-ordering
  newMessages$ = this.countNewMessages.asObservable();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  countNew(): Observable<number> {
    return this.count('', ['New'], this.extractCountNew);
  }

  countTotal(): Observable<number> {
    return this.count('', ['New', 'Read'], this.extractCount);
  }

  countFilteredTotal(searchTerm: string): Observable<number> {
    return this.count(searchTerm, ['New', 'Read'], this.extractCount);
  }

  count(search: string, filter: string[], counter: any): Observable<number> {
    const params = new URLSearchParams();
    if (filter.length) {
      for (const f of filter) {
        params.append('status', f);
      }
    }
    if (search) {
      params.set('subject', search);
    }
    return this.http.authGet(this.path + '/count', { search: params }).pipe(
      map(counter, this),
      catchError(this.loggingService.handleError));
  }

  list(search: string, limit: number, offset: number, orderby: string, filter: string[]): Observable<Message[]> {
    const params = new URLSearchParams();

    if (filter.length) {
      for (const f of filter) {
        params.append('status', f);
      }
    }

    if (search) {
      params.set('subject', search);
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }
    return this.http.authGet(this.path, { search: params }).pipe(
      map(res => this.extractData(res)),
      catchError(this.loggingService.handleError));

  }

  index(id: number, orderby: string): Observable<number> {
    const params = new URLSearchParams();
    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.path + '/' + id + '/index', { search: params }).pipe(
      map(res => this.extractIndex(res)),
      catchError(this.loggingService.handleError));

  }

  find(id): Observable<Message> {
    return this.http.authGet(this.path + '/' + id).pipe(
      map(res => res.json() as Message),
      catchError(this.loggingService.handleError));
  }

  update(message: Message): Observable<Message> {
    const headers = new Headers({ 'Content-Type': 'application/json' });
    const options = new RequestOptions({ 'headers': headers });
    const url = this.path + '/' + message.id;
    return this.http.authPut(url, message, options).pipe(
    map(res => this.extractData(res)),
      catchError(this.loggingService.handleError));
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<Message>;
    return body.items || [];
  }

  private extractIndex(res: Response) {
    const body = res.json() as number;
    return body === undefined ? -1 : body;
  }

  private extractCountNew(res: Response) {
    const body = res.json() as number;
    this.countNewMessages.next(body);
    return body || 0;
  }

  private extractCount(res: Response) {
    const body = res.json() as number;
    return body || 0;
  }
}
