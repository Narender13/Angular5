import { Component, Input, OnInit } from '@angular/core';

import { UserService } from '../../shared/services/user.service';
import { BadgeComponent } from '../../shared/badge/badge.component';
import { MessageService } from '../../message/shared/message.service';

@Component({
  selector: 'app-message-badge',
  templateUrl: './message-badge.component.html',
  styleUrls: ['./message-badge.component.scss']
})
export class MessageBadgeComponent implements BadgeComponent, OnInit {
  @Input() count = 0;

  constructor(private service: MessageService, private userService: UserService) { }

  ngOnInit() {
    this.userService.userLoaded()
      .subscribe(user => {
        this.service.countNew()
          .subscribe((res: number) => {
            this.count = res;
          });
        this.service.newMessages$.subscribe(
          count => {
            this.count = count;
          });
      });

  }

}
