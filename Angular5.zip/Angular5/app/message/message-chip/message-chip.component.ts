import { Component, Input } from '@angular/core';
import { Message } from '../../shared/models/message.model';

@Component({
  selector: 'app-message-chip',
  templateUrl: './message-chip.component.html',
  styles: [':host{width:100%;}']
})
export class MessageChipComponent {
  @Input() message: Message;

  constructor() { }

}
