import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Message } from '../../shared/models/message.model';
import { MessageService } from '../shared/message.service';
import { MessageBusService } from '../../shared/message-bus/shared/message-bus.service';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-message-grid',
  templateUrl: './message-grid.component.html',
  styleUrls: ['./message-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('MessageGridComponent')
export class MessageGridComponent implements Configurable, OnInit {
  config: any;
  @Input() limit = 10;
  @Input() offset = 0;
  @Input() orderby = 'CreatedOn';
  count: number;
  currentMessage: number;
  errorMessage: string;
  localized: any;
  messages: Message[];
  searchTerm = '';
  sortFields: string[] = ['CreatedOn', 'Subject'];
  usable: boolean;

  constructor(
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private service: MessageService,
    private messageBusService: MessageBusService
  ) {

  }

  ngOnInit() {
    this.userService.userLoaded()
      .subscribe(user => {
        this.config.limit = this.config.limit || this.limit;
        this.config.offset = this.offset;
        this.localized = this.config.translated;
        this.init();
      });
  }

  init() {
    this.route.params
      .switchMap((params: { id: string, q: string, limit: number, offset: number, orderby: string }) => {
        this.searchTerm = '';
        let navigating = false;
        if (params.limit !== undefined) { this.config.limit = +params.limit; navigating = true; }
        if (params.offset !== undefined) { this.config.offset = +params.offset; navigating = true; }
        if (params.q !== undefined) { this.searchTerm = params.q; navigating = true; }
        if (params.orderby !== undefined) { this.orderby = params.orderby; navigating = true; }

        // messages are filtered on 'New' messages for other components (a subset of messages);
        // whereas this component paginates through New AND Read messages (all messages):
        // therefore it is possible the component is initialized with pagination out of sync;
        // (that is, the message id maps to a different page);
        // get index of message and determine whether pagination needs to be updated
        this.currentMessage = undefined;
        // id in the route takes precedence over query parameter
        const pathidarray = this.router.url.split('/');
        if (pathidarray[2]) {
          this.currentMessage = +pathidarray[2].split(';')[0];
        } else if ((params.id !== undefined) && (params.id !== 'null')) {
          this.currentMessage = +params.id;
        }
        if (this.currentMessage !== undefined) {
          this.service
            .index(this.currentMessage, this.orderby)
            .subscribe((index) => {
              const offset = this.config.limit * (Math.floor(index / this.config.limit));
              if (offset !== this.config.offset) {
                // the requested message is on a different page
                // if navigating to an offset, use that
                if (!navigating) {
                  this.config.offset = offset;
                }
                this.service.list(this.searchTerm, this.config.limit, this.config.offset, this.orderby, ['New', 'Read'])
                  .subscribe((res: Message[]) => {
                    this.messages = res;
                    this.openSelected(this.messages.find(x => x.id === this.currentMessage));
                  });
              }
            });
        }

        return this.service.list(this.searchTerm, this.config.limit, this.config.offset, this.orderby, ['New', 'Read']);
      })
      .subscribe((res: Message[]) => {
        this.messages = res;
        this.openSelected(this.messages.find(x => x.id === this.currentMessage));
        this.service.countFilteredTotal(this.searchTerm)
          .subscribe((res: number) => {
            this.count = res;
          });
      });
    this.messageBusService.messageUpdateEmitter.subscribe(() => {
      this.service.list(this.searchTerm, this.config.limit, this.config.offset, this.orderby, ['New', 'Read'])
        .subscribe((res: Message[]) => {
          this.messages = res;
          this.service.countFilteredTotal(this.searchTerm)
            .subscribe((count: number) => {
              this.count = count;
            });
          this.service.countNew()
            .subscribe((count: number) => {
            });
        });
    });

  }

  onDelete(e, message: Message) {
    e.stopPropagation();
    if (!message) {
      return;
    }
    const index = this.messages.findIndex(x => x.id === message.id);
    this.messages.splice(index, 1);
    message.status = 'Deleted';
    this.service
      .update(message)
      .subscribe((result) => {
        this.service.list(this.searchTerm, this.config.limit, this.config.offset, this.orderby, ['New', 'Read'])
          .subscribe((res: Message[]) => {
            this.messages = res;
            this.service.countFilteredTotal(this.searchTerm)
              .subscribe((count: number) => {
                this.count = count;
              });
            this.service.countNew()
              .subscribe((count: number) => {
              });
          });
      });
  }

  setAsRead(message: Message) {
    if (!message) {
      return;
    }
    message.status = 'Read';
    this.service
      .update(message)
      .subscribe((result) => {
        const index = this.messages.findIndex(x => x.id === message.id);
        if (index !== -1) {
          this.messages.find(x => x.id === message.id).status = message.status;
        }
        this.service.countNew()
          .subscribe((res: number) => {
          });
      });
  }

  openSelected(message: Message) {
    if (!message) {
      return;
    }
    if (message.status === 'New') {
      this.setAsRead(message);
    }
    this.currentMessage = message.id;
  }

  closeSelected(message: Message) {
    if (message.id === this.currentMessage) {
      this.router.navigate(['/messages', this.params()]);
    }
    this.currentMessage = null;
  }

  params(message?: Message) {
    const id = message ? message.id : null;
    const snapshotParams = this.route.snapshot.params;
    const preservedParams = Object.assign({}, snapshotParams, { id: id });

    return preservedParams;
  }

  isSelected(message: Message) {
    return message.id === this.currentMessage;
  }

}
