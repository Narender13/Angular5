import { Component, Input } from '@angular/core';

import { Message } from '../../shared/models/message.model';

@Component({
  selector: 'app-message-list',
  templateUrl: './message-list.component.html',
  styleUrls: []
})
export class MessageListComponent {
  @Input() limit = 5;
  @Input() messages: Message[];

  constructor() { }
}
