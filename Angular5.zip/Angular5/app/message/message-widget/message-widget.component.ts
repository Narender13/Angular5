import { Component, OnInit } from '@angular/core';

import { Message } from '../../shared/models/message.model';
import { MessageService } from '../../message/shared/message.service';
import { UserService } from '../../shared/services/user.service';
import { MessageBusService } from '../../shared/message-bus/shared/message-bus.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-message-widget',
  templateUrl: './message-widget.component.html',
  styleUrls: ['./message-widget.component.scss']
})
@AutoUnsubscribe()
@Configure('MessageWidgetComponent')
export class MessageWidgetComponent implements Configurable, OnInit {
  config: any;
  limit = 3;
  count = 0;
  offset = 0;
  messages: Message[];
  usable: boolean;

  constructor(
    private userService: UserService,
    private service: MessageService,
    private messageBusService: MessageBusService
  ) { }

  ngOnInit() {
    this.userService.userLoaded()
      .subscribe(user => {
        this.config.limit = this.config.cardLimit || this.limit;
        this.config.offset = this.offset;
        this.init();
      });
  }

  init() {
    this.service.countNew()
      .subscribe((res: number) => {
        this.count = res;
      });
    this.service.newMessages$.subscribe(
      count => {
        this.count = count;
        // when count changes, refresh here
        this.service.list('', this.config.limit, this.config.offset, '', ['New'])
          .subscribe((res: Message[]) => {
            this.messages = res;
          });
      });
    this.messageBusService.messageUpdateEmitter.subscribe(() => {
      this.service.countNew()
        .subscribe((res: number) => {
          this.count = res;
        });
      this.service.list('', this.config.limit, this.config.offset, '', ['New'])
        .subscribe((res: Message[]) => {
          this.messages = res;
        });
    });
  }
}
