import { Component, Input } from '@angular/core';

import { FundValue } from '../../shared/models/fund-value.model';

@Component({
  selector: 'app-fund-value-list',
  templateUrl: './fund-value-list.html',
  styles: []
})
export class FundValueListComponent {
  @Input() fundValues: FundValue[];

  constructor() {}
}
