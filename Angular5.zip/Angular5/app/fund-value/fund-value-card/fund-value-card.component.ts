import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { FundValue } from '../../shared/models/fund-value.model';
import { FundValueService } from 'app/fund-value/shared/fund-value.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-fund-value-card',
  templateUrl: './fund-value-card.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('FundValueCardComponent')
export class FundValueCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  fundValues: Observable<FundValue[]>;
  limit = 5;
  usable: any;

  constructor(
    private route: ActivatedRoute,
    private service: FundValueService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;
    this.limit = this.config.cardLimit || this.limit;
    this.fundValues = this.service.grouped(contractId, this.limit).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
