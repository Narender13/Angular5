import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, tap, switchMap } from 'rxjs/operators';

import { AutoUnsubscribe } from 'app/shared/decorators/autounsubscribe';
import { Configurable, Configure } from 'app/shared/decorators/configurable';
import { FundValue } from 'app/shared/models/fund-value.model';
import { FundValueService } from 'app/fund-value/shared/fund-value.service';
import { UsdCurrencyPipe } from '../../shared/locale/usd-currency.pipe';

@Component({
  selector: 'app-fund-value-grid',
  templateUrl: './fund-value-grid.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('FundValueGridComponent')
export class FundValueGridComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  hasAssetSources = false;
  hasInterestRates = false;
  list: Observable<FundValue[]>;
  loading = true;
  pieChartData: number[] = [];
  pieChartLabels: string[] = [];
  pieChartOptions: any;
  sortFields: string[] = [
    'fundName Asc',
    'fundName Desc',
    'units Asc',
    'units Desc',
    'unitValue Asc',
    'unitValue Desc',
    'amount Asc',
    'amount Desc'
  ];
  totalAmount: number;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: FundValueService,
    private usdPipe: UsdCurrencyPipe
  ) { }

  ngOnInit() {
    this.initChart();
    this.list = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { contractId: string, orderby: string }) => {
        this.config.orderby = params.orderby || this.config.orderby || this.sortFields[0];
        return this.service.list(params.contractId, this.config.orderby);
      }),
      tap(data => {
        this.totalAmount = data.reduce((sum, f) => sum += f.amount, 0);
        this.hasAssetSources = data.some(f => !!f.assetSource);
        this.hasInterestRates = data.some(f => !!f.interestRate);
        const grouped = this.service.group(data);
        this.pieChartData = grouped.map(f => f.amount);
        this.pieChartLabels = grouped.map(f => f.fundName);
      }),
      tap(() => this.loading = false),
      share()
    );
    this.count = this.service.count().pipe(share());
  }

  initChart() {
    this.pieChartOptions = Object.assign({}, this.config.pieChartOptions, {
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => {
            const amount = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
            return this.usdPipe.transform(amount);
          }
        }
      }
    });
  }
}
