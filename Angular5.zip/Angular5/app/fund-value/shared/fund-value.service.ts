import { Injectable } from '@angular/core';
import { URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map, tap } from 'rxjs/operators';

import { FundValue } from '../../shared/models/fund-value.model';
import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class FundValueService {
  private apiUrl = 'fundvalues/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, orderby: string): Observable<FundValue[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('contractid', search);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => res.json() as FundValue[]),
      tap(data => this.lastCount.next(data.length)),
      map(data => this.sort(data, orderby)),
      catchError(this.loggingService.handleError));
  }

  grouped(search: string, limit: number): Observable<FundValue[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('contractid', search);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => res.json() as FundValue[]),
      map(data => this.group(data)),
      tap(data => this.lastCount.next(data.length)),
      map(data => this.sort(data)),
      map(data => data.slice(0, limit || data.length)),
      catchError(this.loggingService.handleError));
  }

  group(fundValues: FundValue[]): FundValue[] {
    return fundValues.reduce((memo, f) => {
      const groupedFund = memo.find(g => g.fundName === f.fundName);
      if (groupedFund === undefined) {
        memo.push(new FundValue (f));
      } else {
        groupedFund.amount += f.amount;
      }
      return memo;
    }, []);
  }

  private sort(fundValues: FundValue[], orderby = 'amount'): FundValue[] {
    const orderbyFragments = orderby.split(' ');
    const f = orderbyFragments[0];
    const dir = orderbyFragments[1];

    fundValues = fundValues.sort((a: FundValue, b: FundValue): number => {
      const valueA = a[f];
      const valueB = b[f];

      switch (f) {
        case 'units':
        case 'unitValue':
        case 'amount':
          return valueA - valueB;
        default:
          if (valueA < valueB) { return -1; }
          if (valueA > valueB) { return 1; }
          return 0;
      }
    });

    if (dir === 'Desc') {
      fundValues = fundValues.reverse();
    }
    return fundValues;
  }
}
