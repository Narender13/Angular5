import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FundValue } from '../../../app/shared/models/fund-value.model';
import { FundValueService } from '../shared/fund-value.service';

@Component({
  selector: 'app-fund-value-chip',
  templateUrl: './fund-value-chip.html',
  styles: [':host{width:100%;}']
})
export class FundValueChipComponent implements OnInit {
  @Input() fundValue: FundValue;
  attrs: string[];
  subscription: any;
  paramsSubscription: any;

  constructor(private route: ActivatedRoute, private service: FundValueService) { }

  ngOnInit() {
  }

}
