import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { FundValueCardComponent } from './fund-value-card/fund-value-card.component';
import { FundValueChipComponent } from './fund-value-chip/fund-value-chip.component';
import { FundValueGridComponent } from './fund-value-grid/fund-value-grid.component';
import { FundValueListComponent } from './fund-value-list/fund-value-list.component';
import { FundValueRoutingModule } from './fund-value-routing.module';
import { FundValueService } from './shared/fund-value.service';
import { SharedModule } from '../shared/shared.module';
import { UsdCurrencyPipe } from '../shared/locale/usd-currency.pipe';

@NgModule({
  declarations: [
    FundValueCardComponent,
    FundValueChipComponent,
    FundValueGridComponent,
    FundValueListComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    FundValueRoutingModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [FundValueCardComponent],
  providers: [
    FundValueService,
    UsdCurrencyPipe
  ]
})
export class FundValueModule { }
