import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FundValueGridComponent } from './fund-value-grid/fund-value-grid.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const fundValueRoutes: Routes = [
  {
    path: 'contracts/:contractId/fund-values', component: FundValueGridComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(fundValueRoutes)],
  exports: [RouterModule]
})
export class FundValueRoutingModule { }
