import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './register-confirm.html',
  styleUrls: ['./register-confirm.component.scss']

})
export class RegisterConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.info('Initing register-confirm.component.');
  }
}