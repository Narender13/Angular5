import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { Alias } from '../../shared/models/alias.model';
import { AliasService } from '../../shared/services/alias.service';
import { regexValidator } from '../../register/shared/regex.validator';
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-delegation-chip',
  templateUrl: './delegation-chip.component.html',
  styles: [':host{width:100%;}']
})
export class DelegationChipComponent implements OnInit {
  @Input() delegation: Alias;
  @Input() isDelegator: boolean;
  @Output() remove: EventEmitter<Alias> = new EventEmitter<Alias>();

  delegateActions: FormGroup;
  showCode = false;
  error = '';
  busy = false;

  constructor(
    private aliasService: AliasService,
    private fb: FormBuilder,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.delegateActions = this.fb.group({
      verificationCode: ['',
      [
        regexValidator(/^[0-9]{5}$/, 'number', 'Must be a 5 digint number between 00000 and 99999.')
      ]]
    });
  }

  terminate() {
    this.busy = true;
    this.aliasService.terminate(this.delegation).subscribe(d => {
      this.busy = false;
      this.delegation = d;
      this.remove.emit(d);
    }, (errResp: any) => {
      this.busy = false;
      this.error = errResp.message;
    });
  }

  preAccept() {
    this.showCode = true;
  }

  accept() {
    const code = this.delegateActions.get('verificationCode').value;
    this.error = '';
    this.busy = true;
    this.aliasService.acceptDelegation(this.delegation.id.toString(), code).subscribe(d => {
      this.busy = false;
      this.delegation = d;
      this.showCode = false;
    }, (errResp: any) => {
      this.busy = false;
      this.error = errResp.message;
    });
  }

  assume() {
    this.busy = true;
    this.error = '';
    this.aliasService.becomeDelegate(this.delegation.id).subscribe(d => {
      this.delegation = d;
      this.busy = false;
    }, (errResp: any) => {
      this.busy = false;
      this.error = errResp.message;
    });
  }

  beYourself () {
    this.busy = true;
    this.error = '';
    this.aliasService.beYourself().subscribe(d => {
      this.delegation.active = false;
      this.busy = false;
    }, (errResp: any) => {
      this.busy = false;
      this.error = errResp.message;
    });
  }
}
