import { Component, Input, OnInit } from '@angular/core';
import { AliasService } from '../../shared/services/alias.service';
import { ActivatedRoute } from '@angular/router';

import { Alias } from '../../shared/models/alias.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-delegation-detail',
  templateUrl: './delegation-detail.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('DelegationDetailComponent')
export class DelegationDetailComponent implements Configurable, OnInit {
  code: string;
  config: any;
  @Input() delegation: Alias;
  usable: any;

  constructor(
    private aliasService: AliasService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string, code: string };
    const aliasId = routeParams.id;
    this.code = routeParams.code;

    if (aliasId) {
      if (this.code) { // accept
        this.aliasService.acceptDelegation(aliasId, this.code).subscribe(d => {
          this.delegation = d;
        });
      } else { // go get it so user can input code
        this.aliasService.find(aliasId).subscribe(item => {
          this.delegation = item;
        });
      }
    }

  }

  accept(code: string) {
    // const code = this.delegateActions.get('verificationCode').value;
    this.aliasService.acceptDelegation(this.delegation.id.toString(), code).subscribe(d => {
      this.delegation = d;
      // this.showCode = false;
    });
  }

}
