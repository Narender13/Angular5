import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DelegationCardComponent } from './delegation-card/delegation-card.component';
import { DelegationChipComponent } from './delegation-chip/delegation-chip.component';
import { DelegationListComponent } from './delegation-list/delegation-list.component';
import { AliasService } from '../shared/services/alias.service';
import { SharedModule } from '../shared/shared.module';
import { DelegationDetailComponent } from './delegation-detail/delegation-detail.component';
import { DelegationRoutingModule } from './delegation-routing.module';

@NgModule({
  imports: [
    CommonModule,
    DelegationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  declarations: [
    DelegationCardComponent,
    DelegationChipComponent,
    DelegationListComponent,
    DelegationDetailComponent
  ],
  providers: [
    AliasService
  ],
  exports: [
    DelegationCardComponent
  ]
})
export class DelegationModule { }
