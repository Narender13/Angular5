import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { DelegationDetailComponent } from './delegation-detail/delegation-detail.component';

const routes: Routes = [
  { path: 'delegations/:id', component: DelegationDetailComponent, canActivate: [AuthGuardService] },
  { path: 'delegations/:id/accept/:code', component: DelegationDetailComponent, canActivate: [AuthGuardService] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DelegationRoutingModule { }
