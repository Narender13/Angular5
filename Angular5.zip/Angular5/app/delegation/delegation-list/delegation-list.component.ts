import { Component, Input } from '@angular/core';

import { Alias } from '../../shared/models/alias.model';

@Component({
  selector: 'app-delegation-list',
  templateUrl: './delegation-list.component.html',
  styles: []
})
export class DelegationListComponent {
  @Input() delegations: Alias[];
  @Input() isDelegator: boolean;

  constructor() { }

  removeItem(item: Alias) {
    this.delegations = this.delegations.filter(d => d.id !== item.id);
  }

}
