import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Alias } from '../../shared/models/alias.model';
import { AliasService } from '../../shared/services/alias.service';
import { AuthGuardService } from '../../shared/services/auth-guard.service';
import { regexValidator } from '../../register/shared/regex.validator';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-delegation-card',
  templateUrl: './delegation-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('DelegationCardComponent')
export class DelegationCardComponent implements Configurable, OnInit {
  busy = false;
  config: any;
  delegations: Alias[];
  inviteError: any;
  isDelegator: boolean;
  mode = '';
  newForm: FormGroup;
  usable: any;

  constructor(
    private fb: FormBuilder,
    private aliasService: AliasService,
    private userService: UserService,

    private guardService: AuthGuardService
  ) { }

  ngOnInit() {
    this.isDelegator = this.userService.isInRole('delegator');
    if (this.isDelegator) {
      this.aliasService.delegatees().subscribe(d => {
        this.delegations = d;
      });
    } else {
      this.aliasService.delegators().subscribe(d => {
        this.delegations = d;
      });
    }

    this.createForm();
  }

  createForm() {
    this.newForm = this.fb.group({
      aliasEmail: ['',
        [
          regexValidator(/^.+@.+\..+$/, 'email', 'Must be a valid email address.'),
          Validators.required
        ]]
    });
  }

  onSubmit() {
    this.busy = true;
    this.inviteError = '';
    this.aliasService.nominateDelegate(this.newForm.get('aliasEmail').value)
      .subscribe((res: Alias) => {
        this.delegations.push(res);
        this.toggleEditor();
        this.busy = false;
      }, (errResp: any) => {
        this.busy = false;
        this.inviteError = errResp.message;
      });
  }

  toggleEditor() {
    this.mode = this.mode === 'add' ? '' : 'add';
  }
}
