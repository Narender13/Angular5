import { Injectable } from '@angular/core';
import { Response, URLSearchParams, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { Document } from '../../shared/models/document.model';
import { Paginated } from '../../shared/models/paginated.interface';
import { Subject } from 'rxjs/Subject';
import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';
import { Router, ActivatedRoute } from '@angular/router/router';
import { map, catchError, finalize } from 'rxjs/operators';

@Injectable()
export class DocumentService {
  private apiUrl = 'Documents/';
  private router: Router;
  private route: ActivatedRoute;
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(limit: number, offset: number, orderby: string, contractId?: string, search?: string): Observable<Document[]> {
    const params = new URLSearchParams();

    if (contractId) {
      params.set('contractId', contractId);
    }

    if (search) {
      params.set('documentType', search);
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError)
    );
  }
  commissions(limit?: number, offset?: number, orderby?: string): Observable<Document[]> {
    const params = new URLSearchParams();

    params.set('documentType', 'commission');

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError)
    );
  }

  find(id): Observable<Document> {
    return this.http.authGet(this.apiUrl + id)
      .pipe(map(res => res.json() as Document),
        catchError(this.loggingService.handleError));
  }

  download(id): Observable<boolean> {
    const options = {
      responseType: ResponseContentType.Blob
    };
    return this.http.authDownload(`${this.apiUrl}${id}/download`, id, options).pipe(
      catchError(this.loggingService.handleError)
    );
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.apiUrl}export?format=csv`, 'commissions.csv', options).pipe(
      catchError(this.loggingService.handleError),
      finalize(() => {
        const url = this.router.createUrlTree([], { queryParams: {}, skipLocationChange: true, relativeTo: this.route });
        this.router.navigateByUrl(url);
      })
    );
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<Document>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }

}
