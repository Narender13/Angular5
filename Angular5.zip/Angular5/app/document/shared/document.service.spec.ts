
import { TestBed, inject } from '@angular/core/testing';
import { DocumentService } from './document.service';
import { HttpModule } from '@angular/http';

describe('DocumentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [DocumentService]
    });
  });

  it('should ...', inject([DocumentService], (service: DocumentService) => {
    expect(service).toBeTruthy();
  }));
});
