
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';

import { DocumentCardComponent } from '../document-card/document-card.component';
import { SharedModule } from '../../shared/shared.module';
import { DocumentService } from '../shared/document.service';
import { CommonModule } from '@angular/common';
import { DocumentRoutingTestModule } from '../document-routing-test.module';
import { DocumentSearchComponent } from '../document-search/document-search.component';

import { DocumentDetailComponent } from './document-detail.component';
import { DocumentGridComponent } from '../document-grid/document-grid.component';

describe('DocumentDetailComponent', () => {
  let component: DocumentDetailComponent;
  let fixture: ComponentFixture<DocumentDetailComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, SharedModule, DocumentRoutingTestModule, HttpModule],
      declarations: [
        DocumentCardComponent,
        DocumentDetailComponent,
        DocumentSearchComponent,
        DocumentGridComponent
      ],
      providers: [DocumentService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    // query for the title <h1> by CSS element selector
    de = fixture.debugElement.query(By.css('.card-title'));
    el = de.nativeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
