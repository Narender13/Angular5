import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';


import { Document } from '../../shared/models/document.model';
import { ContractDocumentService } from 'app/document/shared/contractDocument.service';

@Component({
  selector: 'app-document-detail',
  templateUrl: './document-detail.html',
  styleUrls: []
})
export class DocumentDetailComponent implements OnInit {
  attrs: string[];
  subscription: any;
  paramsSubscription: any;
  document: Document;
  file: any;

  constructor(private route: ActivatedRoute, private service: ContractDocumentService) { }

  ngOnInit() {
    this.paramsSubscription = this.route.params.subscribe((params: { id: string, contractId: string }) => {
      if (params.id !== undefined) {
        const id = +params.id;
        this.subscription = this.service
          .find(id, params.contractId)
          .subscribe((p) => {
            this.document = p;
            this.attrs = Object.keys(p);
          });
      }
    });
  }

  download(documentId) {
    const params = this.route.snapshot.params as { contractId: string };
    const contractId = params.contractId;
    this.service.download(documentId, contractId).subscribe((res: any) => { });
  }

  getValue(key: string): any {
    return this.document[key];
  }
}
