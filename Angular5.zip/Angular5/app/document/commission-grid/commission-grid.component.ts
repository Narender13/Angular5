import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';



import { Document } from '../../shared/models/document.model';
import { DocumentService } from '../shared/document.service';
import { LoggingService } from 'app/shared/logging/logging.service';
import { ToolbarActionHandlers } from '../../shared/services/toolbar-action-handler';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-commission-grid',
  templateUrl: './commission-grid.component.html',
  styles: [],
  encapsulation: ViewEncapsulation.None
})
@AutoUnsubscribe()
@Configure('CommissionGridComponent')
export class CommissionGridComponent implements Configurable, OnInit {
  activity: Observable<Document[]>;
  config: any;
  documents: Observable<Document[]>;
  count: Observable<number>;
  loading = true;
  sortFields: string[] = [
    'dateCreated Asc',
    'dateCreated Desc',
    'documentType Asc',
    'documentType Desc'
  ];
  tools = ['print', 'export'];
  usable: boolean;
  activeTool: string;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: DocumentService,
    private logging: LoggingService
  ) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.documents = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { q: string, limit: number, offset: number, orderby: string }) => {
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        this.config.orderby = params.orderby || this.config.orderby;
        return this.service.commissions(this.config.limit, this.config.offset, this.config.orderby);
      }),
      tap(() => this.loading = false),
      share()

    );

    ToolbarActionHandlers.handle(this);
  }

  onExport(): Observable<any> {
    return this.service.export();
  }

}
