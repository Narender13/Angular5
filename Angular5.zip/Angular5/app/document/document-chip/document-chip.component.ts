import { Component, OnInit, Input } from '@angular/core';
import { Document } from '../../shared/models/document.model';


@Component({
  selector: 'app-document-chip',
  templateUrl: './document-chip.html',
  styles: [':host{width:100%;}']
})
export class DocumentChipComponent implements OnInit {
  @Input() document: Document;
  attrs: string[];

  constructor() { }
  ngOnInit() {

  }

}

