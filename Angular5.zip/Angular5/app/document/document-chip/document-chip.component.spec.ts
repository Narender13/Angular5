
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { SharedModule } from '../../shared/shared.module';
import { CommonModule } from '@angular/common';

import { DocumentChipComponent } from './document-chip.component';
import { DocumentService } from '../shared/document.service';
import { DocumentRoutingTestModule } from '../document-routing-test.module';
import { DocumentDetailComponent } from '../document-detail/document-detail.component';
import { DocumentCardComponent } from '../document-card/document-card.component';
import { DocumentSearchComponent } from '../document-search/document-search.component';
import { DocumentGridComponent } from '../document-grid/document-grid.component';

describe('DocumentChipComponent', () => {
  let component: DocumentChipComponent;
  let fixture: ComponentFixture<DocumentChipComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpModule, CommonModule, SharedModule, DocumentRoutingTestModule],
      declarations: [
        DocumentChipComponent,
        DocumentDetailComponent,
        DocumentCardComponent,
        DocumentSearchComponent,
        DocumentGridComponent
      ],
      providers: [DocumentService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    // query for the title
    de = fixture.debugElement.query(By.css('.chip-header'));
    el = de.nativeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
