import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { Document } from '../../shared/models/document.model';
import { ContractDocumentService } from 'app/document/shared/contractDocument.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-document-card',
  templateUrl: './document-card.html',
  styleUrls: []
})
@AutoUnsubscribe()
@Configure('DocumentCardComponent')
export class DocumentCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  documents: Observable<Document[]>;
  limit = 5;
  usable: any;

  constructor(
    private route: ActivatedRoute,
    private service: ContractDocumentService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;
    this.limit = this.config.cardLimit || this.limit;
    this.documents = this.service.list(this.limit, 0, this.config.orderby, contractId).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
