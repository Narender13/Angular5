
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';

import { DocumentCardComponent } from './document-card.component';
import { SharedModule } from '../../shared/shared.module';
import { DocumentService } from '../shared/document.service';
import { CommonModule } from '@angular/common';
import { DocumentRoutingTestModule } from '../document-routing-test.module';
import { DocumentDetailComponent } from '../document-detail/document-detail.component';
import { DocumentSearchComponent } from '../document-search/document-search.component';
import { DocumentGridComponent } from '../document-grid/document-grid.component';

describe('DocumentCardComponent', () => {
  let component: DocumentCardComponent;
  let fixture: ComponentFixture<DocumentCardComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, SharedModule, DocumentRoutingTestModule, HttpModule],
      declarations: [
        DocumentCardComponent,
        DocumentDetailComponent,
        DocumentSearchComponent,
        DocumentGridComponent
      ],
      providers: [DocumentService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentCardComponent);
    component = fixture.componentInstance;
    // query for the title <h1> by CSS element selector
    de = fixture.debugElement.query(By.css('.card-title'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
