import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { DocumentCardComponent } from './document-card/document-card.component';
import { DocumentDetailComponent } from './document-detail/document-detail.component';

const documentRoutes: Routes = [{
    path: 'documents/:id',
    component: DocumentDetailComponent
},
{
    path: 'documents',
    component: DocumentCardComponent
}];

@NgModule({
    imports: [RouterTestingModule.withRoutes(documentRoutes)],
    exports: [RouterTestingModule]
})
export class DocumentRoutingTestModule { }
