import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DocumentService } from '../shared/document.service';

import { Document } from '../../shared/models/document.model';

@Component({
  selector: 'app-commission-detail',
  templateUrl: './commission-detail.component.html',
  styles: [],
  encapsulation: ViewEncapsulation.None
})
export class CommissionDetailComponent implements OnInit {
  attrs: string[];
  subscription: any;
  paramsSubscription: any;
  document: Document;
  file: any;

  constructor(private route: ActivatedRoute, private service: DocumentService) { }

  ngOnInit() {
    this.paramsSubscription = this.route.params.subscribe((params: { id: string }) => {
      if (params.id !== undefined) {
        const id = +params.id;
        this.subscription = this.service
          .find(id)
          .subscribe((p) => {
            this.document = p;
            this.attrs = Object.keys(p);
          });
      }
    });
  }

  download(documentId) {
    this.service.download(documentId).subscribe((res: any) => { });
  }

  getValue(key: string): any {
    return this.document[key];
  }
}
