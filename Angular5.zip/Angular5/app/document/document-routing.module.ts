import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { DocumentGridComponent } from './document-grid/document-grid.component';
import { DocumentDetailComponent } from './document-detail/document-detail.component';
import { CommissionGridComponent } from 'app/document/commission-grid/commission-grid.component';
import { CommissionDetailComponent } from 'app/document/commission-detail/commission-detail.component';

const documentRoutes: Routes = [
  {
    path: 'contracts/:contractId/documents', component: DocumentGridComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: 'contracts/:contractId/documents/:id', component: DocumentDetailComponent,
    canActivate: [AuthGuardService]
  },
  {
  path: 'commissions', component: CommissionGridComponent,
  canActivate: [AuthGuardService]
},
  {
  path: 'commissions/:id', component: CommissionDetailComponent,
  canActivate: [AuthGuardService]
},
];

@NgModule({
  imports: [RouterModule.forChild(documentRoutes)],
  exports: [RouterModule]
})
export class DocumentRoutingModule { }
