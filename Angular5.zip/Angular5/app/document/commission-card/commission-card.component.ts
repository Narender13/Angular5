import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { Document } from '../../shared/models/document.model';
import { DocumentService } from '../shared/document.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-commission-card',
  templateUrl: './commission-card.component.html',
  styles: [],
  encapsulation: ViewEncapsulation.None
})
@AutoUnsubscribe()
@Configure('CommissionCardComponent')
export class CommissionCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  documents: Observable<Document[]>;
  limit = 5;
  usable: any;

  constructor(
    private route: ActivatedRoute,
    private service: DocumentService
  ) { }

  ngOnInit() {
    this.limit = this.config.cardLimit || this.limit;
    this.documents = this.service.commissions(this.limit, 0, this.config.orderby).pipe(share());
    this.count = this.service.count().pipe(share());
  }

}
