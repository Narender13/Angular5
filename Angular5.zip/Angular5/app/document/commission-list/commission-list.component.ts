import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { Document } from '../../shared/models/document.model';

@Component({
  selector: 'app-commission-list',
  templateUrl: './commission-list.component.html',
  styles: [],
  encapsulation: ViewEncapsulation.None
})
export class CommissionListComponent implements OnInit {
  @Input() documents: Document[];

  constructor() { }

  ngOnInit() {
  }

}
