
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { DocumentGridComponent } from './document-grid.component';
import { SharedModule } from '../../shared/shared.module';
import { DocumentRoutingTestModule } from '../document-routing-test.module';
import { DocumentDetailComponent } from '../document-detail/document-detail.component';
import { DocumentCardComponent } from '../document-card/document-card.component';
import { DocumentSearchComponent } from '../document-search/document-search.component';
import { DocumentService } from '../shared/document.service';
import { HttpModule } from '@angular/http';

const documentServiceStub = {
  id: 1,
  contractNumber: '123876',
  docID: 'abc876'
};

describe('DocumentGridComponent', () => {
  let component: DocumentGridComponent;
  let fixture: ComponentFixture<DocumentGridComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule, DocumentRoutingTestModule, HttpModule],
      declarations: [
        DocumentDetailComponent,
        DocumentCardComponent,
        DocumentSearchComponent,
        DocumentGridComponent
      ],
      // providers: [DocumentService]    // use dummy service
      providers: [{ provide: DocumentService, useValue: documentServiceStub }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentGridComponent);
    component = fixture.componentInstance;
    // query for the title <h1> by CSS element selector
    de = fixture.debugElement.query(By.css('h1'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
