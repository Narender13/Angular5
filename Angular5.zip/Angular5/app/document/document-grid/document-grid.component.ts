import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { Document } from '../../shared/models/document.model';
import { ContractDocumentService } from '../shared/contractDocument.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-document-grid',
  templateUrl: './document-grid.html',
  styleUrls: ['./document-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('DocumentGridComponent')
export class DocumentGridComponent implements Configurable, OnInit {
  config: any;
  documents: Observable<Document[]>;
  count: Observable<number>;
  loading = true;
  sortFields: string[] = [
    'dateCreated Asc',
    'dateCreated Desc',
    'documentType Asc',
    'documentType Desc'];
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: ContractDocumentService
  ) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.documents = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { contractId: string, q: string, limit: number, offset: number, orderby: string }) => {
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        this.config.orderby = params.orderby || this.config.orderby;
        return this.service.list(this.config.limit, this.config.offset, this.config.orderby, params.contractId, params.q);
      }),
      tap(() => this.loading = false),
      share()
    );
  }
}
