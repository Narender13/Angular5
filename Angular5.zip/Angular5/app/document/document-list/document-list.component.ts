import { Component, Input } from '@angular/core';

import { Document } from '../../shared/models/document.model';

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.html',
  styleUrls: ['./document-list.component.scss']
})
export class DocumentListComponent {
  @Input() documents: Document[];

  constructor() { }
}
