
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { DocumentListComponent } from './document-list.component';
import { SharedModule } from '../../shared/shared.module';
import { DocumentRoutingTestModule } from '../document-routing-test.module';
import { DocumentDetailComponent } from '../document-detail/document-detail.component';
import { DocumentCardComponent } from '../document-card/document-card.component';
import { DocumentSearchComponent } from '../document-search/document-search.component';
import { DocumentChipComponent } from '../document-chip/document-chip.component';
import { DocumentService } from '../shared/document.service';
import { HttpModule } from '@angular/http';
import { DocumentGridComponent } from '../document-grid/document-grid.component';

const documentServiceStub = {
  id: 1,
  documentNumber: 'abc876',
  firstName: 'Adam',
  lastName: 'Ant'
};

describe('DocumentListComponent', () => {
  let component: DocumentListComponent;
  let fixture: ComponentFixture<DocumentListComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule, DocumentRoutingTestModule, HttpModule],
      declarations: [
        DocumentDetailComponent,
        DocumentCardComponent,
        DocumentSearchComponent,
        DocumentListComponent,
        DocumentChipComponent,
        DocumentGridComponent
      ],
      // providers: [DocumentService]    // use dummy service
      providers: [{ provide: DocumentService, useValue: documentServiceStub }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentListComponent);
    component = fixture.componentInstance;
    // query for the title <h1> by CSS element selector
    de = fixture.debugElement.query(By.css('.list-group'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
