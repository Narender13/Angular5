import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { Document } from '../../shared/models/document.model';

@Component({
  selector: 'app-commission-chip',
  templateUrl: './commission-chip.component.html',
  styles: [],
  encapsulation: ViewEncapsulation.None
})
export class CommissionChipComponent implements OnInit {
   @Input() document: Document;
   attrs: string[];

  constructor() { }

  ngOnInit() {
  }

}
