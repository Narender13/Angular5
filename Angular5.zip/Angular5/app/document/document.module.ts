import { CommissionCardComponent } from './commission-card/commission-card.component';
import { CommissionChipComponent } from './commission-chip/commission-chip.component';
import { CommissionDetailComponent } from './commission-detail/commission-detail.component';
import { CommissionGridComponent } from './commission-grid/commission-grid.component';
import { CommissionListComponent } from './commission-list/commission-list.component';
import { CommonModule } from '@angular/common';
import { DocumentCardComponent } from './document-card/document-card.component';
import { DocumentChipComponent } from './document-chip/document-chip.component';
import { DocumentDetailComponent } from './document-detail/document-detail.component';
import { DocumentGridComponent } from './document-grid/document-grid.component';
import { DocumentListComponent } from './document-list/document-list.component';
import { DocumentRoutingModule } from './document-routing.module';
import { ContractDocumentService } from 'app/document/shared/contractDocument.service';
import { DocumentService } from './shared/document.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    CommissionCardComponent,
    CommissionChipComponent,
    CommissionDetailComponent,
    CommissionGridComponent,
    CommissionListComponent,
    DocumentCardComponent,
    DocumentChipComponent,
    DocumentDetailComponent,
    DocumentGridComponent,
    DocumentListComponent,

  ],
  imports: [
    CommonModule,
    DocumentRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [
    CommissionCardComponent,
    DocumentCardComponent,
    DocumentChipComponent,

  ],
  providers: [DocumentService, ContractDocumentService]
})
export class DocumentModule { }
