import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-message-detail',
  templateUrl: './admin-message-detail.component.html',
  styleUrls: ['./admin-message-detail.component.scss']
})

export class AdminMessageDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
