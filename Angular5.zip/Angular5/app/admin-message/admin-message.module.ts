import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AdminMessageCardComponent } from './admin-message-card/admin-message-card.component';
import { AdminMessageChipComponent } from './admin-message-chip/admin-message-chip.component';
import { AdminMessageDetailComponent } from './admin-message-detail/admin-message-detail.component';
import { AdminMessageGridComponent } from './admin-message-grid/admin-message-grid.component';
import { AdminMessageListComponent } from './admin-message-list/admin-message-list.component';
import { AdminMessageRoutingModule } from './admin-message-routing.module';
import { AdminMessageService } from './shared/admin-message.service';
import { PopoverModule } from 'ngx-popover';
import { SharedModule } from '../shared/shared.module';
import { AdminMessageEditComponent } from './admin-message-edit/admin-message-edit.component';

@NgModule({
  declarations: [
    AdminMessageCardComponent,
    AdminMessageChipComponent,
    AdminMessageDetailComponent,
    AdminMessageGridComponent,
    AdminMessageListComponent,
    AdminMessageEditComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    PopoverModule,
    ReactiveFormsModule,
    SharedModule,
    AdminMessageRoutingModule
  ],
  exports: [
    AdminMessageCardComponent,
    AdminMessageChipComponent,
    AdminMessageDetailComponent,
    AdminMessageGridComponent,
    AdminMessageListComponent
  ],
  providers: [
    AdminMessageService
  ]
})
export class AdminMessageModule { }
