import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../shared/services/auth-guard.service';
import { AdminMessageGridComponent } from './admin-message-grid/admin-message-grid.component';

const adminMessageRoutes: Routes = [
  {
    path: 'admin-messages',
    component: AdminMessageGridComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(adminMessageRoutes)],
  exports: [RouterModule]
})
export class AdminMessageRoutingModule { }
