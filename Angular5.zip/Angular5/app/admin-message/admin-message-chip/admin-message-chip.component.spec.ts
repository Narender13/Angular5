import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMessageChipComponent } from './admin-message-chip.component';

describe('AdminMessageChipComponent', () => {
  let component: AdminMessageChipComponent;
  let fixture: ComponentFixture<AdminMessageChipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMessageChipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMessageChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
