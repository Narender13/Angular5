import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

import { PushMessage } from '../../shared/models/message.model';

@Component({
  selector: 'app-admin-message-chip',
  templateUrl: './admin-message-chip.component.html',
  styles: [':host{width:100%;}']
})
export class AdminMessageChipComponent implements OnInit {
  @Input() message: PushMessage;
  audience: string[] = [];

  constructor() { }

  ngOnInit() {
    // model will potentially provide specific set of entities as audience for the message and not "All or none"
    // so audience is just a descriptor for the To: line and not included in the PushMessage model

    if (this.message.includeBrokerDealers) {
      this.audience.push('Broker/Dealers');
    }
    if (this.message.includeAgents) {
      this.audience.push('Agents');
    }
    if (this.message.includeConsumers) {
      this.audience.push('Consumers');
    }
  }
}
