import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMessageCardComponent } from './admin-message-card.component';

describe('AdminMessageCardComponent', () => {
  let component: AdminMessageCardComponent;
  let fixture: ComponentFixture<AdminMessageCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMessageCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMessageCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
