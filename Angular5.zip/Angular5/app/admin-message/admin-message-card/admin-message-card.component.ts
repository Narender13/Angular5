import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AdminMessageService } from '../shared/admin-message.service';
import { AuthGuardService } from '../../shared/services/auth-guard.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { PushMessage } from '../../shared/models/message.model';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-admin-message-card',
  templateUrl: './admin-message-card.component.html',
  styleUrls: ['./admin-message-card.component.scss']
})
@AutoUnsubscribe()
@Configure('AdminMessageCardComponent')
export class AdminMessageCardComponent implements Configurable, OnInit {
  config: any;
  usable: boolean;
  count: Observable<number>;
  currentUser: any;
  limit = 3;
  messages: Observable<PushMessage[]>;
  offset = 0;
  showFooter = false;

  constructor(
    private route: ActivatedRoute,
    private adminMessageService: AdminMessageService,
    private userService: UserService,
    private guardService: AuthGuardService) { }

  ngOnInit() {
    this.config.limit = this.config.cardLimit || this.limit;
    this.config.offset = this.offset;

    this.messages = this.adminMessageService.list(this.config.limit, this.config.offset, ['Active', 'Inactive'])
      .pipe(share());

    this.count = this.adminMessageService.countTotal(['Active', 'Inactive']).pipe(share());

    this.adminMessageService.countTotal(['Active', 'Inactive'])
      .subscribe(res => { this.showFooter = (res > this.config.limit) ? true : false; });
  }
}
