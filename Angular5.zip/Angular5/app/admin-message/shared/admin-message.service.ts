import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { map, catchError } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { PushMessage } from '../../shared/models/message.model';
import { UserService } from '../../shared/services/user.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class AdminMessageService {

  private path = 'pushmessages';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private userService: UserService, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  countTotal(filter: string[]): Observable<number> {
    const params = new URLSearchParams();
    if (filter.length) {
      for (const f of filter) {
        params.append('status', f);
      }
    }
    return this.http.authGet(this.path + '/count', { search: params }).pipe(
      map(this.extractCount, this),
      catchError(this.loggingService.handleError)
    );
  }

  list(limit: number, offset: number, filter: string[]): Observable<PushMessage[]> {
    const params = new URLSearchParams();
    params.set('orderby', 'createdon');
    params.set('direction', 'descending');
    if (offset) {
      params.set('skip', offset.toString());
    } else {
      params.set('skip', '0');
    }

    if (limit) {
      params.set('take', limit.toString());
    } else {
      params.set('take', '0');
    }

    if (filter.length) {
      for (const f of filter) {
        params.append('status', f);
      }
    }
    return this.http.authGet(this.path, { search: params }).pipe(
      map(res => this.extractData(res)),
      catchError(this.loggingService.handleError)
    );
  }

  create(s: PushMessage) {
    return this.http.authPost(this.path, s).pipe(
      map(res => this.extractData(res)),
      catchError(this.loggingService.handleError));
  }

  send(s: PushMessage) {
    return this.http.authPost(this.path + '/' + s.id + '/send', s).pipe(
      map(res => this.extractSend(res)),
      catchError(this.loggingService.handleError)
    );
  }

  update(s: PushMessage) {
    return this.http.authPut(this.path + '/' + s.id, s).pipe(
      map(res => this.extractData(res)),
      catchError(this.loggingService.handleError)
    );
  }

  delete(s: PushMessage) {
    s.status = 'Deleted';
    return this.update(s);
  }

  private extractData(res: Response) {
    const body = res.json();
    return body.items || {};
  }

  private extractSend(res: Response) {
    return res.ok;
  }

  private extractCount(res: Response) {
    const body = res.json() as number;
    this.lastCount.next(body || 0);
    return body || 0;
  }

}
