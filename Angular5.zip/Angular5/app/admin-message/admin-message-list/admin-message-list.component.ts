import { Component, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { PushMessage } from '../../shared/models/message.model';

@Component({
  selector: 'app-admin-message-list',
  templateUrl: './admin-message-list.component.html',
  styleUrls: ['./admin-message-list.component.scss']
})
export class AdminMessageListComponent {
  className = 'AdminMessageListComponent';
  config: any;
  currentUser: any;
  @Input() messages: Observable<PushMessage[]>;
  count: Observable<number>;

  constructor() { }
}
