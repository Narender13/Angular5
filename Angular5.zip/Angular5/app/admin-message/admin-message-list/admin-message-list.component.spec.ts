import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMessageListComponent } from './admin-message-list.component';

describe('AdminMessageListComponent', () => {
  let component: AdminMessageListComponent;
  let fixture: ComponentFixture<AdminMessageListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMessageListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMessageListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
