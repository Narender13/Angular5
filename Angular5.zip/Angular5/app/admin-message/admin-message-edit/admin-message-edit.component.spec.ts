import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMessageEditComponent } from './admin-message-edit.component';

describe('AdminMessageEditComponent', () => {
  let component: AdminMessageEditComponent;
  let fixture: ComponentFixture<AdminMessageEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMessageEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMessageEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
