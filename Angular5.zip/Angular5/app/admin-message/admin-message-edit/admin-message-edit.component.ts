import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { debounceTime } from 'rxjs/operators';

import { AdminMessageService } from '../shared/admin-message.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { ConfigService } from '../../shared/services/config.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { PushMessage } from '../../shared/models/message.model';
import { SubscriptionService } from '../../subscription/shared/subscription.service';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-admin-message-edit',
  templateUrl: './admin-message-edit.component.html',
  styleUrls: ['./admin-message-edit.component.scss']
})
@AutoUnsubscribe()
@Configure('AdminMessageEditComponent')
export class AdminMessageEditComponent implements Configurable, OnInit, OnChanges {
  @Input() message: PushMessage;
  @Output() pushMessageUpdated: EventEmitter<any> = new EventEmitter();
  audience = '';
  formModel: FormGroup;
  config: any;
  labels: any;
  messages: any;
  errors: any;
  usable: boolean;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private adminMessageService: AdminMessageService,
    private subscriptionService: SubscriptionService,
    private configService: ConfigService,
    private userService: UserService) { }

  ngOnInit() {
    // assign the message, labels, and errors 
    this.labels = this.config.translated.labels;
    this.errors = this.config.translated.errors;
    this.messages = this.config.translated.messages;
    // initialize model
    this.formModel = this.fb.group({
      'audience': [this.audience, [Validators.required]],
      'audienceGroup': this.fb.group({
        'includeBrokerDealers': [this.message.includeBrokerDealers ? true : false],
        'includeAgents': [this.message.includeAgents ? true : false],
        'includeConsumers': [this.message.includeConsumers ? true : false]
      }, { validator: Validators.required }),
      'subject': [this.message.subject, [Validators.required, Validators.minLength(4)]],
      'body': [this.message.body, [Validators.required, Validators.minLength(10)]],
      'active': [this.message.status === 'Active' ? true : false]
    });

    this.formModel.valueChanges.pipe(
      debounceTime(500)
    ).subscribe(() => this.compileErrors());

    // enable message inputs depending on whether audience is selected
    this.hasAudience();

    this.getPushMessages();
  }

  compileErrors(ignoreDirty?: boolean) {
    for (const field of Object.keys(this.errors)) {
      this.errors[field] = ''; // clear previous error message (if any)
      const control = this.getField(field);
      if (control && (control.dirty || ignoreDirty) && !control.valid) {

        for (const key of Object.keys(control.errors)) {
          this.errors[field] += this.messages[field][key];
        }
      }
    }
  }

  resetFormModel() {
    // reset model to defaults to prepare for adding new message
    // the 'ADD' event simply uncollapses the DOM element
    this.formModel.setValue({
      'audience': '1',
      'audienceGroup': {
        'includeBrokerDealers': false,
        'includeAgents': false,
        'includeConsumers': false
      },
      'subject': '',
      'body': '',
      'active': true
    });
    this.hasAudience();
  }

  setFormModel() {
    // when editing existing message, update model to initialize form
    this.formModel.setValue({
      'audience': '1',
      'audienceGroup': {
        'includeBrokerDealers': this.message.includeBrokerDealers ? true : false,
        'includeAgents': this.message.includeAgents ? true : false,
        'includeConsumers': this.message.includeConsumers ? true : false
      },
      'subject': this.message.subject,
      'body': this.message.body,
      'active': this.message.status === 'Active' ? true : false
    });
    this.hasAudience();
  }

  ngOnChanges() {
    if (!this.formModel) { return; }
    this.setFormModel();
  }

  getPushMessages() {
    this.pushMessageUpdated.emit();
  }

  saveMessage() {
    const form = this.formModel;

    if (!form.valid) {
      return this.compileErrors(true);
    }
    const s = new PushMessage();
    s.userId = 0;
    // todo eventually will be able to select specific brokers/agents/consumers
    // in the audience; for now, just set to All or none
    s.includeBrokerDealers = this.formModel.value.audienceGroup.includeBrokerDealers ? 'All' : '';
    s.includeAgents = this.formModel.value.audienceGroup.includeAgents ? 'All' : '';
    s.includeConsumers = this.formModel.value.audienceGroup.includeConsumers ? 'All' : '';
    s.subject = this.formModel.value.subject.replace(/\n/g, '');
    s.body = this.formModel.value.body;
    s.status = this.formModel.value.active ? 'Active' : 'Inactive';
    if (this.message.id) {
      s.id = this.message.id;
      this.adminMessageService.update(s)
        .subscribe((ns) => {
          this.resetFormModel();
          this.getPushMessages();
        });
    } else {
      this.adminMessageService.create(s)
        .subscribe((ns) => {
          this.resetFormModel();
          this.getPushMessages();
        });
    }
  }

  hasAudience() {
    this.audience = ((this.formModel.value.audienceGroup.includeBrokerDealers) ||
      (this.formModel.value.audienceGroup.includeAgents) ||
      (this.formModel.value.audienceGroup.includeConsumers)) ? '1' : '';
    this.formModel.patchValue({ audience: this.audience });
  }

  toggleAudience($event) {
    const label = $event.currentTarget.id;
    this.formModel.value.audienceGroup[label] = $event.currentTarget.checked;
    this.hasAudience();
  }

  cancelEdit() {
    this.pushMessageUpdated.emit();
    this.resetFormModel();
  }

  private getField(field: string): AbstractControl {
    const forms = [this.formModel];
    const form = forms.find(f => f.contains(field));
    return form.get(field);
  }

}
