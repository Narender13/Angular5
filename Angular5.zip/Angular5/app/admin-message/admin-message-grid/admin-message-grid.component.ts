import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { switchMap } from 'rxjs/operators';

import { AdminMessageService } from '../shared/admin-message.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { DialogDefinition, DialogStyle } from '../../shared/models/dialog.model';
import { DialogService } from '../../shared/dialog/shared/dialog.service';
import { PushMessage } from '../../shared/models/message.model';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-admin-message-grid',
  templateUrl: './admin-message-grid.component.html',
  styleUrls: ['./admin-message-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('AdminMessageGridComponent')
export class AdminMessageGridComponent implements Configurable, OnInit {
  config: any;
  pushMessages: PushMessage[];
  message: PushMessage = new PushMessage();
  count: number;
  limit = 3;
  offset = 0;
  mode = '';
  statusUpdate = '';
  audience: string[][] = [];
  mouseover: boolean;
  messageFocus: number;
  confirmDialog: DialogDefinition = {
    dialogDomId: '#sendDialog',
    contentDomId: '#adminMessageGridDiv',
    title: 'Send Push Message',
    message: 'Please confirm. Send Push Message Now?',
    style: DialogStyle.YesNo
  };
  sentDialog: DialogDefinition = {
    dialogDomId: '#sentDialog',
    contentDomId: '#adminMessageGridDiv',
    title: 'Push Message Sent',
    message: 'Push Message Sent.',
    style: DialogStyle.Ok
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminMessageService: AdminMessageService,
    private userService: UserService,
    private dialogService: DialogService
  ) { }

  ngOnInit() {
    this.config.limit = this.config.limit || this.limit;
    this.config.offset = this.offset;
    this.getPushMessages();
    this.adminMessageService.count()
      .subscribe((res: number) => {
        this.count = res;
      });
  }

  getPushMessages() {
    this.mode = '';
    this.statusUpdate = '';
    this.unsetCurrentMessage();
    this.route.params.pipe(
      switchMap((params: { q: string, limit: number, offset: number }) => {
        this.config.limit = isNaN(params.limit) ? this.config.limit : +params.limit;
        this.config.offset = isNaN(params.offset) ? this.config.offset : +params.offset;
        return this.adminMessageService.list(this.config.limit, this.config.offset, ['Active', 'Inactive']);
      })
    ).subscribe((ns) => {
      this.pushMessages = ns;

      // model will potentially provide specific set of entities as audience for the message and not "All or none"
      // so audience is just a descriptor for the To: line and not included in the PushMessage model
      this.pushMessages.forEach(element => {
        const a: string[] = [];
        if (element.includeBrokerDealers) {
          a.push('Broker/Dealers');
        }
        if (element.includeAgents) {
          a.push('Agents');
        }
        if (element.includeConsumers) {
          a.push('Consumers');
        }
        const key = 'key:' + element.id.toString();
        this.audience[key] = a;
      });
    });
    // this.getSubscriptions();
    this.adminMessageService.countTotal(['Active', 'Inactive'])
      .subscribe((res: number) => {
        this.count = res;
      });
  }

  editPushMessage(e: Event, messageId: number) {
    const currentMessage = this.pushMessages.find(x => x.id === messageId);
    if (currentMessage) {
      this.prepareWindow(messageId);
      this.setCurrentMessage(currentMessage);
      this.mode = 'Editing';
      this.statusUpdate = '';
    }
    e.stopPropagation();
  }

  sendPushMessageConfirmation(e: Event, messageId: number) {
    e.stopPropagation();
    this.messageFocus = messageId;
    this.dialogService.display(this.confirmDialog.dialogDomId);
  }

  actionConfirm(action: string, messageId: number) {
    if (action === 'Ok') {
      this.sendPushMessage(messageId);
    }
  }

  sendPushMessageConfirmed(resp: string) {
    this.dialogService.dismiss(this.confirmDialog.dialogDomId);
    if (resp === 'Yes') {
      this.sendPushMessage(this.messageFocus);
    }
  }

  sendPushMessageConfirmedSent() {
    this.dialogService.dismiss(this.sentDialog.dialogDomId);
  }

  sendPushMessage(messageId: number) {
    const currentMessage = this.pushMessages.find(x => x.id === messageId);
    if (currentMessage) {
      this.statusUpdate = 'InProgress';
      const s = new PushMessage();
      s.id = currentMessage.id;
      this.adminMessageService.send(s)
        .subscribe((ns) => {
          this.statusUpdate = 'Done';
          // uncomment this to get a dialog box message confirming send complete: this.dialogService.display(this.sentDialog.dialogDomId);
        });
    }
  }

  toggleEditor() {
    this.mode = this.mode === '' ? 'New' : '';
    this.statusUpdate = '';
    this.prepareWindow();
  }

  deleteMessage(e: Event, messageId: number) {
    const s = this.pushMessages.find(x => x.id === messageId);
    this.adminMessageService.delete(s)
      .subscribe((r) => {
        this.getPushMessages();
      });
    e.stopPropagation();
  }

  onToggleStatus(e: Event, messageId: number) {
    const s = this.pushMessages.find(x => x.id === messageId);
    s.status = s.status === 'Active' ? 'Inactive' : 'Active';
    this.adminMessageService.update(s)
      .subscribe((r) => {
        this.getPushMessages();
      });
    e.stopPropagation();
  }

  private prepareWindow(id?) {
    if (this.pushMessages.length <= this.config.limit) { return; }
    let idx = 0;
    if (id) {
      idx = this.pushMessages.findIndex(x => x.id === id);
    }
    let result = this.pushMessages.slice(idx);
    const len = result.length;
    if (len <= this.config.limit) {
      const val = -1 * +this.config.limit;
      result = this.pushMessages.slice(val);
    } else {
      result = this.pushMessages.slice(idx, idx + this.config.limit);
    }
    this.pushMessages = result;
  }

  private setCurrentMessage(message) {
    // for any components that have current message as an input
    this.message = message;
  }

  private unsetCurrentMessage() {
    // for any components that have current message as an input
    this.message.id = 0;
  }

  private getAudience(id) {
    const key = 'key:' + id.toString();
    let result = this.audience[key];
    if (result !== undefined) {
      result = result.join('; ');
    } else {
      result = 'wait';
    }
    return result;
  }

}
