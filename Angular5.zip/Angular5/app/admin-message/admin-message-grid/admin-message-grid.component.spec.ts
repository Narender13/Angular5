import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMessageGridComponent } from './admin-message-grid.component';

describe('AdminMessageGridComponent', () => {
  let component: AdminMessageGridComponent;
  let fixture: ComponentFixture<AdminMessageGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminMessageGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminMessageGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
