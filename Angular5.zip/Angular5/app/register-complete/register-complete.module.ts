import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { RegisterCompleteRoutingModule } from './register-complete-routing.module';
import { RegisterCompleteComponent } from './register-complete.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [RegisterCompleteComponent],
  imports: [CommonModule, SharedModule, FormsModule, RegisterCompleteRoutingModule],
  exports: [RegisterCompleteComponent]
})
export class RegisterCompleteModule { }
