import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  templateUrl: './register-complete.html',
  styleUrls: ['./register-complete.component.scss']

})
export class RegisterCompleteComponent implements OnInit {
  message = 'Thanks for creating a user account. Check your email and click the confirmation link prior to signing in.';

  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    const qs = this.activatedRoute.snapshot.queryParams;
    /* tslint:disable:no-string-literal */
    const err = qs['err'];
    /* tslint:enable:no-string-literal */
    switch(err) {
      case 'code': {
        this.message = 'You have entered an incorrect validation code. Please click on the email link and try again';
        break;
      }
      case 'terminated': {
        this.message = 'This delegation has already been terminated. Please check with your delegator';
        break;
      }
      case 'exists': {
        this.message = 'This email address was used to create an account after the invitation was sent.';
        this.message += ' Ask your delegator to remove and recreate the invitation';
        break;
      }
    }
  }
}