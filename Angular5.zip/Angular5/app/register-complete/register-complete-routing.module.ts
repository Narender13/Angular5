import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterCompleteComponent } from './register-complete.component';

const routes: Routes = [
    { path: 'registercomplete', component: RegisterCompleteComponent }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class RegisterCompleteRoutingModule { }
