import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gtp-manage-groups-list',
  templateUrl: './gtp-manage-groups-list.component.html',
  styles: []
})
export class GtpManageGroupsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
