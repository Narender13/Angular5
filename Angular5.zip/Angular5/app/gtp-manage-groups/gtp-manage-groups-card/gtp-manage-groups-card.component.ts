import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gtp-manage-groups-card',
  templateUrl: './gtp-manage-groups-card.component.html',
  styles: []
})
export class GtpManageGroupsCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
