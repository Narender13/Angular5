import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { GtpManageGroupsRoutingModule } from './gtp-manage-groups-routing.module';
import { GtpManageGroupsChipComponent } from './gtp-manage-groups-chip/gtp-manage-groups-chip.component';
import { GtpManageGroupsListComponent } from './gtp-manage-groups-list/gtp-manage-groups-list.component';
import { GtpManageGroupsCardComponent } from './gtp-manage-groups-card/gtp-manage-groups-card.component';
import { GtpManageGroupsGridComponent } from './gtp-manage-groups-grid/gtp-manage-groups-grid.component';
import { GtpManageGroupsService } from 'app/gtp-manage-groups/shared/gtp-manage-groups.service';
import { SharedModule } from '../shared/shared.module';
import { GtpManageGroupsDetailComponent } from './gtp-manage-groups-detail/gtp-manage-groups-detail.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    GtpManageGroupsRoutingModule,
    SharedModule
  ],
  declarations: [GtpManageGroupsChipComponent,
    GtpManageGroupsListComponent,
    GtpManageGroupsCardComponent,
    GtpManageGroupsGridComponent,
    GtpManageGroupsDetailComponent],
  providers: [GtpManageGroupsService]

})
export class GtpManageGroupsModule { }
