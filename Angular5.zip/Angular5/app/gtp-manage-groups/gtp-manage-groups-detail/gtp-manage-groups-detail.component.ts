// tslint:disable-next-line:only-arrow-functions
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { share, switchMap, tap, map, debounceTime } from 'rxjs/operators';

import { Group } from '../../shared/models/group.model';
import { GtpManageGroupsService } from '../shared/gtp-manage-groups.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';
import { PersistableResponse } from 'app/shared/models/PersistableResponse.model';
import { UserService } from 'app/shared/services/user.service';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'app-gtp-manage-groups-detail',
  templateUrl: './gtp-manage-groups-detail.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('GtpManageGroupsDetailComponent')
export class GtpManageGroupsDetailComponent implements OnInit {

  group: Observable<Group>;
  originalGroup: Group;
  localized: any;
  tools = ['print', 'export'];
  activeTool: string;
  usable: boolean;
  config: any;
  groupForm: FormGroup;
  response: PersistableResponse<Group>;
  errors = {
    groupName: null
  };
  loading = true;
  submitting = false;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private fb: FormBuilder,
    private service: GtpManageGroupsService,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.localized = this.config.translated;
    this.group = this.route.params.pipe(
      tap(_ => this.loading = true),
      switchMap((params: { id: string }) => {
        if (params.id === '0') {
          return of(this.buildForm());
        } else {
          return this.service.find(params.id);
        }
      }),
      tap(group => {
        this.originalGroup = group;
        this.buildForm(group);
      }),
      tap(_ => {
        // setTime out function is being used to deal with EXCEPTION: Expression has changed after it was checked.
        setTimeout(() => {
          this.loading = false;
        }, 50);
      }),
      share()
    );
  }

  isNew = (group: Group) => this.service.isNew(group);
  isEditable = (group: Group) => this.service.isEditable(group);
  hasPending = (group: Group) => this.service.hasPending(group);
  isLocked = (group: Group) => this.service.isLocked(group);

  buildForm(model?: Group) {
    model = model || new Group();
    this.groupForm = this.fb.group({
      groupId: [model.groupId],
      groupName: [model.groupName, [
        Validators.required,
        Validators.minLength(3),
        Validators.pattern(/^((?!(all (contract|account)s?)).)*$/i)
      ]]
    });
    this.groupForm.valueChanges.pipe(
      debounceTime(500))
      .subscribe(() => {
        this.compileErrors();
      });
    return model;
  }

  compileErrors(ignoreDirty?: boolean) {
    const form = this.groupForm;
    for (const field of Object.keys(this.errors)) {
      const control = form.get(field);
      this.errors[field] = '';
      if (control && control.invalid && (control.dirty || ignoreDirty)) {
        control.markAsDirty();
        const messages = this.localized.messages[field];
        for (const key of Object.keys(control.errors)) {
          this.errors[field] += messages[key] + '';
        }
      }
    }
  }

  delete(action) {
    if (action === 'Cancel') {
      return;
    }
    const form = this.groupForm;
    this.service.delete(form.value as Group).pipe(
      tap(_ => this.submitting = true),
      map(data => {
        if (data.success) {
          this.router.navigate(['gtp-manage-groups']);
        } else {
          this.response = data;
        }
      }),
      tap(_ => this.submitting = false)
    ).subscribe();
  }

  reset() {
    this.groupForm.reset(this.originalGroup);
    this.response = null;
    this.submitting = false;
  }
  create() {
    this.response = null;
    const form = this.groupForm;
    if (!form.valid) {
      return this.compileErrors(true);
    }
    let group = new Group();
    group = form.value;
    group.userId = this.userService.user.profile.name;
    this.service.create(group).pipe(
      tap(_ => this.submitting = true),
      map(data => {
        if (data.success) {
          this.router.navigate(['gtp-manage-groups', data.model.groupId, 'detail'], { replaceUrl: true });
        } else {
          this.response = data;
        }
      }),
      tap(_ => this.submitting = false)
    ).subscribe();
  }

  update() {
    this.response = null;
    const form = this.groupForm;
    if (!form.valid) {
      return this.compileErrors(true);
    }
    this.service.update(form.value as Group).pipe(
      tap(_ => this.submitting = true),
      map(data => {
        if (data.success) {
          this.router.navigate(['gtp-manage-groups', data.model.groupId, 'detail'], { replaceUrl: true });
        } else {
          this.response = data;
        }
      }),
      tap(_ => this.submitting = false)
    ).subscribe();
  }
}
