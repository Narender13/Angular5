import { Headers, URLSearchParams, Response, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { map, mergeMap, first, catchError } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';
import { Group } from '../../shared/models/group.model';
import { Subject } from 'rxjs/Subject';

import { PersistableResponse } from '../../shared/models/PersistableResponse.model';

@Injectable()
export class GtpManageGroupsService {

  private apiUrl = 'GtpGroups/';
  private cache: Group[];
  private timestamp: number;
  private count$ = new Subject<number>();

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService
  ) { }
  count(): Observable<number> {
    return this.count$.asObservable();
  }

  list(limit?: number, offset?: number, search?: string, orderby?: string, includeProductDefaultGroup?: string): Observable<Group[]> {
    this.timestamp = null; // to stop caching
    let cacheObs = Observable.of(this.cache);
    if (!this.timestamp) {
      const params = new URLSearchParams();
      this.timestamp = Date.now();
      params.set('includeProductDefaultGroup', includeProductDefaultGroup);
      cacheObs = this.http.authGet(this.apiUrl, { search: params }).pipe(
        map(res => {
          const data = this.extractData(res);
          this.cache = data;
          return data;
        }));
    }
    return cacheObs.pipe(
      map(data => this.serach(data, search)),
      map(data => this.sort(data, orderby)),
      map(data => this.slice(data, limit, offset)));
  }

  find(id: string): Observable<Group> {
    return this.list(null, null, null, null, 'true').pipe(
      mergeMap(data => {
        const a = data.filter(group => group.groupId === id);
        return a;
      }),
      first());
  }

  create(group: Group): Observable<PersistableResponse<Group>> {
    return this.http.authPost(this.apiUrl, group).pipe(
      map(res => this.extractsave(res)),
      catchError(this.loggingService.handleError));
  }
  update(group: Group): Observable<PersistableResponse<Group>> {
    return this.http.authPut(this.apiUrl, group).pipe(
      map(res => this.extractsave(res)),
      catchError(this.loggingService.handleError));
  }

  delete(group: Group): Observable<PersistableResponse<Group>> {
    const options = new RequestOptions();
    options.body = group;
    const headers = new Headers({ 'ContentType': 'application/json' });
    options.headers = headers;
    return this.http.authDelete(this.apiUrl, options).pipe(
      map(res => this.extractsave(res)),
      catchError(this.loggingService.handleError));
  }

  isNew(group: Group): boolean {
    return !group.groupId || !+group.groupId;
  }

  isEditable(group: Group): boolean {
    return !this.hasPending(group) && !this.isLocked(group);
  }

  hasPending(group: Group): boolean {
    return group.groupTradeLock;
  }

  isLocked(group: Group): boolean {
    return group.productDefaultGroup;
  }

  private extractData(res: Response) {
    const body = res.json() as Group[];
    body.forEach(item => {
      item.groupId = '' + item.groupId;
    });
    return body || [];
  }
  private slice(data: Group[], limit: number, offset: number) {
    this.count$.next(data.length);
    const start = (+offset) || 0;
    const end = (start + (+limit)) || data.length;
    return data.slice(start, end);
  }
  private sort(data: Group[], orderby: string) {
    if (!orderby) { return data; }
    const fragments = orderby.toLowerCase().split(' ');
    const f = fragments[0];
    const dir = fragments[1];

    switch (f) {
      case 'groupname':
        data = data.sort((a: Group, b: Group): number => {
          if (a.groupName.toLowerCase() < b.groupName.toLowerCase()) { return -1; }
          if (a.groupName.toLowerCase() > b.groupName.toLowerCase()) { return 1; }
          return 0;
        });
        break;
      case 'totalcontracts':
        data = data.sort((a: Group, b: Group): number => {
          if (a.totalContracts < b.totalContracts) { return -1; }
          if (a.totalContracts > b.totalContracts) { return 1; }
          return 0;
        });
        break;
    }

    if (dir === 'desc') {
      data = data.reverse();
    }
    return data;
  }
  private serach(data: Group[], search: string) {
    if (!search) { return data; }
    const searchValue = String(search).toLowerCase();
    data = data.filter(g => {
      if (g.groupName && g.groupName.toLowerCase().includes(searchValue)) { return true; }
      return false;
    });
    return data;
  }

  private extractsave(res: Response): PersistableResponse<Group> {
    return res.json() as PersistableResponse<Group>;
  }
}
