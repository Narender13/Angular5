import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { GtpManageGroupsGridComponent } from './gtp-manage-groups-grid/gtp-manage-groups-grid.component';
import { GtpManageGroupsDetailComponent } from './gtp-manage-groups-detail/gtp-manage-groups-detail.component';

const routes: Routes = [
  { path: 'gtp-manage-groups', component: GtpManageGroupsGridComponent, canActivate: [AuthGuardService] },
  { path: 'gtp-manage-groups/:id/detail', component: GtpManageGroupsDetailComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GtpManageGroupsRoutingModule { }
