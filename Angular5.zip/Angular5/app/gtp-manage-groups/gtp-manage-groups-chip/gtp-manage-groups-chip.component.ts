import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gtp-manage-groups-chip',
  templateUrl: './gtp-manage-groups-chip.component.html',
  styles: []
})
export class GtpManageGroupsChipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
