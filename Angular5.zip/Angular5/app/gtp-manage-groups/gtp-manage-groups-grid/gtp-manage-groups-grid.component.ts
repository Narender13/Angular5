import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { Group } from '../../shared/models/group.model';
import { GtpManageGroupsService } from '../shared/gtp-manage-groups.service';
import { ToolbarActionable, ToolbarActionHandlers } from '../../shared/services/toolbar-action-handler';
import { UserService } from '../../shared/services/user.service';
import { PersistableResponse } from '../../shared/models/PersistableResponse.model';

@Component({
  selector: 'app-gtp-manage-groups-grid',
  templateUrl: './gtp-manage-groups-grid.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('GtpManageGroupsGridComponent')
export class GtpManageGroupsGridComponent implements Configurable, OnInit, ToolbarActionable {
  groups: Observable<Group[]>;
  response: PersistableResponse<Group>;
  tools = ['print', 'export'];
  activeTool: string;
  usable: boolean;
  config: any;
  localized: any;
  count: Observable<number>;
  sortFields: string[] =
    ['groupName Asc',
      'groupName Desc',
      'totalContracts Asc',
      'totalContracts Desc'
    ];
  loading = true;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private userService: UserService,
    private service: GtpManageGroupsService
  ) { }

  isEditable = (group: Group) => this.service.isEditable(group);
  hasPending = (group: Group) => this.service.hasPending(group);
  isLocked = (group: Group) => this.service.isLocked(group);

  ngOnInit() {
    this.localized = this.config.translated;
    this.getGroups();
    this.count = this.service.count().pipe(share());
    ToolbarActionHandlers.handle(this);
  }

  getGroups() {
    this.groups = this.route.params.pipe(
      tap(_ => this.loading = true),
      switchMap((params: { q: string, limit: number, offset: number, orderby: string }) => {
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        this.config.orderby = params.orderby || this.config.orderby;
        return this.service.list(this.config.limit, this.config.offset, params.q, this.config.orderby, 'true');
      }),
      tap(_ => this.loading = false),
      share()
    );
  }

  deleteGroup(data, action) {
    if (action === 'Cancel') {
      return;
    }
    const group = new Group();
    group.groupId = data.groupId;
    group.groupName = data.groupName;
    group.userId = this.userService.user.profile.name;
    this.service.delete(group).subscribe(res => {
      this.response = res;
      if (this.response.success) {
        this.getGroups();
      } else {
        // handle error
      }
    });
  }
}
