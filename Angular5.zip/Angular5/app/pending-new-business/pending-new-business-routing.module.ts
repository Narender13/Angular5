import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { PendingNewBusinessGridComponent } from './pending-new-business-grid/pending-new-business-grid.component';
import { PendingNewBusinessDetailComponent } from './pending-new-business-detail/pending-new-business-detail.component';

const routes: Routes = [{
  path: 'pending-contracts/action/:action',
  component: PendingNewBusinessDetailComponent,
  canActivate: [AuthGuardService]
}, {
  path: 'pending-contracts/:id',
  component: PendingNewBusinessDetailComponent,
  canActivate: [AuthGuardService]
}, {
  path: 'pending-contracts',
  component: PendingNewBusinessGridComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingNewBusinessRoutingModule { }
