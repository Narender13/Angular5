import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { PendingContract } from '../../shared/models/pending-contract.model';
import { PendingNewBusinessService } from '../shared/pending-new-business.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-pending-new-business-card',
  templateUrl: './pending-new-business-card.component.html',
  styleUrls: ['./pending-new-business-card.component.scss']
})
@AutoUnsubscribe()
@Configure('PendingNewBusinessCardComponent')
export class PendingNewBusinessCardComponent implements Configurable, OnInit {
  config: any;
  contracts: Observable<PendingContract[]>;
  count: Observable<number>;
  limit = 5;
  usable: any;

  constructor(
    private service: PendingNewBusinessService
  ) { }

  ngOnInit() {
    this.limit = this.config.cardLimit || this.limit;
    this.contracts = this.service.list(null, this.limit, 0, this.config.orderby).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
