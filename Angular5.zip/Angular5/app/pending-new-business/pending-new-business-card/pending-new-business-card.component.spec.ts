import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingNewBusinessCardComponent } from './pending-new-business-card.component';

describe('PendingNewBusinessCardComponent', () => {
  let component: PendingNewBusinessCardComponent;
  let fixture: ComponentFixture<PendingNewBusinessCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingNewBusinessCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingNewBusinessCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
