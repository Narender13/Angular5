import { TestBed, inject } from '@angular/core/testing';

import { PendingNewBusinessService } from './pending-new-business.service';

describe('PendingNewBusinessService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PendingNewBusinessService]
    });
  });

  it('should be created', inject([PendingNewBusinessService], (service: PendingNewBusinessService) => {
    expect(service).toBeTruthy();
  }));
});
