import { Injectable } from '@angular/core';
import { Response, ResponseContentType, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { map, catchError } from 'rxjs/operators';

import { ContractFunding } from '../../shared/models/contract-funding.model';
import { LoggingService } from '../../shared/logging/logging.service';
import { Paginated } from '../../shared/models/paginated.interface';
import { PendingContract } from '../../shared/models/pending-contract.model';
import { PendingContractMilestone } from '../../shared/models/pending-contract-milestone.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class PendingNewBusinessService {
  milestones: any[] = [{
    status: 'Processing',
    sequence: 0
  }, {
    status: 'Pending',
    sequence: 1
  }, {
    status: 'Pending Funds',
    sequence: 2
  }, {
    status: 'Pending Issue',
    sequence: 3
  }, {
    status: 'Issued',
    sequence: 4
  }];
  private apiUrl = 'pendingcontracts/';
  private lastCount = new Subject<number>();

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, limit: number, offset: number, orderby: string): Observable<PendingContract[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('searchvalue', search);
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (limit) {
      params.set('take', limit.toString());
    }
    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params })
      .pipe(map(this.extractData, this),
      catchError(this.loggingService.handleError));
  }

  find(contractId): Observable<PendingContract> {
    return this.http.authGet(this.apiUrl + contractId)
      .pipe(map(res => res.json() as PendingContract),
      catchError(this.loggingService.handleError));
  }

  getDetails(contractId): Observable<ContractFunding[]> {
    return this.http.authGet(this.apiUrl + contractId + '/detail')
      .pipe(map(res => res.json() as ContractFunding[]),
      catchError(this.loggingService.handleError));
  }

  getMilestone(contract: PendingContract): PendingContractMilestone {
    let contractMilestone: PendingContractMilestone;

    const milestone = this.milestones.find(ms => ms.status === contract.contractStatus); // Is NIGO a status?
    // const randNum = Math.floor(Math.random() * 6);
    // const milestone = this.milestones.find(ms => ms.sequence === randNum);

    if (milestone && contract.nigoReasons.length === 0) {
      contractMilestone = new PendingContractMilestone(
        milestone.status,
        milestone.sequence,
        contract.applicationDate,
        contract.processDate,
        false
      );
    } else if (contract.nigoReasons.length > 0) {
      contractMilestone = new PendingContractMilestone('NIGO', milestone.sequence, contract.applicationDate, contract.processDate, false);
    }

    return contractMilestone;
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.apiUrl}export?format=csv`, 'pending-contracts.csv', options);
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<PendingContract>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }
}
