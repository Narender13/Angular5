import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingNewBusinessListComponent } from './pending-new-business-list.component';

describe('PendingNewBusinessListComponent', () => {
  let component: PendingNewBusinessListComponent;
  let fixture: ComponentFixture<PendingNewBusinessListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingNewBusinessListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingNewBusinessListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
