import { Component, Input } from '@angular/core';

import { PendingContract } from '../../shared/models/pending-contract.model';

@Component({
  selector: 'app-pending-new-business-list',
  templateUrl: './pending-new-business-list.component.html',
  styleUrls: ['./pending-new-business-list.component.scss']
})
export class PendingNewBusinessListComponent {
  @Input() contracts: PendingContract[];

  constructor() { }
}
