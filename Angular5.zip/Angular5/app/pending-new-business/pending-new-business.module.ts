import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PendingNewBusinessRoutingModule } from './pending-new-business-routing.module';
import { PendingNewBusinessCardComponent } from './pending-new-business-card/pending-new-business-card.component';
import { PendingNewBusinessChipComponent } from './pending-new-business-chip/pending-new-business-chip.component';
import { PendingNewBusinessDetailComponent } from './pending-new-business-detail/pending-new-business-detail.component';
import { PendingNewBusinessGridComponent } from './pending-new-business-grid/pending-new-business-grid.component';
import { PendingNewBusinessListComponent } from './pending-new-business-list/pending-new-business-list.component';
import { PendingNewBusinessStatusComponent } from './pending-new-business-status/pending-new-business-status.component';
import { PendingNewBusinessService } from './shared/pending-new-business.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    PendingNewBusinessCardComponent,
    PendingNewBusinessChipComponent,
    PendingNewBusinessDetailComponent,
    PendingNewBusinessGridComponent,
    PendingNewBusinessListComponent,
    PendingNewBusinessStatusComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    PendingNewBusinessRoutingModule
  ],
  exports: [PendingNewBusinessCardComponent, PendingNewBusinessStatusComponent],
  providers: [
    PendingNewBusinessService
  ]
})
export class PendingNewBusinessModule { }
