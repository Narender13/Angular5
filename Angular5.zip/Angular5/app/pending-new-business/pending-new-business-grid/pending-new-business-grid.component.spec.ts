import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingNewBusinessGridComponent } from './pending-new-business-grid.component';

describe('PendingNewBusinessGridComponent', () => {
  let component: PendingNewBusinessGridComponent;
  let fixture: ComponentFixture<PendingNewBusinessGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingNewBusinessGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingNewBusinessGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
