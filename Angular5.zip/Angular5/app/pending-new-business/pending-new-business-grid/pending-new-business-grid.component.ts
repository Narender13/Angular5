import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { PendingContract } from '../../shared/models/pending-contract.model';
import { PendingNewBusinessService } from '../shared/pending-new-business.service';
import { ToolbarActionHandlers, ToolbarActionable } from '../../shared/services/toolbar-action-handler';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { PageParams } from '../../shared/models/paginated.interface';

@Component({
  selector: 'app-pending-new-business-grid',
  templateUrl: './pending-new-business-grid.component.html',
  styleUrls: ['./pending-new-business-grid.component.scss']
})
@Configure('PendingNewBusinessGridComponent')
export class PendingNewBusinessGridComponent implements Configurable, OnInit, ToolbarActionable {
  config: any;
  contracts: Observable<PendingContract[]>;
  count: Observable<number>;
  loading = true;
  sortFields: string[] = [
    'contractNumber Asc',
    'contractNumber Desc',
    'applicationDate Asc',
    'applicationDate Desc',
    'personName Asc',
    'personName Desc'];
  tools = ['print', 'export'];
  activeTool: string;
  usable: boolean;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: PendingNewBusinessService,
    private logging: LoggingService) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.contracts = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap(params => this.load(params as PageParams)),
      tap(() => this.loading = false),
      share()
    );
    ToolbarActionHandlers.handle(this);
  }
  load(query: PageParams) {
    const { q, limit = this.config.limit, offset = 0, orderby = this.config.orderby } = query;
    this.config.limit = limit;
    this.config.offset = offset;
    this.config.orderby = orderby;
    return this.service.list(q, limit, offset, orderby);
  }
  onExport(): Observable<any> {
    return this.service.export();
  }
}
