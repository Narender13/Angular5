import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { ContractFunding } from '../../shared/models/contract-funding.model';
import { PendingContract } from '../../shared/models/pending-contract.model';
import { SubscriptionMonitor } from '../../shared/models/subscription.model';
import { SubscriptionService } from '../../subscription/shared/subscription.service';
import { PendingNewBusinessService } from '../shared/pending-new-business.service';

@Component({
  selector: 'app-pending-new-business-detail',
  templateUrl: './pending-new-business-detail.component.html',
  styleUrls: ['./pending-new-business-detail.component.scss']
})
export class PendingNewBusinessDetailComponent implements OnInit {
  pendingContract: Observable<PendingContract>;
  contractFundings: Observable<ContractFunding[]>;
  monitorEnabled: string;

  constructor(
    private route: ActivatedRoute,
    private service: PendingNewBusinessService,
    private subscriptionService: SubscriptionService) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    const contractId = routeParams.id;
    this.pendingContract = this.service.find(contractId).pipe(share());
    this.contractFundings = this.service.getDetails(contractId).pipe(share());
    // monitoring status
    const s: SubscriptionMonitor = new SubscriptionMonitor('web', 'ChangeApplicationStatus', contractId, '');
    this.subscriptionService.individualcheck(s)
      .subscribe((res: SubscriptionMonitor) => {
        this.monitorEnabled = (res.individualKey === contractId) ? 'Active' : 'Inactive';
      });
  }

  onToggleEnabled(e: Event) {
    const routeParams = this.route.snapshot.params as { id: string };
    const contractId = routeParams.id;
    this.monitorEnabled = (this.monitorEnabled === 'Active') ? 'Inactive' : 'Active';
    const s: SubscriptionMonitor = new SubscriptionMonitor(
      'web', 'ChangeApplicationStatus', contractId, this.monitorEnabled);
    this.subscriptionService.individual(s)
      .subscribe((ok: boolean) => {
      });
  }

}
