import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingNewBusinessDetailComponent } from './pending-new-business-detail.component';

describe('PendingNewBusinessDetailComponent', () => {
  let component: PendingNewBusinessDetailComponent;
  let fixture: ComponentFixture<PendingNewBusinessDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingNewBusinessDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingNewBusinessDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
