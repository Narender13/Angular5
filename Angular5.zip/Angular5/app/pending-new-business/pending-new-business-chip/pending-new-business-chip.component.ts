import { Component, OnInit, Input } from '@angular/core';
import { PendingContract } from '../../shared/models/pending-contract.model';

@Component({
  selector: 'app-pending-new-business-chip',
  templateUrl: './pending-new-business-chip.component.html',
  styles: [':host{width:100%;}']
})
export class PendingNewBusinessChipComponent implements OnInit {
  @Input() pendingContract: PendingContract;

  constructor() { }

  ngOnInit() {
  }

}
