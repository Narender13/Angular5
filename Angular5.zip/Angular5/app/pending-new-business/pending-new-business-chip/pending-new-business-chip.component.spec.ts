import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingNewBusinessChipComponent } from './pending-new-business-chip.component';

describe('PendingNewBusinessChipComponent', () => {
  let component: PendingNewBusinessChipComponent;
  let fixture: ComponentFixture<PendingNewBusinessChipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingNewBusinessChipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingNewBusinessChipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
