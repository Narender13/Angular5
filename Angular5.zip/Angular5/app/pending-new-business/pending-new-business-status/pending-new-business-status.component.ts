import { Component, OnInit, Input } from '@angular/core';
import { PendingContract } from '../../shared/models/pending-contract.model';
import { PendingContractMilestone } from '../../shared/models/pending-contract-milestone.model';
import { PendingNewBusinessService } from '../shared/pending-new-business.service';

@Component({
  selector: 'app-pending-contract-status',
  templateUrl: './pending-new-business-status.component.html',
  styleUrls: []
})
export class PendingNewBusinessStatusComponent implements OnInit {
  @Input() contract: PendingContract;
  @Input() size: string; // sm or lg, leave empty for default
  milestone: PendingContractMilestone;
  progressArr = this.service.milestones;

  constructor(private service: PendingNewBusinessService) { }

  ngOnInit() {
    this.milestone = this.service.getMilestone(this.contract);
  }
}
