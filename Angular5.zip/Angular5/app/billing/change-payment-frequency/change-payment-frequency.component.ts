import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { ChangePaymentFrequency } from '../../shared/models/change-payment-frequency.model';
import { ChangePaymentFrequencyService } from 'app/billing/shared/change-payment-frequency.service';
import { Billing } from '../../shared/models/billing.model';
import { BillingService } from '../shared/billing.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';


@Component({
  selector: 'app-change-payment-frequency',
  templateUrl: './change-payment-frequency.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ChangePaymentFrequencyComponent')
export class ChangePaymentFrequencyComponent implements OnInit {
  changePaymentFrequencyForm: FormGroup;
  config: any;
  paymentFrequency = ['', 'Monthly', 'Quarterly', 'Semiannually', 'Annually'];
  estimatedPremium: Observable<ChangePaymentFrequency>;
  billing: Observable<Billing>;
  selectedPaymentFrequency: string;
  contractId: string;
  localized: any;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: ChangePaymentFrequencyService,
    private billingService: BillingService,
    private fb: FormBuilder,
  ) {  }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    this.contractId = routeParams.id;
    this.billing = this.billingService.list(this.contractId);
    this.localized = this.config.translated;
    this.buildForms();
    // this.estimatedPremium = this.service.list(contractId, 'Monthly');
  }
  onChange(event, frequency) {
    if (frequency === '') {
      this.estimatedPremium = null;
    } else {
      this.estimatedPremium = this.service.list(this.contractId, frequency);
    }
  }
  buildForms() {
    this.changePaymentFrequencyForm = this.fb.group({
      agreement: [false, Validators.requiredTrue]
    });
  }
}
