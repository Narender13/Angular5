import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { ChangePaymentFrequencyComponent } from 'app/billing/change-payment-frequency/change-payment-frequency.component';

const routes: Routes = [{
  path: 'contracts/:id/change-payment-frequency',
  component: ChangePaymentFrequencyComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BillingRoutingModule { }
