import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { AuthGuardService } from '../../shared/services/auth-guard.service';
import { Billing } from '../../shared/models/billing.model';
import { BillingService } from '../shared/billing.service';
import { ContractService } from 'app/contract/shared/contract.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-billing-card',
  templateUrl: './billing-card.html',
  styleUrls: []
})
@AutoUnsubscribe()
@Configure('BillingCardComponent')
export class BillingCardComponent implements OnInit {
  billing: Observable<Billing>;
  config: any;
  contextMenuAvailable: boolean;
  contractId: string;
  hideContextMenu = false;
  showOneTimePaymentLink = false;
  usable: any;
  matrix: any;

  constructor(
    private route: ActivatedRoute,
    private service: BillingService,
    private contractService: ContractService,
    private guardService: AuthGuardService
  ) { }

  ngOnInit() {
    this.contextMenuAvailable = !this.hideContextMenu && this.config.contextMenu && this.config.contextMenu.length > 0;
    //this.config.contextMenu.find(cm => cm.route === 'transactions').route += ';q=Premium';
    // this.config.contextMenu += ';q=Premium';
    const routeParams = this.route.snapshot.params as { contractId: string };
    this.contractId = routeParams.contractId;

    this.billing = this.service.list(this.contractId);
    this.matrix = {'offset': 0, 'q': 'Premium'};
    // Call Contract service to get Contract status
    this.contractService.find(this.contractId).subscribe(c => {
      const contractStatus = c.contractStatus;
      if (contractStatus && contractStatus.toLowerCase() === 'lapse pending') {
        this.showOneTimePaymentLink = true;
      }
    });
  }

}
