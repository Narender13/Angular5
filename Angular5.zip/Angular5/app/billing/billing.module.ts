import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { BillingCardComponent } from 'app/billing/billing-card/billing-card.component';
import { BillingRoutingModule } from './billing-routing.module';
import { BillingService } from './shared/billing.service';
import { SharedModule } from '../shared/shared.module';
import { ChangePaymentFrequencyComponent } from './change-payment-frequency/change-payment-frequency.component';
import { ChangePaymentFrequencyService } from 'app/billing/shared/change-payment-frequency.service';

@NgModule({
  declarations: [
    BillingCardComponent,
    ChangePaymentFrequencyComponent
  ],
  imports: [
    BillingRoutingModule,
    CommonModule,
    SharedModule,
    ReactiveFormsModule
  ],
  exports: [BillingCardComponent],
  providers: [BillingService, ChangePaymentFrequencyService]
})
export class BillingModule { }
