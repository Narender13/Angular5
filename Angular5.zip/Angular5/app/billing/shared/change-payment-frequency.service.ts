import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';

import { UWHttp } from '../../UWHttp';
import { LoggingService } from '../../shared/logging/logging.service';
import { ChangePaymentFrequency } from '../../shared/models/change-payment-frequency.model';

@Injectable()
export class ChangePaymentFrequencyService {
  private apiUrl = 'changepaymentfrequency/';

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  list(contractId: string, paymentFrequency: string): Observable<ChangePaymentFrequency> {
    const params = new URLSearchParams();
    params.set('id', contractId);
    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => this.extract(res)),
      // .map(data => data.slice(0, limit || data.length))
      catchError(this.loggingService.handleError));
  }

  // private extract(res: Response): Billing[] {
  //   const data = res.json() as Billing[];
  //   this.lastCount.next(data.length);
  //   return data;
  // }

  private extract(res: Response): Observable<ChangePaymentFrequency> {
    const data = res.json() as Observable<ChangePaymentFrequency>;
    // this.lastCount.next(data.length);
    return data;
  }
}
