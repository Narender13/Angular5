import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { Billing } from 'app/shared/models/billing.model';
import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class BillingService {
  private apiUrl = 'billing/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(contractId: string, limit?: number): Observable<Billing> {
    const params = new URLSearchParams();
    params.set('id', contractId);
    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => this.extract(res)),
      // .map(data => data.slice(0, limit || data.length))
      catchError(this.loggingService.handleError));
  }

  // private extract(res: Response): Billing[] {
  //   const data = res.json() as Billing[];
  //   this.lastCount.next(data.length);
  //   return data;
  // }

  private extract(res: Response): Observable<Billing> {
    const data = res.json() as Observable<Billing>;
    // this.lastCount.next(data.length);
    return data;
  }
}
