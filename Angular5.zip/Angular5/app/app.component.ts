import { Component, OnInit, Renderer2 } from '@angular/core';
import { SessionTimeoutService } from './shared/services/sessionTimeout.service';
import { UserService } from './shared/services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Agent Summary';
  cntDwn = 0;
  timeoutWarn = false;

  constructor(
    private sessionTimeoutService: SessionTimeoutService,
    private userService: UserService,
    private renderer: Renderer2
  ) { }

  ngOnInit() {
    this.sessionTimeoutService.timeoutWarning
      .subscribe((cntDwn) => {
        this.timeoutWarn = true;
        this.renderer.addClass(document.body, 'modal-open');
        this.cntDwn = cntDwn;
      });

    this.sessionTimeoutService.idleEnd
      .subscribe(() => {
        this.renderer.removeClass(document.body, 'modal-open');
        this.timeoutWarn = false;
      });

    this.sessionTimeoutService.timeOut
      .subscribe(() => this.userService.startSignoutMainWindow())
  }
}
