import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { timer } from 'rxjs/observable/timer';
import { finalize, map, take } from 'rxjs/operators';

import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../shared/decorators/configurable';
import { StorageService } from '../shared/services/storage.service';
import { UserService } from '../shared/services/user.service';
import { OidcToken } from '../shared/models/oidcToken.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  styleUrls: ['./login.component.scss']

})
@AutoUnsubscribe()
@Configure('LoginComponent')
export class LoginComponent implements Configurable, OnInit {
  localized: any;
  returnUrl: string;
  attemptedRoute: string;
  config: any;
  usable: boolean;
  oidcToken: OidcToken;
  private userErrorMsg: string;
  private loginWait: boolean;
  private loginAttempts: number;
  private loginLockCountDown: any;
  private loginLockTimeCounter: number;
  private maxLoginAttempts: number;
  private loginLockTime: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private storageService: StorageService
  ) { }

  ngOnInit() {
    const params = this.route.snapshot.queryParams as { override: string };
    if (this.config.disabled === true && params.override !== this.config.override) {
      this.router.navigate(['/not-found']);
    }
    const attemptedUrl = this.storageService.get<string>('attemptedUrl');
    if (attemptedUrl) {
      this.attemptedRoute = attemptedUrl.split('/')[1];
    }

    this.storageService.clearOidcTokens();

    // fetches an oidc token asynchronously. CAUTION, asyncSignin is shared functionality with SSO
    this.userService.asyncSignin().subscribe(resp => {
      console.log('received token ' + JSON.stringify(resp));
      this.returnUrl = resp.data;
      this.oidcToken = resp;
    });

    // configure the login options

    // NOTE: We do not need to configure this client side as the prelogin call will/should return all info needed.
    // In order to work "properly", IDS startup needs to have IdentityOptions "DefaultLockoutTimeSpan"
    // and "MaxFailedAccessAttempts" set, they are not configurable on a tenant by tenant basis.

    this.loginWait = false; // this.storageService.get('userLockedOut') as boolean;
    // TODO this should probably store in local storage and check from there
    this.loginAttempts = 0; // TODO this should probably store in local storage and check from there
    this.loginLockTime = this.config.loginLockTime || 60 * 5; // 5 mins
    this.loginLockTimeCounter = this.loginLockTime;
    this.localized = this.config.translated;
    // this.maxLoginAttempts = this.config.loginMaxAttempts ? this.config.loginMaxAttempts : 3;
  }

  onNgSubmit(form: any, evt: any) {
    evt.preventDefault();
    console.log('onNgSubmit called', form, evt);
  }

  startLogInLockTimer() {
    this.loginWait = true;
    // this.storageService.set('userLockedOut', 'true');
    this.loginLockCountDown = timer(0, 1000).pipe( // observable timers don't have the same risk of memory leaks
      take(this.loginLockTimeCounter),
      map(() => --this.loginLockTimeCounter),
      finalize(() => this.loginWait = false), // <-Forrest Gump Style // reset login wait
      // .finally(() => this.storageService.set('userLockedOut', 'false'))
      finalize(() => this.loginAttempts = 0), // <-Forrest Gump Style // reset max current login attempts
      finalize(() => this.loginLockTimeCounter = this.loginLockTime) // reset login lock time
    );
  }

  submit(form: any, userName: string, password: string, evt: any) {
    evt.preventDefault();
    if (userName.length > 0 && password.length > 0) {
      this.userService.preSignin(userName, password)
        .subscribe(resp => {
          console.log('response received from userService.preSignin()', resp.result);
          if (resp.result === 'valid' || resp.result === 'requirestwofactor') {
            this.userErrorMsg = null;
            // set twofactor ui url
            if (resp.result === 'requirestwofactor') {
              // console.log('setting twoFactorUiUrl');
              // two factor auth is set for this user, point the form at sendcode
              form['twofactoruiurl'].value = `${this.config.hostName}/sendcode`;
            }
            form.submit();
          } else if (resp.result === 'lockout') {
            this.startLogInLockTimer();
          } else {
            // track login attempts
            this.loginAttempts = resp.count;
            this.userErrorMsg = 'userErrorMsg';
          }
        }, error => {
          console.log(error);
        });
    } else {
      this.userErrorMsg = 'noUserPasswordError';
    }

  }
}
