import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { UWHttp } from '../../UWHttp';
import { LoggingService } from '../../shared/logging/logging.service';
import { AdministrativeFee } from '../../shared/models/administrative-fee.model';

@Injectable()
export class AdministrativeFeeService {
  private count$ = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.count$.asObservable();
  }

  fees(contractId: string, limit?: number): Observable<AdministrativeFee[]> {
    const url = 'administrativeFees/';
    const params = new URLSearchParams();

    if (contractId) {
      // todo: uncomment when data feeds from api
      // params.set('contractId', contractId);
    }

    return this.http.authGet(url, { search: params }).pipe(
      map(res => this.extract(res)),
      map(data => data.slice(0, limit || data.length)),
      catchError(this.loggingService.handleError)
    );
  }

  charges(contractId: string, limit?: number): Observable<AdministrativeFee[]> {
    const url = 'surrenderCharges/';
    const params = new URLSearchParams();

    if (contractId) {
      // todo: uncomment when data feeds from api
      // params.set('contractId', contractId);
    }

    return this.http.authGet(url, { search: params }).pipe(
      map(res => this.extract(res)),
      map(data => data.slice(0, limit || data.length)),
      catchError(this.loggingService.handleError)
    );
  }

  private extract(res: Response) {
    // todo: fixup when data feeds from api
    const body = res.json() as { data: AdministrativeFee[] };
    this.count$.next(body.data.length);
    return body.data || [];
  }
}
