import { Component, OnInit, Input } from '@angular/core';

import { AdministrativeFee } from '../../shared/models/administrative-fee.model';

@Component({
  selector: 'app-administrative-fee-chip',
  templateUrl: './administrative-fee-chip.component.html',
  styles: [':host { width: 100%}']
})
export class AdministrativeFeeChipComponent implements OnInit {
  @Input() fee: AdministrativeFee;

  constructor() { }

  ngOnInit() {
  }

}
