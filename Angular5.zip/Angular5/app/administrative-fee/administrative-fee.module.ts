import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdministrativeFeeCardComponent } from './administrative-fee-card/administrative-fee-card.component';
import { AdministrativeFeeChipComponent } from './administrative-fee-chip/administrative-fee-chip.component';
import { AdministrativeFeeGridComponent } from './administrative-fee-grid/administrative-fee-grid.component';
import { AdministrativeFeeDetailComponent } from './administrative-fee-detail/administrative-fee-detail.component';
import { AdministrativeFeeListComponent } from './administrative-fee-list/administrative-fee-list.component';
import { AdministrativeFeeRoutingModule } from './administrative-fee-routing.module';
import { AdministrativeFeeService } from './shared/administrative-fee.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    AdministrativeFeeRoutingModule,
    SharedModule
  ],
  declarations: [
    AdministrativeFeeCardComponent,
    AdministrativeFeeChipComponent,
    AdministrativeFeeDetailComponent,
    AdministrativeFeeGridComponent,
    AdministrativeFeeListComponent
  ],
  exports: [
    AdministrativeFeeCardComponent,
    AdministrativeFeeChipComponent
  ],
  providers: [AdministrativeFeeService]
})
export class AdministrativeFeeModule { }
