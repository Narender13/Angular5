import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';
import { AdministrativeFee } from '../../shared/models/administrative-fee.model';
import { AdministrativeFeeService } from '../shared/administrative-fee.service';

@Component({
  selector: 'app-administrative-fee-detail',
  templateUrl: './administrative-fee-detail.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('AdministrativeFeeDetailComponent')
export class AdministrativeFeeDetailComponent implements OnInit {
  config: any;
  fees: Observable<AdministrativeFee[]>;
  charges: Observable<AdministrativeFee[]>;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: AdministrativeFeeService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    const contractId = routeParams.id;
    this.fees = this.service.fees(contractId).pipe(share());
    this.charges = this.service.charges(contractId).pipe(share());
  }
}
