import { Component, OnInit, Input } from '@angular/core';

import { AdministrativeFee } from '../../shared/models/administrative-fee.model';

@Component({
  selector: 'app-administrative-fee-list',
  templateUrl: './administrative-fee-list.component.html',
  styles: []
})
export class AdministrativeFeeListComponent implements OnInit {
  @Input() fees: AdministrativeFee[];

  constructor() { }

  ngOnInit() {
  }

}
