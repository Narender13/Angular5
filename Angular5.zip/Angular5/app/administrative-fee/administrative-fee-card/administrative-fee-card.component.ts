import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { AdministrativeFee } from '../../shared/models/administrative-fee.model';
import { AdministrativeFeeService } from '../shared/administrative-fee.service';

@Component({
  selector: 'app-administrative-fee-card',
  templateUrl: './administrative-fee-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('AdministrativeFeeCardComponent')
export class AdministrativeFeeCardComponent implements Configurable, OnInit {
  className = 'AdministrativeFeeCardComponent';
  config: any;
  count: Observable<number>;
  fees: Observable<AdministrativeFee[]>;
  limit = 5;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: AdministrativeFeeService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    const contractId = routeParams.id;
    this.limit = this.config.cardLimit || this.limit;
    this.fees = this.service.fees(contractId, this.limit).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
