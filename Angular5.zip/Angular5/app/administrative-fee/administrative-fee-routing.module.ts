import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { AdministrativeFeeDetailComponent } from './administrative-fee-detail/administrative-fee-detail.component';

const routes: Routes = [{
  path: 'contracts/:id/administrative-fees',
  component: AdministrativeFeeDetailComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministrativeFeeRoutingModule { }
