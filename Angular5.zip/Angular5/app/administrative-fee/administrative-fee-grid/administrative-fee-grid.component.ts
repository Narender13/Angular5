import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrative-fee-grid',
  templateUrl: './administrative-fee-grid.component.html',
  styles: []
})
export class AdministrativeFeeGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
