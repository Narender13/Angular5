import { Component, Input } from '@angular/core';
import { Purchase } from '../../shared/models/purchase.model';

@Component({
  selector: 'app-purchase-list',
  templateUrl: './purchase-list.component.html',
  styleUrls: ['./purchase-list.component.scss']
})
export class PurchaseListComponent {
  @Input() purchases: Purchase[];

  constructor() { }
}
