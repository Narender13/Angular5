import { Component, Input } from '@angular/core';

import { Purchase } from '../../shared/models/purchase.model';

@Component({
  selector: 'app-purchase-chip',
  templateUrl: './purchase-chip.component.html',
  styles: [':host{width:100%;}']
})
export class PurchaseChipComponent {
  @Input() purchase: Purchase;

  constructor() { }
}
