import { Injectable } from '@angular/core';
import { Response, ResponseContentType, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { Paginated } from '../../shared/models/paginated.interface';
import { Purchase } from '../../shared/models/purchase.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class PurchaseService {
  private apiUrl = 'purchases/';
  private lastCount = new Subject<number>();

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(
    contributing: PurchaseType,
    interval: PurchaseTimespan,
    search?: string,
    limit?: number,
    offset?: number,
    orderby?: string
  ): Observable<Purchase[]> {
    const params = new URLSearchParams();
    params.set('contributing', Boolean(contributing).toString());
    params.set('interval', interval.toString());
    if (search) {
      params.set('searchvalue', search);
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError));
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.apiUrl}export?format=csv`, 'purchases.csv', options);
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<Purchase>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }
}

export enum PurchaseType {
  Noncontributing = 0,
  Contributing
}

export enum PurchaseTimespan {
  Days120 = 120,
  Days240 = 240,
  Days365 = 365
}
