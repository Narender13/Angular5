import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';
import { PurchaseService, PurchaseType, PurchaseTimespan } from '../shared/purchase.service';
import { Purchase } from '../../shared/models/purchase.model';
import { ToolbarActionHandlers, ToolbarActionable } from 'app/shared/services/toolbar-action-handler';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-purchase-grid',
  templateUrl: './purchase-grid.component.html',
  styleUrls: ['./purchase-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('PurchaseGridComponent')
export class PurchaseGridComponent implements Configurable, OnInit, ToolbarActionable {
  config: any;
  purchases: Observable<Purchase[]>;
  count: Observable<number>;
  tools = ['print', 'export'];
  activeTool: string;
  sortFields: string[] = [
    'contractNumber Asc',
    'contractNumber Desc',
    'personName Asc',
    'personName Desc',
    'transactionDate Asc',
    'transactionDate Desc',
    'amount Asc',
    'amount Desc'
  ];
  purchaseTypeEnum: typeof PurchaseType = PurchaseType;
  purchaseTimespanEnum: typeof PurchaseTimespan = PurchaseTimespan;
  usable: boolean;
  loading = true;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: PurchaseService
  ) { }

  ngOnInit() {
    this.purchases = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: PurchaseParams) => {
        const cfg = this.config;
        cfg.purchaseType = params.type === undefined ? PurchaseType.Contributing : +params.type;
        cfg.timespan = +params.time || PurchaseTimespan.Days365;
        cfg.limit = +params.limit || cfg.limit;
        cfg.offset = +params.offset || 0;
        cfg.orderby = params.orderby || cfg.orderby;
        return this.service.list(cfg.purchaseType, cfg.timespan, params.q, cfg.limit, cfg.offset, cfg.orderby);
      }),
      tap(() => this.loading = false),
      share()
    );

    this.count = this.service.count().pipe(share());
    ToolbarActionHandlers.handle(this);
  }

  setPurchaseType(value: PurchaseType) {
    const params = {} as PurchaseParams;
    params.type = PurchaseType[value];
    this.valueChanged(params);
  }

  setTimespan(value: PurchaseTimespan) {
    const params = {} as PurchaseParams;
    params.time = PurchaseTimespan[value];
    this.valueChanged(params);
  }

  valueChanged(data: PurchaseParams) {
    const routeParams = Object.assign({}, this.route.snapshot.params, data);
    const url = this.router.createUrlTree([routeParams], { relativeTo: this.route });
    this.router.navigateByUrl(url);
  }

  getEnumerator(type: any) {
    const keys = Object.keys(type);
    return keys.slice(keys.length / 2);
  }

  onExport(): Observable<any> {
    return this.service.export();
  }
}

interface PurchaseParams {
  type: string;
  time: string;
  q: string;
  limit: string;
  offset: string;
  orderby: string;
}
