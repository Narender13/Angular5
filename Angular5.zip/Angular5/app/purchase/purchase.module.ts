import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { PurchaseCardComponent } from './purchase-card/purchase-card.component';
import { PurchaseChipComponent } from './purchase-chip/purchase-chip.component';
import { PurchaseGridComponent } from './purchase-grid/purchase-grid.component';
import { PurchaseListComponent } from './purchase-list/purchase-list.component';
import { PurchaseRoutingModule } from './purchase-routing.module';
import { PurchaseService } from './shared/purchase.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    PurchaseCardComponent,
    PurchaseChipComponent,
    PurchaseGridComponent,
    PurchaseListComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    PurchaseRoutingModule
  ],
  exports: [
    PurchaseCardComponent,
    PurchaseChipComponent
  ],
  providers: [PurchaseService]
})
export class PurchaseModule { }
