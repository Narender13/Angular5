import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { Purchase } from '../../shared/models/purchase.model';
import { PurchaseService, PurchaseType, PurchaseTimespan } from '../shared/purchase.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-purchase-card',
  templateUrl: './purchase-card.component.html',
  styleUrls: ['./purchase-card.component.scss']
})
@AutoUnsubscribe()
@Configure('PurchaseCardComponent')
export class PurchaseCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  limit = 5;
  purchases: Observable<Purchase[]>;
  purchaseType = PurchaseType.Contributing;
  timespan = PurchaseTimespan.Days365;
  usable: any;

  constructor(
    private service: PurchaseService
  ) { }

  ngOnInit() {
    this.limit = this.config.cardLimit || this.limit;
    this.purchases = this.service.list(this.purchaseType, this.timespan, null, this.limit, 0, this.config.orderby).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
