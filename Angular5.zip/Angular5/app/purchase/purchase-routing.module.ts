import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PurchaseGridComponent } from './purchase-grid/purchase-grid.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const routes: Routes = [
  {
    path: 'purchases', component: PurchaseGridComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PurchaseRoutingModule { }
