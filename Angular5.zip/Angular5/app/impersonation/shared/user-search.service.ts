import { Injectable } from '@angular/core';
import { UWHttp } from '../../UWHttp';
import { Observable } from 'rxjs/Observable';



import { share } from 'rxjs/operators';

@Injectable()
export class UserSearchService {
  private apiUrl = 'usersearch/';

  constructor(
    private http: UWHttp
  ) { }

  searchByTenant(search: string, offset: number, take: number): Observable<any> {
    return this.http.authGet(`${this.apiUrl}?search=${search}&offset=${offset}&take=${take}`)
      .map(res => {
        const countAndData = res.json() as any;
        return countAndData;
      }).pipe(share());
  }
}
