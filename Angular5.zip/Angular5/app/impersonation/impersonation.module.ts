import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { ImpersonationCardComponent } from './impersonation-card/impersonation-card.component';
import { AliasService } from '../shared/services/alias.service';
import { UserSearchService } from './shared/user-search.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    ImpersonationCardComponent
  ],
  providers: [
    AliasService,
    UserSearchService
  ],
  exports: [
    ImpersonationCardComponent
  ],
})
export class ImpersonationModule { }
