import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { debounceTime, distinctUntilChanged, filter, share, switchMap } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';
import { Alias } from '../../shared/models/alias.model';
import { AliasService } from '../../shared/services/alias.service';
import { UserService } from '../../shared/services/user.service';
import { UserSearchService } from '../shared/user-search.service';

@Component({
  selector: 'app-impersonation-card',
  templateUrl: './impersonation-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ImpersonationCardComponent')
export class ImpersonationCardComponent implements OnInit {
  busy = false;
  config: any;
  errorMessage: string;
  impersonation: Alias;
  mode = '';
  newForm: FormGroup;
  searchForm: FormGroup;
  searchMatches: any[];
  usable: any;
  userSelected = false;
  userTotal = 0;

  constructor(
    private fb: FormBuilder,
    private aliasService: AliasService,
    private userService: UserService,
    private userSearchService: UserSearchService
  ) { }

  ngOnInit() {
    if (this.aliasService.current !== undefined) {
      this.impersonation = this.aliasService.current;
    } else {
      this.aliasService.observeCurrent.subscribe(a => {
        this.impersonation = a;
      });
    }

    // this.createForm();

    this.createSearchForm();

    this.searchControl.valueChanges.pipe(
      filter(val => {
        const st = val.trim();
        return st.length > 3 || st.length === 0;
      }),
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(val => this.doSearch(val))
    ).subscribe(countAndData => {
      this.userTotal = countAndData.count || 0;
      this.searchMatches = countAndData.data;
      this.busy = false;
    });
  }

  // createForm() {
  //   this.newForm = this.fb.group({
  //     aliasEmail: ['',
  //       [
  //         regexValidator(/^.+@.+\..+$/, 'email', 'Must be a valid email address.')
  //       ]]
  //   });
  // }

  createSearchForm() {
    console.log('creating form');
    this.searchForm = this.fb.group({
      search: ''
    });
  }

  get searchControl() {
    return this.searchForm.get('search');
  }

  doSearch(search) {
    const st = search.trim().length < 1 ? null : search.trim();
    // reset?
    if (!st || st.length < 1) {
      this.userTotal = 0;
      this.searchMatches = [];
      return Observable.of([]).pipe(share());
    } else {
      this.busy = true;
      return this.userSearchService.searchByTenant(st, 0, 10);
    }
  }

  beYourself() {
    this.busy = true;
    this.aliasService.beYourself()
      .subscribe((res: Alias) => {
        this.impersonation = res;
        this.busy = false;
      });
  }

  impersonate() {
    this.busy = true;
    this.errorMessage = '';
    this.aliasService.impersonate(this.searchControl.value)
      .subscribe((res: Alias) => {
        this.busy = false;
        this.impersonation = res;
        this.toggleEditor();

      }, (errResp: any) => {
        this.busy = false;
        this.errorMessage = errResp.message;
      });
  }

  // onSubmit() {
  //   this.busy = true;
  //   this.errorMessage = '';
  //   this.aliasService.impersonate(this.newForm.get('aliasEmail').value)
  //     .subscribe((res: Alias) => {
  //       this.busy = false;
  //       this.impersonation = res;
  //       this.toggleEditor();
  //       if (window.confirm('To effect this change in impersonation, you must log out. Do you wish to logout now?')) {
  //         this.userService.startSignoutMainWindow();
  //       }
  //     }, (errResp: any) => {
  //       this.busy = false;
  //       this.errorMessage = errResp.message;
  //     });
  // }

  toggleEditor() {
    this.mode = this.mode === 'add' ? '' : 'add';
  }

}
