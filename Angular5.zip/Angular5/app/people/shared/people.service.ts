import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { Person, RolePercent } from '../../shared/models/person.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class PeopleService {
  private apiUrl = 'people/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, limit: number): Observable<Person[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('contractId', search);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => this.extractGrouped(res)),
      map(data => data.slice(0, limit || data.length)),
      catchError(this.loggingService.handleError));
  }

  find(id): Observable<Person> {
    return this.http.authGet(this.apiUrl + id).pipe(
      map(res => res.json() as Person),
      catchError(this.loggingService.handleError));
  }

  private extract(res: Response): Person[] {
    const data = res.json() as Person[];
    this.lastCount.next(data.length);
    return data;
  }

  private extractGrouped(res: Response): Person[] {
    const people = this.group(this.extract(res));
    return people;
  }

  private group(people: Person[]): Person[] {
    return people.reduce((memo: Person[], p) => {
      const groupedItem = memo.find(g => g.firstName === p.firstName && g.lastName === p.lastName && g.taxIdLast4 === p.taxIdLast4);
      if (groupedItem === undefined) {
        p.groupedRoles = [];
        p.groupedRoles.push(new RolePercent(p.role, p.splitPercent));
        memo.push(p);
      } else {
        groupedItem.groupedRoles.push(new RolePercent(p.role, p.splitPercent));
      }
      return memo;
    }, []);
  }
}
