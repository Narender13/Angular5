import { Component, Input } from '@angular/core';
import { Person } from '../../shared/models/person.model';

@Component({
  selector: 'app-address-chip',
  templateUrl: './address-chip.component.html',
  styles: []
})
export class AddressChipComponent {
  className = 'AddressChipComponent';
  @Input() person: Person;

  constructor() { }
}
