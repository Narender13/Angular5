import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { AddressChipComponent } from './address-chip/address-chip.component';
import { PeopleDetailComponent } from './people-detail/people-detail.component';
import { PeopleCardComponent } from './people-card/people-card.component';
import { PeopleChipComponent } from './people-chip/people-chip.component';
import { PeopleGridComponent } from './people-grid/people-grid.component';
import { PeopleListComponent } from './people-list/people-list.component';
import { PeopleRoutingModule } from './people-routing.module';
import { PeopleService } from './shared/people.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    AddressChipComponent,
    PeopleDetailComponent,
    PeopleCardComponent,
    PeopleChipComponent,
    PeopleGridComponent,
    PeopleListComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    PeopleRoutingModule,
    SharedModule
  ],
  exports: [
    AddressChipComponent,
    PeopleCardComponent,
    PeopleChipComponent
  ],
  providers: [
    PeopleService
  ]
})
export class PeopleModule { }
