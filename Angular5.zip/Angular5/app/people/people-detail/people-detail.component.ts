import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { switchMap, share, tap } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { PeopleService } from '../shared/people.service';
import { Person } from '../../shared/models/person.model';

@Component({
  selector: 'app-people-detail',
  templateUrl: './people-detail.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('PeopleDetailComponent')
export class PeopleDetailComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  list: Observable<Person[]>;
  loading = true;
  localized: any;

  constructor(
    private route: ActivatedRoute,
    private service: PeopleService
  ) { }

  ngOnInit() {
    this.localized = this.config.translated;
    this.list = this.route.params.pipe(
      tap(_ => this.loading = true),
      switchMap((params: { contractId: string, limit: number, offset: number }) => {
        return this.service.list(params.contractId, params.limit);
      }),
      tap(_ => this.loading = false),
      share()
    );
    this.count = this.service.count().pipe(share());
  }
}
