import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PeopleDetailComponent } from '../people/people-detail/people-detail.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const peopleRoutes: Routes = [
  {
    path: 'contracts/:contractId/people', component: PeopleDetailComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(peopleRoutes)],
  exports: [RouterModule]
})
export class PeopleRoutingModule { }
