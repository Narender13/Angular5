import { Component, Input } from '@angular/core';

import { Person } from '../../shared/models/person.model';

@Component({
  selector: 'app-people-chip',
  templateUrl: './people-chip.html',
  styles: [':host{width:100%;}']
})
export class PeopleChipComponent {
  @Input() person: Person;

  constructor() { }
}
