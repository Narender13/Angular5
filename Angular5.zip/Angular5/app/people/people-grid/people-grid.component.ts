import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Person } from '../../shared/models/person.model';
import { PeopleService } from '../shared/people.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-people-grid',
  templateUrl: './people-grid.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('PeopleGridComponent')
export class PeopleGridComponent implements Configurable, OnInit {
  @Input() people: Person[];
  config: any;
  count: number;
  selected: Person;
  quickView = false;
  sortFields: string[] = ['role', 'entityName'];
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: PeopleService
  ) { }

  ngOnInit() {
    this.route.params
      .switchMap((params: { contractId: string, limit: number, offset: number }) => {
        return this.service.list(params.contractId, params.limit);
      })
      .subscribe((res: Person[]) => {
        this.people = res;
      });

    this.service.count()
      .subscribe((res: number) => {
        this.count = res;
      });
  }
  setSelectedPerson(person: Person) {
    this.selected = person;
    this.quickView = true;
  }
  unSelect() {
    this.selected = null;
    this.quickView = false;
  }
}
