import { Component, Input } from '@angular/core';

import { Person } from '../../shared/models/person.model';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.html',
  styles: []
})
export class PeopleListComponent {
  @Input() people: Person[];

  constructor() { }
}
