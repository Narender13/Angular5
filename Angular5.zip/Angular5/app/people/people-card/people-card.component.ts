import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { Person } from '../../shared/models/person.model';
import { PeopleService } from '../shared/people.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-people-card',
  templateUrl: './people-card.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('PeopleCardComponent')
export class PeopleCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  limit = 5;
  people: Observable<Person[]>;
  usable: any;

  constructor(
    private route: ActivatedRoute,
    private service: PeopleService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;
    this.limit = this.config.cardLimit || this.limit;
    this.people = this.service.list(contractId, this.limit).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
