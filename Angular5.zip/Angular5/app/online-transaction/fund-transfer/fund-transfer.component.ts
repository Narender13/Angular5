import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
import { ContractFund } from '../../shared/models/contract-fund.model';
import { OnlineTransaction, OnlineTransactionType, FundTransaction } from '../../shared/models/online-transaction.model';
import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { TransactionValidators } from 'app/online-transaction/shared/transaction-validator';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { debounceTime, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.scss']
})
@AutoUnsubscribe()
@Configure('FundTransferComponent')
export class FundTransferComponent implements Configurable, OnInit {
  allocationFromForm: FormGroup;
  allocationToForm: FormGroup;
  config: any;
  confirmNumber: string;
  contractId: string;
  contractNumber: string;
  effectiveDate: string;
  firstSubmitClick = false;
  fromAllocations: ContractFund[] = [];
  loadingFunds = true;
  localized: any;
  option: string = null;
  originalFromFunds: ContractFund[] = [];
  originalFunds: ContractFund[] = [];
  ownerName: string;
  productId: string;
  selectedFromAllocation: ContractFund = null;
  selectedToAllocation: ContractFund = null;
  submitDateTimestamp: string;
  submitted = false;
  submittedResponse = null;
  toAllocations: ContractFund[] = [];
  totalFundValue: number;
  transactionForm: FormGroup;
  transferOptions: string[] = ['Percentage-to-percentage', 'Dollar-to-dollar', 'Dollar-to-percentage'];
  usable: boolean;
  warnings: string[];

  get availableFromFunds(): ContractFund[] {
    let usedFunds = this.fromAllocations.map(f => new ContractFund(f));
    if (this.selectedFromAllocation) {
      usedFunds = usedFunds.filter(f => f.fundId !== this.selectedFromAllocation.fundId);
    }
    return (this.originalFromFunds || [])
      .filter(item => !usedFunds.some(f => f.fundName === item.fundName));
  }

  get availableToFunds(): ContractFund[] {
    let usedFunds = this.toAllocations.map(f => new ContractFund(f));
    if (this.selectedToAllocation) {
      usedFunds = usedFunds.filter(f => f.fundId !== this.selectedToAllocation.fundId);
    }
    return (this.originalFunds || [])
      .filter(item => !usedFunds.some(f => f && (f.fundName === item.fundName)));
  }

  get toTotal(): number {
    return this.toAllocations
      .map(alloc => alloc.amount)
      .reduce((memo, amount) => memo + amount, 0);
  }

  get fromTotal(): number {
    return this.fromAllocations
      .map(alloc => alloc.amount)
      .reduce((memo, amount) => memo + amount, 0);
  }

  get availableFromAllocationTotal(): number {
    return this.fromAllocations
      .map(alloc => alloc !== this.selectedFromAllocation && alloc.amount)
      .reduce((memo, amount) => memo + amount, 0);
  }

  get availableToAllocationTotal(): number {
    return this.toAllocations
      .map(alloc => alloc !== this.selectedToAllocation && alloc.amount)
      .reduce((memo, amount) => memo + amount, 0);
  }

  errors = {
    option: null,
    toFund: null,
    toAmount: null,
    fromTotal: null,
    toTotal: null,
    fromFund: null,
    fromAmount: null
  };

  private ngUnsubscribe: Subject<void> = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private service: OnlineTransactionService,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private userService: UserService
  ) {

  }

  ngOnInit(): void {
    this.route.params.subscribe((params: { id: string }) => {
      if (params.id !== undefined) {
        this.contractId = params.id;
        // Temporarily hijacking ContractId constraint when it is coming in as LC~539~7100000950
        const contractParts = this.contractId.split('~');
        if (contractParts.length === 3) {
          this.contractNumber = contractParts[2];
        }
        this.service.types(params.id).subscribe(res => {
          this.service.funds(params.id)
            .subscribe(contractFunds => {
              this.loadingFunds = false;
              // get funds that have values for "From" List
              this.originalFromFunds = this.getFundsInvested(contractFunds);
              this.totalFundValue = this.getTotalFundValue(this.originalFromFunds);
              // "To" List is just all funds
              this.originalFunds = contractFunds;
            });
          this.service.contract(this.contractId)
            .subscribe(c => { this.productId = c.productId; this.ownerName = c.personName; });
        });
      }
    });
    this.localized = this.config.translated;
    this.buildForms(null);
  }

  buildForms(transferType: string) {
    this.option = transferType;
    const validators = this.configureValidators(transferType);
    this.allocationFromForm = this.fb.group({
      fromFund: [null, validators.get('fromFund')],
      fromAmount: [null, validators.get('fromAmount')],
      selectedFundFromAmount: [null]
    });
    this.allocationToForm = this.fb.group({
      toFund: [null, validators.get('toFund')],
      toAmount: [null, validators.get('toAmount')]
    });
    this.transactionForm = this.fb.group({
      fromTotal: [0, validators.get('fromTotal')],
      toTotal: [0, validators.get('toTotal')],
      option: [transferType, validators.get('option')]
    });
    if (transferType === 'Dollar-to-dollar') {
      const transactionForm = this.transactionForm;
      transactionForm.get('toTotal').setValidators([Validators.min(1), TransactionValidators.equalTo(transactionForm.get('fromTotal'))]);
    }
  }

  addFromAllocation(): void {
    this.addAllocation(this.allocationFromForm, this.fromAllocations);
  }

  addToAllocation(): void {
    this.addAllocation(this.allocationToForm, this.toAllocations);
  }

  setTransferType(value: string): void {
    this.resetAllocations();
    this.buildForms(value);
  }

  syncTotal(): void {
    this.transactionForm.patchValue({ fromTotal: this.fromTotal });
    this.transactionForm.patchValue({ toTotal: this.toTotal });
  }

  subsubcribeFormChange() {
    this.allocationFromForm.valueChanges.pipe(
      debounceTime(500),
      takeUntil(this.ngUnsubscribe)
    ).subscribe(() => this.compileErrors(this.allocationFromForm));

    this.allocationToForm.valueChanges.pipe(
      debounceTime(500),
      takeUntil(this.ngUnsubscribe)
    ).subscribe(() => this.compileErrors(this.allocationToForm));
  }

  resetErrors() {
    for (const field of Object.keys(this.errors)) {
      this.errors[field] = '';
    }
  }

  compileErrors(form: FormGroup, ignoreDirty?: boolean) {
    for (const field of Object.keys(this.errors)) {
      const control = form.get(field);
      if (ignoreDirty !== null) {
        this.errors[field] = '';
      }
      if (form.contains(field) && (control && control.dirty || ignoreDirty)) {
        if (!control.valid) {
          for (const key of Object.keys(control.errors)) {
            this.errors[field] += this.errors[field] += this.localized.messages[field][key];
          }
        }
      }
    }
  }

  resetSelectedFundFromAmount(): void {
    const form = this.allocationFromForm;
    const fund = this.originalFromFunds.find(f => f.fundId === form.get('fromFund').value);
    form.patchValue({ selectedFundFromAmount: fund.amount });
  }

  startEdit(allocation: ContractFund, form: FormGroup): void {
    this.submittedResponse = null;
    switch (form) {
      case this.allocationFromForm:
        this.selectedFromAllocation = allocation;
        const fund = this.originalFromFunds.find(f => f.fundId === allocation.fundId);
        form.setValue({
          fromFund: allocation.fundId,
          fromAmount: allocation.amount,
          selectedFundFromAmount: fund.amount
        });
        break;
      case this.allocationToForm:
        this.selectedToAllocation = allocation;
        form.setValue({
          toFund: allocation.fundId,
          toAmount: allocation.amount
        });
        break;
      default:
        break;
    }
  }

  cancelEdit(form: FormGroup): void {
    if (form === this.allocationFromForm) { this.selectedFromAllocation = null; }
    if (form === this.allocationToForm) { this.selectedToAllocation = null; }
    form.reset();
  }

  removeAllocation(form: FormGroup): void {
    switch (form) {
      case this.allocationFromForm:
        const fromallocation = this.selectedFromAllocation;
        const fromIndex = this.fromAllocations.indexOf(fromallocation);
        if (fromIndex !== -1) {
          this.fromAllocations.splice(fromIndex, 1);
        }
        break;
      case this.allocationToForm:
        const toallocation = this.selectedToAllocation;
        const toIndex = this.toAllocations.indexOf(toallocation);
        if (toIndex !== -1) {
          this.toAllocations.splice(toIndex, 1);
        }
        break;
      default:
        break;
    }
    this.syncTotal();
    this.cancelEdit(form);
  }

  updateAllocation(form: FormGroup): void {
    this.resetErrors();
    if (!form.valid) {
      return this.compileErrors(form, true);
    }
    switch (form) {
      case this.allocationFromForm:
        const fromAllocation = this.selectedFromAllocation;
        const fromFund = this.originalFromFunds.find(f => f.fundId === form.get('fromFund').value);
        fromAllocation.fundId = fromFund.fundId;
        fromAllocation.fundName = fromFund.fundName;
        fromAllocation.amount = form.get('fromAmount').value;
        this.cancelEdit(form);
        break;
      case this.allocationToForm:
        const toAllocation = this.selectedToAllocation;
        const toFund = this.originalFunds.find(f => f.fundId === form.get('toFund').value);
        toAllocation.fundId = toFund.fundId;
        toAllocation.fundName = toFund.fundName;
        toAllocation.amount = form.get('toAmount').value;
        this.cancelEdit(form);
        break;
    }
    this.syncTotal();
  }

  investedAmount(allocation: ContractFund): string {
    const amount = this.originalFunds.find(f => f.fundName === allocation.fundName).amount || null;
    return amount ? amount.toString() : 'err';
  }

  formatAmount(value: string, allocationType: string): string {
    const transferType = this.transactionForm.value.option;
    if (transferType === 'Dollar-to-dollar' || transferType === 'Dollar-to-percentage' && allocationType === 'from') {
      return '$' + parseFloat(value);
    } else {
      return value + '%';
    }
  }

  submitTransaction() {
    this.submitted = false;
    this.submittedResponse = null;
    const form = this.transactionForm;
    this.resetErrors();
    if (!form.valid) {
      return this.compileErrors(form, true);
    }

    this.firstSubmitClick = true;

    const transaction = new OnlineTransaction();
    transaction.contractId = this.contractId;
    transaction.userName = this.userService.user.profile.name;
    transaction.transactionType = OnlineTransactionType.FundTransfer;
    transaction.productId = this.productId;
    transaction.ownerName = this.ownerName;

    const transferType = this.transactionForm.value.option;
    let fromType = 'P';
    let toType = 'P';

    if (transferType === 'Dollar-to-percentage') {
      fromType = 'D';
      toType = 'P';
    } else if (transferType === 'Dollar-to-dollar') {
      fromType = 'D';
      toType = 'D';
    }

    // assumption is the asset source is the same for all funds for contract
    const fund = this.originalFunds.find(f => f.fundId === this.fromAllocations[0].fundId);
    transaction.assetSource = fund.assetSource;

    const ft = new Array<FundTransaction>();
    this.fromAllocations.forEach(a => {
      const f = new FundTransaction();
      f.fundId = a.fundId;
      f.amountType = fromType;             // D/P : Dollar or Percent
      f.direction = 'F';           // T/F : To or From
      f.amount = a.amount;
      f.fundName = a.fundName;
      ft.push(f);
    });
    this.toAllocations.forEach(a => {
      const f = new FundTransaction();
      f.fundId = a.fundId;
      f.amountType = toType;             // D/P : Dollar or Percent
      f.direction = 'T';           // T/F : To or From
      f.amount = a.amount;
      f.fundName = a.fundName;
      ft.push(f);
    });
    transaction.funds = ft;

    // Block transaction if a soft-closed fund is used as a To fund
    const softCloseFunds = this.originalFunds.filter(f => f.softClose === 1);

    if (softCloseFunds.some(f => {
      const transactionFund = transaction.funds.find(tf => tf.fundId === f.fundId && tf.direction === 'T');
      if (transactionFund != null) {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'Cannot use soft-closed fund:  ' + f.fundName;
        return true;
      }
    })) {
      return;
    }

    this.service.save(transaction).subscribe(res => {
      if (res.success && !res.hasErrors) {
        this.submittedResponse = 'The transaction has been submitted.';
        this.confirmNumber = res.confirmNumber;
        this.submitDateTimestamp = res.submitDateTime.toString();
        this.effectiveDate = res.effectiveDate.toString();
        if (res.hasWarnings && res.warnings.length > 0) {
          this.warnings = res.warnings;
        }
        this.submitted = true;
      } else {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'The transaction encountered the following problem(s): [' + res.errors + ']';
      }
    });
  }

  resetAllocations() {
    this.fromAllocations.length = 0;
    this.toAllocations.length = 0;
    this.cancelEdit(this.allocationFromForm);
    this.cancelEdit(this.allocationToForm);
    this.compileErrors(this.transactionForm, false);
    this.submitted = false;
    this.submittedResponse = null;
  }

  private getFundsInvested(contractFunds: ContractFund[]) {
    return contractFunds.filter(f => f.amount && f.amount > 0);
  }

  private getTotalFundValue(contractFunds: ContractFund[]) {
    let total = 0;
    contractFunds.forEach(cf => {
      if (cf.amount && cf.amount > 0) {
        total += cf.amount;
      }
    });
    return total;
  }

  private configureValidators(transferType: string): Map<string, any> {
    const config = new Map();
    config.set('option', [Validators.required]);
    config.set('fromFund', [Validators.required]);
    config.set('toFund', [Validators.required]);
    config.set('fromTotal', Validators.min(1));

    switch (transferType) {
      case 'Percentage-to-percentage':
        config.set('fromAmount', [
          Validators.required,
          Validators.min(1),
          Validators.max(100),
          TransactionValidators.integer
        ]);
        config.set('toAmount', config.get('fromAmount'));
        config.set('toTotal', [Validators.min(1), TransactionValidators.equal(100)]);
        break;
      case 'Dollar-to-percentage':
        config.set('fromAmount', [
          Validators.required,
          TransactionValidators.fundAmount
        ]);
        config.set('toAmount', [
          Validators.required,
          Validators.min(1),
          Validators.max(100),
          TransactionValidators.integer
        ]);
        config.set('toTotal', [Validators.min(1), TransactionValidators.equal(100)]);
        break;
      case 'Dollar-to-dollar':
        config.set('fromAmount', [
          Validators.required,
          TransactionValidators.fundAmount
        ]);
        config.set('toAmount', Validators.required);
        config.set('toTotal', [Validators.min(1), TransactionValidators.equalTo(config.get('fromTotal'))]);
        break;
      default:
        break;
    }
    return config;
  }

  private addAllocation(form: FormGroup, list: ContractFund[]) {
    this.resetErrors();
    if (!form.valid) {
      return this.compileErrors(form, true);
    }
    const allocation = new ContractFund();
    switch (form) {
      case this.allocationFromForm:
        const fromFund = this.originalFromFunds.find(f => f.fundId === form.get('fromFund').value);
        allocation.fundId = fromFund.fundId;
        allocation.fundName = fromFund.fundName;
        allocation.amount = form.get('fromAmount').value;
        // tslint:disable-next-line:no-string-literal
        this.errors['fromTotal'] = '';
        list.push(allocation);
        break;
      case this.allocationToForm:
        const toFund = this.originalFunds.find(f => f.fundId === form.get('toFund').value);
        allocation.fundId = toFund.fundId;
        allocation.fundName = toFund.fundName;
        allocation.amount = form.get('toAmount').value;
        // tslint:disable-next-line:no-string-literal
        this.errors['toTotal'] = '';
        list.push(allocation);
        break;
      default:
        break;
    }
    this.syncTotal();
    return true;
  }
}
