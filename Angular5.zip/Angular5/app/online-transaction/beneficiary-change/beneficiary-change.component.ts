import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { PeopleService } from 'app/people/shared/people.service';
import { Person } from 'app/shared/models/person.model';
import { Observable } from 'rxjs/Observable';
import { share, debounceTime } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { fastRelationshipToOwner } from '../../shared/models/fast-relationshipToOwner';
import { fastRoles } from '../../shared/models/fast-roles';
import { Beneficiary, OnlineTransaction, OnlineTransactionResponse, OnlineTransactionType } from '../../shared/models/online-transaction.model';
import { states } from '../../shared/models/states';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-beneficiary-change',
  templateUrl: './beneficiary-change.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('BeneficiaryChangeComponent')
export class BeneficiaryChangeComponent implements Configurable, OnInit {
  changeBeneficiaryForm: FormGroup;
  addBeneficiaryForm: FormGroup;
  addNewBeneDetailsForm: FormGroup;
  config: any;
  contractId: string;
  localized: any;
  states: Array<any>;
  roles: Array<any>;
  relationshipToOwner: Array<any>;
  response: OnlineTransactionResponse;
  currentDate = Date.now();
  submitted = false;
  showAddBene = false;
  totalPrimeBenePercent = 0;
  totalContingentBenePercent = 0;
  newPeople: Beneficiary[];
  submitDateTimestamp: string;
  warnings: string[];
  confirmNumber: string;
  effectiveDate: string;
  submittedResponse: string;
  firstSubmitClick = false;

  makeAChoice = [{ 'name': 'Update existing beneficiary info', 'value': '1' },
  { 'name': 'Add or delete beneficiary/Edit percentage allocation', 'value': '2' }];
  choice: string;

  gender = ['Male', 'Female', 'Other'];
  phoneType: string;
  selectedPerson: any;
  people: Observable<Person[]>;
  beneficiaries: Person[];
  contingentBeneficiary: Person[];
  primaryBeneficiary: Person[];
  // controls: any[];
  editBeneInfoErrors = {
    relationshipToOwner: null,
    dateOfBirth: null,
    lastName: null,
    gender: null,
    addressId: null,
    address1: null,
    city: null,
    country: null,
    state: null,
    zipCode: null,
    businessPhone: null,
    cellPhone: null,
    homePhone: null,
    email: null
  };
  addBeneErrors = {
    addBeneFirstName: null,
    addBeneLastName: null,
    addBeneGender: null,
    addBeneDOB: null,
    addBeneAddress1: null,
    addBeneCity: null,
    addBeneState: null,
    addBeneZip: null,
    addBeneCountry: null,
    addBeneRelationship: null,
    addBeneRole: null,
    addBeneTaxId: null,
    addBeneBusinessPhone: null,
    addBeneCellPhone: null,
    addBeneHomePhone: null,
    addBeneEmail: null
  };
  editBenePercentError = {
    totalPrimeBenePercent: null,
    totalContingentBenePercent: null
  };
  usable: boolean;

  constructor(
    private route: ActivatedRoute,

    private fb: FormBuilder,
    private service: OnlineTransactionService,
    private peopleService: PeopleService,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.localized = this.config.translated;
    const routeParams = this.route.snapshot.params as { id: string };
    this.contractId = routeParams.id;
    this.states = states;
    this.roles = fastRoles;
    this.relationshipToOwner = fastRelationshipToOwner;
  }

  onChange(event, value) {
    this.people = this.peopleService.list(this.contractId, 0).pipe(share());
    this.choice = value;
    this.selectedPerson = null;
    this.response = null;
    this.submitted = false;
    if (value === '1') {
      // this.changeBeneficiaryForm.reset();
      this.people.subscribe(person => {
        this.beneficiaries = person.filter(p => (p.role === 'Beneficiary' || p.role === 'Contingent Beneficiary') && p.personType === 'Person');
      });
    }

    if (value === '2') {
      this.buildAddBeneForm();
      // this.addBeneficiaryForm.reset();
      this.response = null;
      this.showAddBene = false;
      this.addNewBeneDetailsForm.disable();
      this.people
        .subscribe(item => {
          this.primaryBeneficiary = item.filter(a => a.role === 'Beneficiary');
          this.contingentBeneficiary = item.filter(a => a.role === 'Contingent Beneficiary');
          if (this.contingentBeneficiary.length === 0) {
            this.addBeneficiaryForm.get('totalContingentBenePercent').setValue(100);
          }
          // this.buildForms();
          this.updateForm();
        });
    }
  }
  buildEditBeneForm() {
    this.changeBeneficiaryForm = this.fb.group({
      personId: [this.selectedPerson.id, Validators.required],
      personType: [this.selectedPerson.personType],
      addressType: [this.selectedPerson.addressType],
      firstName: [this.selectedPerson.firstName, Validators.required],
      middleInitial: [this.selectedPerson.middleInitial],
      lastName: [this.selectedPerson.lastName, Validators.required],
      gender: [this.selectedPerson.gender, Validators.required],
      email: [this.selectedPerson.email, Validators.pattern(/^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i)],
      address1: [this.selectedPerson.address1, [Validators.required, Validators.pattern(/^[a-z\d\-.\s]+$/i)]],
      address2: [this.selectedPerson.address2],
      address3: [this.selectedPerson.address3],
      city: [this.selectedPerson.city, [Validators.required, Validators.pattern(/^[a-z\d\-_.\s]+$/i)]],
      state: [this.selectedPerson.state, Validators.required],
      zipCode: [this.selectedPerson.zipCode, [Validators.required, Validators.pattern(/^\d{5}(-\d{4})?$/)]],
      country: ['USA', Validators.required],
      dateOfBirth: [this.selectedPerson.dateOfBirth, Validators.required],
      businessPhone: ['', Validators.pattern(/^\d{10}$/)],
      cellPhone: ['', Validators.pattern(/^\d{10}$/)],
      homePhone: ['', Validators.pattern(/^\d{10}$/)],
      relationshipToOwner: [this.selectedPerson.relationshipToOwner, Validators.required]
    });
    this.changeBeneficiaryForm.valueChanges.pipe(
      debounceTime(500)
    ).subscribe(item => {
      this.compileErrors();
    });
    this.changeBeneficiaryForm.controls.middleInitial.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.middleInitial) {
          this.changeBeneficiaryForm.controls.middleInitial.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.lastName.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.lastName) {
          this.changeBeneficiaryForm.controls.lastName.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.gender.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.gender) {
          this.changeBeneficiaryForm.controls.gender.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.email.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.email) {
          this.changeBeneficiaryForm.controls.email.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.address1.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.address1) {
          this.changeBeneficiaryForm.controls.address1.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.address2.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.address2) {
          this.changeBeneficiaryForm.controls.address2.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.address3.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.address3) {
          this.changeBeneficiaryForm.controls.address3.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.city.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.city) {
          this.changeBeneficiaryForm.controls.city.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.state.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.state) {
          this.changeBeneficiaryForm.controls.state.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.zipCode.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.zipCode) {
          this.changeBeneficiaryForm.controls.zipCode.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.dateOfBirth.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.dateOfBirth) {
          this.changeBeneficiaryForm.controls.dateOfBirth.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.relationshipToOwner.valueChanges
      .subscribe(v => {
        if (v === this.selectedPerson.relationshipToOwner) {
          this.changeBeneficiaryForm.controls.relationshipToOwner.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.businessPhone.valueChanges
      .subscribe(v => {
        if (!this.selectedPerson.phoneType && !v) {
          this.changeBeneficiaryForm.controls.businessPhone.markAsPristine();
        }
        if (this.selectedPerson.phoneType === 'BU' && v === this.selectedPerson.phoneNumber) {
          this.changeBeneficiaryForm.controls.businessPhone.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.cellPhone.valueChanges
      .subscribe(v => {
        if (!this.selectedPerson.phoneType && !v) {
          this.changeBeneficiaryForm.controls.cellPhone.markAsPristine();
        }
        if (this.selectedPerson.phoneType === 'CELL' && v === this.selectedPerson.phoneNumber) {
          this.changeBeneficiaryForm.controls.cellPhone.markAsPristine();
        }
      });
    this.changeBeneficiaryForm.controls.homePhone.valueChanges
      .subscribe(v => {
        if (!this.selectedPerson.phoneType && !v) {
          this.changeBeneficiaryForm.controls.homePhone.markAsPristine();
        }
        if (this.selectedPerson.phoneType === 'HO' && v === this.selectedPerson.phoneNumber) {
          this.changeBeneficiaryForm.controls.cellPhone.markAsPristine();
        }
      });
  }
  buildAddBeneForm() {
    this.addNewBeneDetailsForm = this.fb.group({
      addBeneId: [''],
      addBeneTaxId: ['', [Validators.required, Validators.pattern(/^\d{9}$/)]],
      addBeneFirstName: ['', Validators.required],
      addBeneMiddleInitial: [''],
      addBeneLastName: ['', Validators.required],
      addBeneGender: ['', Validators.required],
      addBeneRelationship: ['', Validators.required],
      addBeneRole: ['', Validators.required],
      addBeneEmail: ['', Validators.pattern(/^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i)],
      addBeneAddressId: [''],
      addBeneAddressType: [''],
      addBeneAddress1: ['', [Validators.required, Validators.pattern(/^[a-z\d\-.\s]+$/i)]],
      addBeneAddress2: [''],
      addBeneAddress3: [''],
      addBeneCity: ['', [Validators.required, Validators.pattern(/^[a-z\d\-_.\s]+$/i)]],
      addBeneState: ['', Validators.required],
      addBeneCountry: ['USA'],
      addBeneZip: ['', [Validators.required, Validators.pattern(/^\d{5}(-\d{4})?$/)]],
      addBeneDOB: ['', Validators.required],
      addBeneBusinessPhone: ['', Validators.pattern(/^\d{10}$/)],
      addBeneCellPhone: ['', Validators.pattern(/^\d{10}$/)],
      addBeneHomePhone: ['', Validators.pattern(/^\d{10}$/)]
    });

    this.addBeneficiaryForm = this.fb.group({
      allPrimeBeneControls: this.fb.array([]),
      allContingentBeneControls: this.fb.array([]),
      totalPrimeBenePercent: ['', Validators.pattern(/^100$/)],
      totalContingentBenePercent: ['', Validators.pattern(/^100$/)],
      addNewBeneDetails: this.addNewBeneDetailsForm
    });
    this.addBeneficiaryForm.valueChanges.pipe(
      debounceTime(500)
    ).subscribe(item => {
      this.syncTotalPrimeBenePercent();
      this.syncTotalContingentBenePercent();
      this.compileEditPercentError();
      this.checkPristine();
    });
    this.addNewBeneDetailsForm.valueChanges.pipe(
      debounceTime(500)
    ).subscribe(item => {
      this.compileAddNewBeneFormErrors();
    });
  }

  updateForm() {

    const primeBeneControls = this.primaryBeneficiary.length > 0 && this.primaryBeneficiary.map((c, i) => this.fb.group({
      primeBeneId: [c.id],
      primeBenePersonType: [c.personType],
      primeBeneAddressType: [c.addressType],
      primeBeneTaxId: [c.taxIdLast4],
      primeBeneFirstName: [c.firstName],
      primeBeneMiddleInitial: [c.middleInitial],
      primeBeneLastName: [c.lastName],
      primeBeneGender: [c.gender],
      primeBeneRelationship: [c.relationshipToOwner],
      primeBenePercent: [c.splitPercent, [Validators.required, Validators.min(1), Validators.max(100)]],
      primeBeneRole: [c.role],
      primeBeneEmail: [c.email],
      primeBeneAddress1: [c.address1],
      primeBeneAddress2: [c.address2],
      primeBeneAddress3: [c.address3],
      primeBeneCity: [c.city],
      primeBeneState: [c.state],
      primeBeneCountry: [c.country],
      primeBeneZip: [c.zipCode],
      primeBeneDOB: [c.dateOfBirth],
      primeBeneBusinessPhone: [''],
      primeBeneCellPhone: [''],
      primeBeneHomePhone: ['']
    }));
    const contingentBeneControls = this.contingentBeneficiary.length > 0 && this.contingentBeneficiary.map(c => this.fb.group({
      contingentBeneId: [c.id],
      contingentBenePersonType: [c.personType],
      contingentBeneAddressType: [c.addressType],
      contingentBeneTaxId: [c.taxIdLast4],
      contingentBeneFirstName: [c.firstName],
      contingentBeneMiddleInitial: [c.middleInitial],
      contingentBeneLastName: [c.lastName],
      contingentBeneGender: [c.gender],
      contingentBeneRelationship: [c.relationshipToOwner],
      contingentBenePercent: [c.splitPercent, [Validators.required, Validators.min(1), Validators.max(100)]],
      contingentBeneRole: [c.role],
      contingentBeneEmail: [c.email],
      contingentBeneAddress1: [c.address1],
      contingentBeneAddress2: [c.address2],
      contingentBeneAddress3: [c.address3],
      contingentBeneCity: [c.city],
      contingentBeneState: [c.state],
      contingentBeneCountry: [c.country],
      contingentBeneZip: [c.zipCode],
      contingentBeneDOB: [c.dateOfBirth],
      contingentBeneBusinessPhone: [''],
      contingentBeneCellPhone: [''],
      contingentBeneHomePhone: ['']
    }));

    const primeBeneFormArray = primeBeneControls.length > 0 && this.fb.array(primeBeneControls) || this.fb.array([]);
    const contingentBeneFormArray = contingentBeneControls.length > 0 && this.fb.array(contingentBeneControls) || this.fb.array([]);
    this.addBeneficiaryForm.setControl('allPrimeBeneControls', primeBeneFormArray);
    this.addBeneficiaryForm.setControl('allContingentBeneControls', contingentBeneFormArray);
    this.syncTotalPrimeBenePercent();
    this.syncTotalContingentBenePercent();
  }

  get allPrimeBeneControls(): FormArray {
    return this.addBeneficiaryForm.get('allPrimeBeneControls') as FormArray;
  }
  get allContingentBeneControls(): FormArray {
    return this.addBeneficiaryForm.get('allContingentBeneControls') as FormArray;
  }

  getSelectedPerson(event, id) {
    if (id) {
      this.selectedPerson = null;
      this.response = null;
      this.submitted = false;
      this.people.subscribe(person => {
        this.selectedPerson = person.find(p => p.id === id);
        this.buildEditBeneForm();
        // this.changeBeneficiaryForm.patchValue(this.selectedPerson);
        if (this.selectedPerson.dateOfBirth) {
          const dp = new DatePipe(navigator.language);
          const p = 'yyyy-MM-dd';
          const dtr = dp.transform(this.selectedPerson.dateOfBirth, p);
          this.changeBeneficiaryForm.get('dateOfBirth').setValue(dtr);
        }
        if (this.selectedPerson.relationshipToOwner) {

          if (!this.relationshipToOwner.find(rel => rel === this.selectedPerson.relationshipToOwner)) {
            this.changeBeneficiaryForm.get('relationshipToOwner').setValue(null);
            this.changeBeneficiaryForm.get('relationshipToOwner').markAsDirty();
          }
        }
        if (this.selectedPerson.state && !this.states.find(state => state === this.selectedPerson.state)) {
          this.changeBeneficiaryForm.get('state').setValue(null);
          this.changeBeneficiaryForm.get('state').markAsDirty();
        }
        switch (this.selectedPerson.phoneType) {
          case 'HO': {
            this.changeBeneficiaryForm.get('homePhone').setValue(this.selectedPerson.phoneNumber);
            this.phoneType = 'Home Phone';
            break;
          }
          case 'CELL': {
            this.changeBeneficiaryForm.get('cellPhone').setValue(this.selectedPerson.phoneNumber);
            this.phoneType = 'Cell Phone';
            break;
          }
          case 'BU': {
            this.changeBeneficiaryForm.get('cellPhone').setValue(this.selectedPerson.phoneNumber);
            this.phoneType = 'Business Phone';
            break;
          }
        }
      });
    } else {
      this.reset();
    }
  }

  addBene(action: string) {
    const form = this.addNewBeneDetailsForm;
    if (!form.valid) {
      return this.compileAddNewBeneFormErrors(true);
    }
    const role = form.get('addBeneRole').value;

    if (role === 'Beneficiary') {
      const newControl = this.fb.group({
        primeBeneId: '',
        primeBenePersonType: 'Person',
        primeBeneAddressType: '00000000-0000-0000-0000-000000000001',
        primeBeneFirstName: form.get('addBeneFirstName').value,
        primeBeneMiddleInitial: form.get('addBeneMiddleInitial').value,
        primeBeneLastName: form.get('addBeneLastName').value,
        primeBenePercent: ['', [Validators.required, Validators.min(1), Validators.max(100)]],
        primeBeneRelationship: form.get('addBeneRelationship').value,
        primeBeneRole: form.get('addBeneRole').value,
        primeBeneEmail: form.get('addBeneEmail').value,
        primeBeneTaxId: form.get('addBeneTaxId').value,
        primeBeneGender: form.get('addBeneGender').value,
        primeBeneDOB: form.get('addBeneDOB').value,
        primeBeneAddress1: form.get('addBeneAddress1').value,
        primeBeneAddress2: form.get('addBeneAddress2').value,
        primeBeneAddress3: form.get('addBeneAddress3').value,
        primeBeneCity: form.get('addBeneCity').value,
        primeBeneState: form.get('addBeneState').value,
        primeBeneZip: form.get('addBeneZip').value,
        primeBeneCountry: form.get('addBeneCountry').value,
        primeBeneBusinessPhone: form.get('addBeneBusinessPhone').value,
        primeBeneCellPhone: form.get('addBeneCellPhone').value,
        primeBeneHomePhone: form.get('addBeneHomePhone').value
      });
      this.allPrimeBeneControls.push(newControl);
      // set the percentage
      const equalPercentage = Math.round(100 / this.allPrimeBeneControls.controls.length);
      this.allPrimeBeneControls.controls.forEach(control => {
        control.get('primeBenePercent').setValue(equalPercentage);
        control.get('primeBenePercent').markAsDirty();
      });
      this.syncTotalPrimeBenePercent();
    } else if (role === 'Contingent Beneficiary') {
      const newControl = this.fb.group({
        contingentBeneId: '',
        contingentBenePersonType: 'Person',
        contingentBeneAddressType: '00000000-0000-0000-0000-000000000001',
        contingentBeneFirstName: form.get('addBeneFirstName').value,
        contingentBeneMiddleInitial: form.get('addBeneMiddleInitial').value,
        contingentBeneLastName: form.get('addBeneLastName').value,
        contingentBenePercent: ['', [Validators.required, Validators.min(1), Validators.max(100)]],
        contingentBeneRelationship: form.get('addBeneRelationship').value,
        contingentBeneRole: form.get('addBeneRole').value,
        contingentBeneEmail: form.get('addBeneEmail').value,
        contingentBeneTaxId: form.get('addBeneTaxId').value,
        contingentBeneGender: form.get('addBeneGender').value,
        contingentBeneDOB: form.get('addBeneDOB').value,
        contingentBeneAddress1: form.get('addBeneAddress1').value,
        contingentBeneAddress2: form.get('addBeneAddress2').value,
        contingentBeneAddress3: form.get('addBeneAddress3').value,
        contingentBeneCity: form.get('addBeneCity').value,
        contingentBeneState: form.get('addBeneState').value,
        contingentBeneZip: form.get('addBeneZip').value,
        contingentBeneCountry: form.get('addBeneCountry').value,
        contingentBeneBusinessPhone: form.get('addBeneBusinessPhone').value,
        contingentBeneCellPhone: form.get('addBeneCellPhone').value,
        contingentBeneHomePhone: form.get('addBeneHomePhone').value
      });
      this.allContingentBeneControls.push(newControl);
      // set the percentage
      const equalPercentage = Math.round(100 / this.allContingentBeneControls.controls.length);
      this.allContingentBeneControls.controls.forEach(control => {
        control.get('contingentBenePercent').setValue(equalPercentage);
        control.get('contingentBenePercent').markAsDirty();
      });
      this.syncTotalContingentBenePercent();
    }
    if (action === 'saveAndClose') {
      this.addNewBeneDetailsForm.reset();
      this.addNewBeneDetailsForm.get('addBeneCountry').setValue('USA');
      this.addNewBeneDetailsForm.disable();
      this.showAddBene = false;
    } else if (action === 'saveAndAddNew') {
      this.addNewBeneDetailsForm.reset();
      this.addNewBeneDetailsForm.get('addBeneCountry').setValue('USA');
    }
  }

  showAddBeneForm() {
    this.addNewBeneDetailsForm.enable();
    this.addNewBeneDetailsForm.get('addBeneCountry').setValue('USA');
    this.showAddBene = true;
  }
  hideAddBeneForm() {
    this.addNewBeneDetailsForm.reset();
    this.addNewBeneDetailsForm.get('addBeneCountry').setValue('USA');
    this.addNewBeneDetailsForm.disable();
    this.showAddBene = false;
  }
  deletePrimeBene(primeBeneIdx, action) {
    if (action === 'Cancel') {
      return;
    }
    this.allPrimeBeneControls.removeAt(primeBeneIdx);
    const equalPercentage = Math.round(100 / this.allPrimeBeneControls.controls.length);
    this.allPrimeBeneControls.controls.forEach(control => {
      control.get('primeBenePercent').setValue(equalPercentage);
    });
    this.allPrimeBeneControls.markAsDirty();
    this.syncTotalPrimeBenePercent();
  }
  deleteContingentBene(contingentBeneIdx, action) {
    if (action === 'Cancel') {
      return;
    }
    this.allContingentBeneControls.removeAt(contingentBeneIdx);
    const equalPercentage = Math.round(100 / this.allContingentBeneControls.controls.length);
    this.allContingentBeneControls.controls.forEach(control => {
      control.get('contingentBenePercent').setValue(equalPercentage);
    });
    this.allContingentBeneControls.markAsDirty();
    this.syncTotalContingentBenePercent();
  }

  compileErrors(ignoreDirty?: boolean) {
    const form = this.changeBeneficiaryForm;
    for (const field of Object.keys(this.editBeneInfoErrors)) {
      const control = form.get(field);
      if (field === 'dateOfBirth') {
        if (control.value) {
          const value = new Date(control.value);
          const present = new Date(this.currentDate);
          if (value > present) {
            control.setErrors({
              'pattern': false
            });
          }
        }
      }
      this.editBeneInfoErrors[field] = '';
      if (control && control.invalid && (control.dirty || ignoreDirty)) {
        control.markAsDirty();
        const messages = this.localized.messages[field];
        for (const key of Object.keys(control.errors)) {
          this.editBeneInfoErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  checkPristine() {
    const form = this.addBeneficiaryForm;
    const originalPrimeBene = this.primaryBeneficiary && this.primaryBeneficiary.length;
    const allNewPrimeBene = this.allPrimeBeneControls.controls.length;
    const allNewPrimeBeneWithId = this.allPrimeBeneControls.controls.filter(a => a.get('primeBeneId').value).length;
    const originalContingentBene = this.contingentBeneficiary && this.contingentBeneficiary.length;
    const allNewContingentBene = this.allContingentBeneControls.controls.length;
    const allNewContingentBeneWithId = this.allContingentBeneControls.controls.filter(a => a.get('contingentBeneId').value).length;
    let c = true;
    if (form.controls.allPrimeBeneControls.pristine && form.controls.allContingentBeneControls.pristine) {
      this.addBeneficiaryForm.markAsPristine();
      return;
    }
    if (originalPrimeBene === allNewPrimeBene
      && originalPrimeBene === allNewPrimeBeneWithId
      && originalContingentBene === allNewContingentBene
      && originalContingentBene === allNewContingentBeneWithId) {
      this.allPrimeBeneControls.controls.forEach(control => {
        const p = this.primaryBeneficiary.find(a => a.id === control.get('primeBeneId').value);
        if (p.splitPercent === control.get('primeBenePercent').value && c) {
          c = true;
        } else {
          c = false;
        }
      });
      this.allContingentBeneControls.controls.forEach(control => {
        const p = this.contingentBeneficiary.find(a => a.id === control.get('contingentBeneId').value);
        if (p.splitPercent === control.get('contingentBenePercent').value && c) {
          c = true;
        } else {
          c = false;
        }
      });
      if (c) {
        this.addBeneficiaryForm.markAsPristine();
      }
    }
  }
  compileEditPercentError(ignoreDirty?: boolean) {

    const form = this.addBeneficiaryForm;
    for (const field of Object.keys(this.editBenePercentError)) {
      const control = form.get(field);
      this.editBenePercentError[field] = '';
      if (control && control.invalid && (control.dirty || ignoreDirty)) {
        const messages = this.localized.messages[field];
        for (const key of Object.keys(control.errors)) {
          this.editBenePercentError[field] += messages[key] + ' ';
        }
      }
    }
  }

  compileAddNewBeneFormErrors(ignoreDirty?: boolean) {
    const form = this.addNewBeneDetailsForm;

    for (const field of Object.keys(this.addBeneErrors)) {
      const control = form.get(field);
      if (field === 'addBeneDOB' && control.value) {
        const value = new Date(control.value);
        const present = new Date(this.currentDate);
        if (value > present) {
          control.setErrors({
            'pattern': false
          });
        }
      }
      this.addBeneErrors[field] = '';
      if (control && control.invalid && (control.dirty || ignoreDirty)) {
        control.markAsDirty();
        const messages = this.localized.messages[field];
        for (const key of Object.keys(control.errors)) {
          this.addBeneErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  syncTotalPrimeBenePercent() {
    this.totalPrimeBenePercent = 0;
    this.allPrimeBeneControls.controls.forEach(control => {
      this.totalPrimeBenePercent += control.get('primeBenePercent').value;
    });
    this.addBeneficiaryForm.get('totalPrimeBenePercent').setValue(this.totalPrimeBenePercent);
    this.addBeneficiaryForm.get('totalPrimeBenePercent').markAsDirty();
  }
  syncTotalContingentBenePercent() {
    // if (this.contingentBeneficiary || this.allContingentBeneControls.length > 0) {
    if (this.allContingentBeneControls.length > 0) {
      this.totalContingentBenePercent = 0;
      this.allContingentBeneControls.controls.forEach(control => {
        this.totalContingentBenePercent += control.get('contingentBenePercent').value;
      });
      this.addBeneficiaryForm.get('totalContingentBenePercent').setValue(this.totalContingentBenePercent);
      this.addBeneficiaryForm.get('totalContingentBenePercent').markAsDirty();
    } else {
      this.addBeneficiaryForm.get('totalContingentBenePercent').setValue('100');
    }
  }
  submitEditBeneInfo() {
    const form = this.changeBeneficiaryForm;
    if (!form.valid) {
      return this.compileErrors(true);
    }
    this.firstSubmitClick = true;
    let transaction = new OnlineTransaction();
    transaction = form.value;
    transaction.contractId = this.contractId;
    transaction.transactionType = OnlineTransactionType.BeneficiaryChange;
    transaction.userName = this.userService.user.profile.name;
    transaction.method = 'PUT';
    this.service.save(transaction).subscribe(res => {
      this.response = res;
      if (res.success && !res.hasErrors) {
        this.confirmNumber = res.confirmNumber;
        this.submitDateTimestamp = res.submitDateTime.toString();
        this.effectiveDate = res.effectiveDate.toString();
        if (res.hasWarnings && res.warnings.length > 0) {
          this.warnings = res.warnings;
        }
        this.submitted = true;
      } else {
        this.submitted = false;
        this.submittedResponse = 'The transaction encountered the following problem(s): [' + res.errors + ']';
      }
      this.firstSubmitClick = false;
    });
  }
  submitAddBene() {
    const form = this.addBeneficiaryForm;
    if (!form.valid) {
      return this.compileEditPercentError(true);
    }
    this.firstSubmitClick = true;
    const transaction = new OnlineTransaction();
    transaction.contractId = this.contractId;
    transaction.transactionType = OnlineTransactionType.BeneficiaryChange;
    transaction.userName = this.userService.user.profile.name;
    transaction.method = 'POST';
    this.collectAllBeneficiaries();
    transaction.beneficiary = this.newPeople;
    this.service.save(transaction).subscribe(res => {
      this.response = res;
      if (res.success && !res.hasErrors) {
        this.confirmNumber = res.confirmNumber;
        this.submitDateTimestamp = res.submitDateTime.toString();
        this.effectiveDate = res.effectiveDate.toString();
        this.addBeneficiaryForm.disable();
        if (res.hasWarnings && res.warnings.length > 0) {
          this.warnings = res.warnings;
        }
        this.submitted = true;
      } else {
        this.submitted = false;
        this.submittedResponse = 'The transaction encountered the following problem(s): [' + res.errors + ']';
      }
      this.firstSubmitClick = false;
    });
  }

  collectAllBeneficiaries() {
    this.newPeople = [];
    this.allPrimeBeneControls.controls.forEach(control => {
      const person = new Beneficiary();
      person.personType = control.get('primeBenePersonType').value;
      person.firstName = control.get('primeBeneFirstName').value;
      person.middleInitial = control.get('primeBeneMiddleInitial').value;
      person.lastName = control.get('primeBeneLastName').value;
      person.splitPercent = control.get('primeBenePercent').value;
      person.gender = control.get('primeBeneGender').value;
      person.role = control.get('primeBeneRole').value;
      person.email = control.get('primeBeneEmail').value;
      person.taxId = control.get('primeBeneTaxId').value;
      person.dateOfBirth = control.get('primeBeneDOB').value;
      person.relationshipToOwner = control.get('primeBeneRelationship').value;
      person.addressType = control.get('primeBeneAddressType').value;
      person.address1 = control.get('primeBeneAddress1').value;
      person.address2 = control.get('primeBeneAddress2').value;
      person.address3 = control.get('primeBeneAddress3').value;
      person.city = control.get('primeBeneCity').value;
      person.state = control.get('primeBeneState').value;
      person.zip = control.get('primeBeneZip').value;
      person.country = control.get('primeBeneCountry').value;
      person.businessPhone = control.get('primeBeneBusinessPhone').value;
      person.cellPhone = control.get('primeBeneCellPhone').value;
      person.homePhone = control.get('primeBeneHomePhone').value;
      this.newPeople.push(person);
    });
    if (this.allContingentBeneControls.length > 0) {
      this.allContingentBeneControls.controls.forEach(control => {
        const person = new Beneficiary();
        person.personType = control.get('contingentBenePersonType').value;
        person.firstName = control.get('contingentBeneFirstName').value;
        person.middleInitial = control.get('contingentBeneMiddleInitial').value;
        person.lastName = control.get('contingentBeneLastName').value;
        person.splitPercent = control.get('contingentBenePercent').value;
        person.gender = control.get('contingentBeneGender').value;
        person.role = control.get('contingentBeneRole').value;
        person.email = control.get('contingentBeneEmail').value;
        person.taxId = control.get('contingentBeneTaxId').value;
        person.dateOfBirth = control.get('contingentBeneDOB').value;
        person.relationshipToOwner = control.get('contingentBeneRelationship').value;
        person.addressType = control.get('contingentBeneAddressType').value;
        person.address1 = control.get('contingentBeneAddress1').value;
        person.address2 = control.get('contingentBeneAddress2').value;
        person.address3 = control.get('contingentBeneAddress3').value;
        person.city = control.get('contingentBeneCity').value;
        person.state = control.get('contingentBeneState').value;
        person.zip = control.get('contingentBeneZip').value;
        person.country = control.get('contingentBeneCountry').value;
        person.businessPhone = control.get('contingentBeneBusinessPhone').value;
        person.cellPhone = control.get('contingentBeneCellPhone').value;
        person.homePhone = control.get('contingentBeneHomePhone').value;
        this.newPeople.push(person);
      });
    }
  }
  reset() {
    this.changeBeneficiaryForm.reset();
    this.selectedPerson = null;
    this.response = null;
    // Is there a better way to do the below ?
    (document.getElementById('selectBene') as HTMLSelectElement).value = '';
  }
  addBeneficiaryFormReset() {
    this.addBeneficiaryForm.reset();
    this.response = null;
    this.showAddBene = false;
    this.updateForm();
    this.addNewBeneDetailsForm.disable();
  }
}
