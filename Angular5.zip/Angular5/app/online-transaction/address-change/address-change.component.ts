import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { debounceTime, map, share, takeUntil } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { Contract } from '../../shared/models/contract.model';
import { countries } from '../../shared/models/countries';
import { OnlineTransaction, OnlineTransactionResponse, OnlineTransactionType } from '../../shared/models/online-transaction.model';
import { Person } from '../../shared/models/person.model';
import { states } from '../../shared/models/states';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-address-change',
  templateUrl: './address-change.component.html',
  styleUrls: []
})
@AutoUnsubscribe()
@Configure('AddressChangeComponent')
export class AddressChangeComponent implements Configurable, OnInit {
  config: any;
  confirmNumber: string;
  contract: Observable<Contract>;
  contractId: string;
  countries: Array<any>;
  effectiveDate: string;
  submittedResponse: string;
  errors = {
    addressId: null,
    address1: null,
    changed: null,
    city: null,
    country: null,
    state: null,
    zipCode: null
  };
  firstSubmitClick = false;
  localized: any;
  people: Observable<Person[]>;
  response: OnlineTransactionResponse;
  selected: Person;
  states: Array<any>;
  submitDateTimestamp: string;
  submitted = false;
  transactionForm: FormGroup;
  usable: boolean;
  warnings: string[];

  private ngUnsubscribe: Subject<void> = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private service: OnlineTransactionService,
    private userService: UserService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    this.contractId = routeParams.id;

    this.contract = this.service.contract(this.contractId).pipe(share());
    this.people = this.service.people(this.contractId).pipe(
      map(ppl => {
        // below is a hack until mulesoft returns FAST people with country attribute
        if (this.config.tenantCode.toLowerCase() === 'jhli') {
          ppl.forEach(p => p.country = 'USA');
        }
        return ppl;
      }),
      share()
    );
    this.states = states;
    this.countries = countries;
    this.localized = this.config.translated;
    // this.buildForm();
  }

  buildForm() {
    this.transactionForm = this.fb.group({
      addressId: [this.selected.addressId, Validators.required],
      address1: [this.selected.address1, [Validators.required, Validators.pattern(/^[a-z\d\-.\s]+$/i)]],
      address2: [this.selected.address2],
      address3: [this.selected.address3],
      addressType: [this.selected.addressType],
      city: [this.selected.city, [Validators.required, Validators.pattern(/^[a-z\d\-_.\s]+$/i)]],
      contractId: [this.contractId],
      country: [this.selected.country, Validators.required],
      fullName: [this.selected.fullName],
      personId: [this.selected.id],
      role: [this.selected.role, Validators.required],
      state: [this.selected.state, Validators.required],
      transactionType: [OnlineTransactionType.AddressChange],
      zipCode: [this.selected.zipCode, [Validators.required, Validators.pattern(/^\d{5}(-\d{4})?$/)]],
    });

    this.transactionForm.valueChanges.pipe(
      debounceTime(500),
      takeUntil(this.ngUnsubscribe)
    ).subscribe(() => this.compileErrors());

    this.transactionForm.controls.address1.valueChanges
      .subscribe(v => {
        if (v === this.selected.address1) {
          this.transactionForm.controls.address1.markAsPristine();
        }
      });
    this.transactionForm.controls.address2.valueChanges
      .subscribe(v => {
        if (v === this.selected.address2) {
          this.transactionForm.controls.address2.markAsPristine();
        }
      });
    this.transactionForm.controls.address3.valueChanges
      .subscribe(v => {
        if (v === this.selected.address3) {
          this.transactionForm.controls.address3.markAsPristine();
        }
      });
    this.transactionForm.controls.city.valueChanges
      .subscribe(v => {
        if (v === this.selected.city) {
          this.transactionForm.controls.city.markAsPristine();
        }
      });
    this.transactionForm.controls.state.valueChanges
      .subscribe(v => {
        if (v === this.selected.state) {
          this.transactionForm.controls.state.markAsPristine();
        }
      });
    this.transactionForm.controls.zipCode.valueChanges
      .subscribe(v => {
        if (v === this.selected.zipCode) {
          this.transactionForm.controls.zipCode.markAsPristine();
        }
      });
    this.transactionForm.controls.country.valueChanges
      .subscribe(v => {
        if (v === this.selected.country) {
          this.transactionForm.controls.country.markAsPristine();
        }
      });
  }

  compileErrors(ignoreDirty?: boolean) {
    const form = this.transactionForm;
    for (const field of Object.keys(this.errors)) {
      const control = form.get(field);
      this.errors[field] = '';
      if (control && control.invalid && (control.dirty || ignoreDirty)) {
        for (const key of Object.keys(control.errors)) {
          this.errors[field] += this.localized.messages[field][key];
        }
      }
    }
  }

  startEdit(person: Person) {
    this.selected = person;
    console.info('building form based on', this.selected);
    this.buildForm();
  }

  reset() {
    this.transactionForm.reset();
    this.selected = null;
    this.response = null;
  }

  submit() {
    const form = this.transactionForm;
    if (!form.valid) {
      console.info('form not valid', form);
      return this.compileErrors(true);
    }

    this.firstSubmitClick = true;

    let transaction = new OnlineTransaction();
    transaction = form.value;
    transaction.contractId = this.contractId;
    transaction.transactionType = OnlineTransactionType.AddressChange;
    transaction.userName = this.userService.user.profile.name;
    this.service.save(transaction).subscribe(res => {
      this.response = res;
      if (res.success && !res.hasErrors) {
        this.confirmNumber = res.confirmNumber;
        this.submitDateTimestamp = res.submitDateTime.toString();
        this.effectiveDate = res.effectiveDate.toString();
        if (res.hasWarnings && res.warnings.length > 0) {
          this.warnings = res.warnings;
        }
        this.submitted = true;
      } else {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'The transaction encountered the following problem(s): [' + res.errors + ']';
      }
    });
  }
}
