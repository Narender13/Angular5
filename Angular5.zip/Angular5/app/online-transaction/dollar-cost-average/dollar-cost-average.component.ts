import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dollar-cost-average',
  templateUrl: './dollar-cost-average.component.html',
  styleUrls: ['./dollar-cost-average.component.scss']
})
export class DollarCostAverageComponent implements OnInit {
  className = 'DollarCostAverageComponent';
  constructor() { }

  ngOnInit() {
  }

}
