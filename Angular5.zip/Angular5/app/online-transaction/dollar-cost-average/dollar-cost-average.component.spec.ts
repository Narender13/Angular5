import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DollarCostAverageComponent } from './dollar-cost-average.component';

describe('DollarCostAverageComponent', () => {
  let component: DollarCostAverageComponent;
  let fixture: ComponentFixture<DollarCostAverageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DollarCostAverageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DollarCostAverageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
