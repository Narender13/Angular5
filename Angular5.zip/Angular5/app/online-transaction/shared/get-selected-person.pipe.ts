import { Pipe, PipeTransform } from '@angular/core';
import { RolePercent } from 'app/shared/models/person.model';

@Pipe({
  name: 'getSelectedPerson'
})

export class GetSelectedPersonPipe implements PipeTransform {

  transform(items: RolePercent[]): any {
    const requiredRoles = ['Primary Owner', 'Owner', 'Primary Annuitant', 'Primary Annuitant / Insured', 'PRIM OWNER'];
    return items.filter(function (item) {
      return (requiredRoles.indexOf(item.name) > -1);
    });
  };
}
