/**
 * All except static integer were taken from latest in angular repo
 * https://github.com/angular/angular/blob/master/packages/forms/src/validators.ts
 */

// tslint:disable:only-arrow-functions
import { AbstractControl, ValidationErrors, ValidatorFn, FormGroup } from '@angular/forms';

function isEmptyInputValue(value: any): boolean {
  // we don't check for string here so it also works with arrays
  return value == null || value.length === 0;
}

export class TransactionValidators {
  static integer(control: AbstractControl): ValidationErrors | null {
    if (isEmptyInputValue(control.value)) {
      return null;
    }
    const value = parseFloat(control.value);
    return !isNaN(value) && !Number.isInteger(value) ? { 'integer': true } : null;
  }
  static compareDates(date1, date2, duration): ValidationErrors | null {
    return (group: FormGroup) => {
      const sourceInput = group.get(date1).value;
      const targetInput = group.get(date2).value;
      const selectedDuration = group.get(duration).value;
      if (selectedDuration === 'fixedPeriod') {
        if (sourceInput >= targetInput) {
          return group.controls[date2].setErrors({ 'compareDates': true });
        }
      }
      // REMOVE the error if present from previous iteration
      if (targetInput && group.controls[date2].errors) {
        delete group.controls[date2].errors.compareDates;
      }
      return null;
    };
  }
  static equal(value: number): ValidationErrors | null {
    return (control: AbstractControl): { [key: string]: any } => {
      if (isEmptyInputValue(control.value)) {
        return null;
      }
      const num = control.value;
      return isNaN(num) || (num !== value) ? { 'equal': true } : null;
    };
  }
  static equalTo(fieldKey: AbstractControl): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      const compare = fieldKey != null ? fieldKey.value : null;
      if (compare !== control.value) {
        return { 'equalTo': true };
      }
      return null;
    };
  }
  static fundAmount(control: AbstractControl): ValidationErrors | null {
    // tslint:disable-next-line:no-string-literal
    // tslint:disable-next-line:max-line-length
    const compare: string = control.parent != null && control.parent.get('selectedFundFromAmount') != null && control.parent.get('selectedFundFromAmount').value != null ? control.parent.get('selectedFundFromAmount').value : null;
    if (compare && (control.value > compare)) {
      return { 'fundAmount': true };
    }
    return null;
  }
  static date(control: AbstractControl): ValidationErrors | null {
    if (isEmptyInputValue(control.value)) {
      return null;
    }
    // tslint:disable-next-line:max-line-length
    const pattern = ('^[0-9]{4}-(((0[13578]|(10|12))-(0[1-9]|[1-2][0-9]|3[0-1]))|(02-(0[1-9]|[1-2][0-9]))|((0[469]|11)-(0[1-9]|[1-2][0-9]|30)))$');
    return !control.value.match(pattern) ? { 'date': true } : null;
  }
  static zipCodePattern(control: AbstractControl): ValidationErrors | null {
    if (isEmptyInputValue(control.value)) {
      return null;
    }
    const pattern = ('^([0-9]{5}|[0-9]{5}-[0-9]{4})$');
    return !control.value.match(pattern) ? { 'zipCodePattern': true } : null;
  }
  static betweenDays(control: AbstractControl): ValidationErrors | null {
    if (isEmptyInputValue(control.value)) {
      return null;
    }
    const targetInput = control.value;
    const d: Date = new Date(targetInput);
    const month = 1 + d.getMonth();
    const year = d.getFullYear();
    const cdate1: Date = new Date(month + '/01/' + year);
    const cdate2: Date = new Date(month + '/28/' + year);
    const compare1 = cdate1.valueOf();
    const compare2 = cdate2.valueOf();
    const compare = d.valueOf();
    if (!((compare1 <= compare) && (compare <= compare2))) {
      return { 'betweenDays': true };
    }
    return null;
  }
}
