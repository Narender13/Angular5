import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { OnlineTransactionType } from '../../../shared/models/online-transaction.model';
import { onlineTransactionRoutes } from 'app/online-transaction/shared/auth-transaction/auth-transaction-routes';
import { Configure, Configurable } from '../../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../../shared/decorators/autounsubscribe';

const transactionRoutes = onlineTransactionRoutes;

@Component({
  selector: 'app-auth-transaction',
  templateUrl: './auth-transaction.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('OnlineTransactionSelectionComponent')
export class OnlineTransactionSelectionComponent implements Configurable, OnInit {
  availableTransactions: Observable<any[]>;
  config: any;
  contractId: string;
  usable: any;

  constructor(
    private service: OnlineTransactionService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { contractId: string };
    this.contractId = routeParams.contractId;
    this.availableTransactions = this.service.types(this.contractId).map(arr => {
      return arr.map(t => {
        return {
          name: this.getName(t),
          link: this.getRoute(t)
        };
      });
    }).pipe(share());
  }

  getName(transactionType: OnlineTransactionType) {
    return OnlineTransactionType[transactionType];
  }

  getRoute(transactionType: OnlineTransactionType) {
    const route = transactionRoutes.find(r => r.data.transactionType === transactionType);

    let path: string;
    if (route) {
      path = `/${route.path.replace(':id', this.contractId)}`;
    }
    return path;
  }
}
