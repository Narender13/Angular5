import { Routes } from '@angular/router';

import { AuthGuardService } from 'app/shared/services/auth-guard.service';
import { AddressChangeComponent } from '../../address-change/address-change.component';
import { DollarCostAverageComponent } from '../../dollar-cost-average/dollar-cost-average.component';
import { FormUploadComponent } from '../../form-upload/form-upload.component';
import { FundTransferComponent } from '../../fund-transfer/fund-transfer.component';
import { FutureAllocationComponent } from '../../future-allocation/future-allocation.component';
import { OnlineTransactionType } from 'app/shared/models/online-transaction.model';
import { ReallocationComponent } from '../../reallocation/reallocation.component';
import { SystematicReallocationComponent } from '../../systematic-reallocation/systematic-reallocation.component';
import { TransGuardService } from './trans-service';
import { BeneficiaryChangeComponent } from '../../beneficiary-change/beneficiary-change.component';

export const onlineTransactionRoutes: Routes = [

  {
    path: 'contracts/:id/address-change',
    component: AddressChangeComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.AddressChange }
  },
  {
    path: 'contracts/:id/beneficiary-change',
    component: BeneficiaryChangeComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.BeneficiaryChange }
  },
  {
    path: 'contracts/:id/dollar-cost-average',
    component: DollarCostAverageComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.DollarCostAverage }
  },
  {
    path: 'contracts/:id/fund-transfer',
    component: FundTransferComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.FundTransfer }
  },
  {
    path: 'contracts/:id/future-allocation',
    component: FutureAllocationComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.FutureAllocation }
  },
  {
    path: 'contracts/:id/reallocation',
    component: ReallocationComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.Reallocation }
  },
  {
    path: 'contracts/:id/systematic-reallocation',
    component: SystematicReallocationComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.SystematicReallocation }
  },
  {
    path: 'contracts/:id/form-upload',
    component: FormUploadComponent,
    canActivate: [AuthGuardService, TransGuardService],
    data: { transactionType: OnlineTransactionType.FormUpload }
  },
  {
    path: 'form-upload',
    component: FormUploadComponent,
    canActivate: [AuthGuardService],
    data: { transactionType: OnlineTransactionType.FormUpload }
  }
];
