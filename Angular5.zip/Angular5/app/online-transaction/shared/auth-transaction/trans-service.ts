import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { UserService } from 'app/shared/services/user.service';
@Injectable()
export class TransGuardService implements CanActivate {
  constructor(
    private service: OnlineTransactionService,
    private userService: UserService,
    private router: Router
  ) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    const contractId = route.paramMap.get('contractId') || route.paramMap.get('id');
    if (!contractId) {
      return Observable.of(true);
    }
    const routeData = route.routeConfig.data;
    if (!(routeData || 'transactionType' in routeData)) {
      return Observable.of(true);
    }
    // temporary so that I can land on address - change page through url directly
    // return this.service.types(contractId)
    //   .first(types => {
    //     const available = types.includes(routeData.transactionType);
    //     if (!available) {
    //       this.router.navigate(['/not-authorized']);
    //     }
    //     return available;
    //   })
    //   .map(t => !!t);
    return Observable.of(true);
  }
}