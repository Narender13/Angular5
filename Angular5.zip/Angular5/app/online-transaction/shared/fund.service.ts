import { Injectable } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';

import { Fund } from '../../shared/models/fund.model';
import { LoggingService } from '../../shared/logging/logging.service';

@Injectable()
export class FundService {
  private apiUrl = 'api/funds/';

  constructor(private http: Http, private loggingService: LoggingService) { }

  list(contractId: string): Observable<Fund[]> {
    const params = new URLSearchParams();

    if (contractId) {
      params.set('contractId', contractId);
    }

    return this.http.get(this.apiUrl, { search: params }).pipe(
      map(res => res.json().data as Fund[]),
      catchError(this.loggingService.handleError));
  }
}
