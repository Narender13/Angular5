import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
import { ContractService } from 'app/contract/shared/contract.service';
import { PeopleService } from 'app/people/shared/people.service';
import { Address, Person } from 'app/shared/models/person.model';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';

import { ContractFundService } from './contract-fund.service';
import { LoggingService } from '../../shared/logging/logging.service';
import { OnlineTransaction, OnlineTransactionResponse, OnlineTransactionType } from '../../shared/models/online-transaction.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class OnlineTransactionService {
  private apiUrl = 'onlinetransactions/';

  // NOTE ContractFundService aggregates all information necessary for building the UI
  constructor(
    private contractService: ContractService,
    private contractFundService: ContractFundService,
    private peopleService: PeopleService,
    private http: UWHttp,
    private loggingService: LoggingService
  ) { }

  contract(id: string) {
    return this.contractService.find(id);
  }

  funds(search: string) {
    return this.contractFundService.list(search, 0, 0, '');
  }

  // temporary so that I can land on address-change page through url directly
  types(search: string): Observable<OnlineTransactionType[]> {
    return this.http.authGet(this.apiUrl + search + '/types').pipe(map(res => this.extracttypes(res)),
      catchError(this.loggingService.handleError));
  }

  save(transaction: OnlineTransaction): Observable<OnlineTransactionResponse> {
    return this.http.authPost(this.apiUrl, transaction).pipe(map(res => this.extractsave(res)),
      catchError(this.loggingService.handleError));
  }

  people(id: string) {
    return this.peopleService.list(id, 0).pipe(
      map(res => this.filterPerson(res)));
  }

  // Online transactions service "owns" states data? doubt it...
  states() {
    return this.http.get('states/').pipe(map(res => res.json().data));
  }

  countries() {
    return this.http.get('countries/').pipe(map(res => res.json().data));
  }
  roles() {
    return this.http.get('roles/').pipe(map(res => res.json().data));
  }
  relationshipToOwners() {
    return this.http.get('relationshipToOwners/').pipe(map(res => res.json().data));
  }

  isEqual(a: Address, b: Address) {
    const normalize = (s) => (s || '').toUpperCase();
    // todo: ought be a way to get keys for interface, eg keyof or Object.keys()
    const keys = ['address1', 'address2', 'address3', 'city', 'state', 'zipCode', 'country'];
    const different = keys.some(k => normalize(a[k]) !== normalize(b[k]));
    return !different;
  }

  private extracttypes(res: Response): OnlineTransactionType[] {
    const data = res.json();
    const result: OnlineTransactionType[] = [];
    const theKeys = Object.keys(data);
    theKeys.forEach(element => {
      result.push(data[element]);
    });
    return result;
  }

  private extractsave(res: Response): OnlineTransactionResponse {
    return res.json() as OnlineTransactionResponse;
  }

  private filterPerson(ppl: Person[]) {
    const requiredRoles = ['Primary Owner', 'Owner', 'Primary Annuitant', 'Primary Annuitant / Insured', 'PRIM OWNER'];

    return ppl.filter(p => p.groupedRoles.some(r => requiredRoles.includes(r.name)));
  }

}
