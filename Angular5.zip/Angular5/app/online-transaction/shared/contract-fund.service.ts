import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { ContractFund } from '../../shared/models/contract-fund.model';
import { LoggingService } from '../../shared/logging/logging.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ContractFundService {
  private apiUrl = 'contractfunds/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, limit: number, offset: number, orderby: string): Observable<ContractFund[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('contractid', search);
    }

    return this.http.authGet(this.apiUrl + search).pipe(
      map(res => this.extract(res)),
      catchError(this.loggingService.handleError));
  }

  private extract(res: Response): ContractFund[] {
    const data = res.json() as ContractFund[];
    this.lastCount.next(data.length);
    return data;
  }

}
