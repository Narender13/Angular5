import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { debounceTime, filter } from 'rxjs/operators';

import { AuthGuardService } from '../../shared/services/auth-guard.service';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { FileUpload } from '../../shared/models/file-upload.model';
import { FormUploadService } from './shared/form-upload.service';
import { RegisterService } from '../../register/shared/register.service';
import { UserService } from '../../shared/services/user.service';

export class RecaptchaModel {
  catpcha?: string;
  satisfied: boolean;
  response?: string;
  constructor() {
    this.satisfied = false;
  }
}

@Component({
  selector: 'app-form-upload',
  templateUrl: './form-upload.component.html',
  styles: []
})
@Configure('FormUploadComponent')
export class FormUploadComponent implements Configurable, OnInit {
  contractId: string;
  siteKey: string;
  validateForm: FormGroup;
  ownerName: string;
  personNotFound = true;
  personFindAttempted = false;
  busy = false;
  started = false;
  finished = false;
  recaptcha = new RecaptchaModel();
  config: any;
  usable: any;
  user: any = null;
  result: string;
  validTypes: any;
  files = new Array<FileUpload>();

  constructor(
    private fb: FormBuilder,
    private formUploadService: FormUploadService,
    private registerService: RegisterService,
    private route: ActivatedRoute,
    private userService: UserService,
    private guardService: AuthGuardService
  ) { }

  ngOnInit() {
    this.user = this.userService.user;
    this.validTypes = this.config.validTypes;
    this.siteKey = this.config.recaptchaKey;
    this.initUploadForm();
    this.createLookupForm();
  }

  createLookupForm() {
    this.validateForm = this.fb.group({
      lastName: ['',
        [
          Validators.required,
          Validators.minLength(2)
        ]
      ],
      dob: ['', [Validators.required]],
      last4: ['',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(4),
          Validators.pattern(/^[0-9]+$/)
        ]
      ]
    });

    this.last4Field.valueChanges.pipe(
      filter(val => val.length === 4),
      debounceTime(300)
    ).subscribe(val => this.personFindAttempted = false);

    this.dobField.valueChanges.pipe(
      debounceTime(300)
    ).subscribe(val => this.personFindAttempted = false);

    this.lastNameField.valueChanges.pipe(
      debounceTime(300)
    ).subscribe(val => this.personFindAttempted = false);
  }

  get last4Field() {
    return this.validateForm.get('last4');
  }
  get dobField() {
    return this.validateForm.get('dob');
  }
  get lastNameField() {
    return this.validateForm.get('lastName');
  }

  get uploadReady() {
    return this.files.length > 0 &&
      this.files.every(f => f.onBaseType !== undefined);
  }

  get readyReason() {
    return this.files.length ? 'Every file must have a type selected' : '';
  }

  public recaptchaResolved(captchaResponse: string) {
    this.recaptcha.satisfied = true;
    this.recaptcha.response = captchaResponse;
  }

  personLookup(last4: string, dob: string, lastName: string) {
    this.busy = true;
    this.registerService.lookupBackendKey(lastName, last4, dob, this.recaptcha.response)
      .subscribe(person => {
        this.personNotFound = true;
        this.personFindAttempted = true;
        if (person && person.length === 1) {
          // Not supporting case when multiple contracts returned because fast policysearch doesn't return Dob
          const ppl = person[0];
          if (ppl) {
            this.personNotFound = false;
            this.contractId = ppl.id;
            this.ownerName = `${ppl.firstName} ${ppl.lastName}`;
          }
        }
        this.busy = false;
      });
  }

  fileChange(event) {
    const fileList: FileList = event.target.files;
    if (fileList.length === 0) { return; }
    for (let i = 0; i < fileList.length; i++) {
      const upload = new FileUpload();
      upload.file = fileList[i];
      upload.pending = false;
      this.files.push(upload);
    }
    event.target.value = null;
  }

  setType(event, index, type) {
    this.files[index].onBaseType = type.onBaseType;
    this.files[index].clientType = type.name;
    return false;
  }

  remove(event, index) {
    this.files.splice(index, 1);
  }

  uploadFiles() {
    this.busy = true;
    this.started = true;
    this.result = 'Uploading form(s), please wait';
    let workers = 0;
    for (let i = 0; i < this.files.length; i++) {
      const upload = this.files[i];
      upload.pending = true;
      workers++;
      this.formUploadService.upload(upload, this.contractId)
        .subscribe(uploadDone => {
          this.files.find(f => f.file.name === uploadDone.file.name).success = true;
          this.files.find(f => f.file.name === uploadDone.file.name).pending = false;
          // todo: use rxjs timer
          setTimeout(() => {
            const removeAt = this.files.findIndex(f => f.file.name === uploadDone.file.name);
            this.files.splice(removeAt, 1);
          }, 5000);
          workers--;
          if (!workers) {
            this.busy = false;
            this.result = 'Files uploaded successfully';
            this.finished = true;
            // todo: use rxjs timer; eg, timer(9000).subscribe(_ => this.initUploadForm());
            setTimeout(() => { this.initUploadForm(); }, 9000);
          }
        }, (errResp) => {
          workers--;
          if (!workers) {
            this.busy = false;
            this.started = false;
            this.finished = true;
          }
        });
    }
  }

  initUploadForm() {
    // authenticated init
    const routeParams = this.route.snapshot.params as { id: string };
    if (routeParams.id) {
      this.contractId = routeParams.id.split('~')[2];
    } else {
      this.contractId = null;
    }
    // unauthenticated init
    this.personNotFound = true;
    this.personFindAttempted = false;
    this.recaptcha = new RecaptchaModel();
    // upload controls
    this.files = new Array<FileUpload>();
    this.result = null;
    this.busy = this.started = this.finished = false;
  }

}
