import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { UserService } from 'app/shared/services/user.service';
import { ContractService } from '../../contract/shared/contract.service';
import { OnlineTransactionService } from '../shared/online-transaction.service';
import { OnlineTransactionType } from '../../shared/models/online-transaction.model';
import { Contract } from '../../shared/models/contract.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-form-upload-link',
  templateUrl: './form-upload-link.component.html',
  styles: []
})
@Configure('FormUploadLink')
export class FormUploadLinkComponent implements Configurable, OnInit {
  availableTransactions: OnlineTransactionType[];
  config: any;
  contracts: Contract[];
  // @ViewChild('contractSelect') contractSelect: ElementRef;
  uploadContracts = new Array<Contract>();
  user: any;
  selectedContract: any;
  error: any;

  constructor(
    private userService: UserService,
    private contractService: ContractService,
    private onlineTransactionService: OnlineTransactionService,
    private router: Router
  ) { }

  ngOnInit() {
    this.user = this.userService.user;
    if (this.user) {
      this.contractService.list(null, 25, 0, '').subscribe(contracts => {
        this.contracts = contracts;
        if (this.contracts.length > 0) {
          this.contracts.forEach(contract => {
            // this might perform poorly for users with many contracts
            this.onlineTransactionService.types(contract.id).subscribe(tx => {
              if (tx.some(t => t === OnlineTransactionType.FormUpload)) {
                this.uploadContracts.push(contract);
              }
            });
          });
        }
      });
    }
  }

  navigate() {
    if (this.selectedContract) {
      this.router.navigate([`contracts/${this.selectedContract}/form-upload`]);
    } else {
      this.error = 'Please select a contract';
    }
  }

  select(value: string) {
    this.error = '';
    this.selectedContract = value;
  }

}
