import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';

import { FileUpload } from '../../../shared/models/file-upload.model';
import { LoggingService } from '../../../shared/logging/logging.service';
import { UWHttp } from '../../../UWHttp';

@Injectable()
export class FormUploadService {

  private apiUrl = 'forms';

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService) {
  }

  upload(upload: FileUpload, contractId: string) {
    const formData: FormData = new FormData();
    formData.append('file', upload.file, upload.file.name);
    formData.append('fileType', upload.onBaseType);

    return this.http.authPost(`${this.apiUrl}?contract=${contractId}`, formData).pipe(
      map(res => { return upload; }),
      catchError(e => {
        return Observable.of(upload);
      }));
  }

}
