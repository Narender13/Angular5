import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FutureAllocationComponent } from './future-allocation.component';

describe('FutureAllocationComponent', () => {
  let component: FutureAllocationComponent;
  let fixture: ComponentFixture<FutureAllocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FutureAllocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FutureAllocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
