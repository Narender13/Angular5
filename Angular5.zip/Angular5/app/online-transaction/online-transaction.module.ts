import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AddressChangeComponent } from './address-change/address-change.component';
import { BeneficiaryChangeComponent } from './beneficiary-change/beneficiary-change.component';
import { ContractService } from 'app/contract/shared/contract.service';
import { ContractFundService } from 'app/online-transaction/shared/contract-fund.service';
import { DollarCostAverageComponent } from './dollar-cost-average/dollar-cost-average.component';
import { FormUploadComponent } from './form-upload/form-upload.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { FutureAllocationComponent } from './future-allocation/future-allocation.component';
import { GetSelectedPersonPipe } from './shared/get-selected-person.pipe';
import { OnlineTransactionRoutingModule } from './online-transaction-routing.module';
import { OnlineTransactionSelectionComponent } from './shared/auth-transaction/auth-transaction.component';
import { OnlineTransactionService } from './shared/online-transaction.service';
import { PeopleModule } from '../people/people.module';
import { ReallocationComponent } from './reallocation/reallocation.component';
import { SharedModule } from '../shared/shared.module';
import { SystematicReallocationComponent } from './systematic-reallocation/systematic-reallocation.component';
import { TransGuardService } from './shared/auth-transaction/trans-service';
import { RecaptchaModule } from 'ng-recaptcha';
import { FormUploadService } from './form-upload/shared/form-upload.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    OnlineTransactionRoutingModule,
    PeopleModule,
    SharedModule,
    ReactiveFormsModule,
    RecaptchaModule
  ],
  declarations: [
    AddressChangeComponent,
    DollarCostAverageComponent,
    FormUploadComponent,
    FundTransferComponent,
    FutureAllocationComponent,
    OnlineTransactionSelectionComponent,
    ReallocationComponent,
    SystematicReallocationComponent,
    GetSelectedPersonPipe,
    BeneficiaryChangeComponent
  ],
  exports: [OnlineTransactionSelectionComponent],
  providers: [
    ContractService,
    ContractFundService,
    DatePipe,
    FormUploadService,
    OnlineTransactionService,
    TransGuardService
  ]
})
export class OnlineTransactionModule { }
