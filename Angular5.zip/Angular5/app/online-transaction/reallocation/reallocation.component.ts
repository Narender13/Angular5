import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { TransactionValidators } from 'app/online-transaction/shared/transaction-validator';
import { Subject } from 'rxjs/Subject';
import { debounceTime, takeUntil } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { ContractFund } from '../../shared/models/contract-fund.model';
import { FundTransaction, OnlineTransaction, OnlineTransactionType } from '../../shared/models/online-transaction.model';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-reallocation',
  templateUrl: './reallocation.component.html',
  styleUrls: ['./reallocation.component.scss']
})
@AutoUnsubscribe()
@Configure('ReallocationComponent')
export class ReallocationComponent implements Configurable, OnInit {
  allocationForm: FormGroup;
  allocations: ContractFund[] = [];
  className = 'ReallocationComponent';
  config: any;
  confirmNumber: string;
  contractId: string;
  contractNumber: string;
  effectiveDate: string;
  errors = {
    amount: '',
    fund: '',
    total: ''
  };
  firstSubmitClick = false;
  fundValues: ContractFund[];
  loadingFunds = true;
  localized: any;
  originalFundValues: ContractFund[];
  ownerName: string;
  productId: string;
  selectedAllocation: ContractFund = null;
  submitDateTimestamp: string;
  submitted = false;
  submittedResponse = null;
  totalFundValue: number;
  transactionForm: FormGroup;
  usable: boolean;
  warnings: string[];

  private ngUnsubscribe: Subject<void> = new Subject<void>();

  get availableFunds(): ContractFund[] {
    const selected = this.selectedAllocation;
    let usedFunds = this.allocations.map(f => new ContractFund(f));
    if (selected) {
      usedFunds = usedFunds.filter(f => f.fundId !== selected.fundId);
    }
    return (this.originalFundValues || [])
      .filter(item => !usedFunds.some(f => f.fundName === item.fundName));
  }

  get total(): number {
    return this.allocations
      .map(alloc => alloc.percent)
      .reduce((memo, amount) => memo + amount, 0);
  }

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private service: OnlineTransactionService,
    private datePipe: DatePipe,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.localized = this.config.translated;

    this.route.params.subscribe((params: { id: string }) => {
      if (params.id !== undefined) {
        this.contractId = params.id;
        // Temporarily hijacking ContractId constraint when it is coming in as LC~539~7100000950
        const contractParts = this.contractId.split('~');
        if (contractParts.length === 3) {
          this.contractNumber = contractParts[2];
        }
        this.service.types(params.id).subscribe(res => {
          this.service.funds(params.id)
            .subscribe(fundValues => {
              this.loadingFunds = false;
              // get funds that have fund values
              this.fundValues = this.getFundsWithFundValues(fundValues);
              this.totalFundValue = this.getTotalFundValue(this.fundValues);
              // clone fund values to preserve original
              this.originalFundValues = fundValues.map(f => new ContractFund(f));
            });
          this.service.contract(this.contractId)
            .subscribe(c => { this.productId = c.productId; this.ownerName = c.personName; });
        });
      }
    });
    this.buildForm();
  }

  buildForm(): void {
    this.allocationForm = this.fb.group({
      fund: [null, Validators.required],
      amount: [null, [Validators.required, Validators.min(1), Validators.max(100)]]
    });

    this.transactionForm = this.fb.group({
      allocation: this.allocationForm,
      applyFutureAllocation: false,
      total: [0, TransactionValidators.equal(100)]
    });

    this.transactionForm.valueChanges.pipe(
      debounceTime(500),
      takeUntil(this.ngUnsubscribe)
    ).subscribe(() => {
        this.resetErrors();
        if (!this.transactionForm.valid) {
          this.compileErrors(this.transactionForm);
        }
      });
  }

  resetErrors() {
    for (const field of Object.keys(this.errors)) {
      this.errors[field] = '';
    }
  }

  compileErrors(form: FormGroup, ignoreDirty?: boolean) {
    for (const field of Object.keys(this.errors)) {
      const control = form.get(field);
      if (ignoreDirty !== null) {
        this.errors[field] = '';
      }
      if (form.contains(field) && (control && control.dirty || ignoreDirty)) {
        if (!control.valid) {
          for (const key of Object.keys(control.errors)) {
            this.errors[field] += this.localized.messages[field][key];
          }
        }
      }
    }
  }

  addAllocation(): void {

    const form = this.allocationForm;

    this.resetErrors();
    if (!form.valid) {
      return this.compileErrors(this.allocationForm, true);
    }

    const allocation = new ContractFund();
    const fund = this.originalFundValues.find(f => f.fundId === form.get('fund').value);
    allocation.fundId = fund.fundId;
    allocation.fundName = fund.fundName;
    allocation.percent = form.get('amount').value;
    this.allocations.push(allocation);
    this.syncTotal();
    form.reset();
  }

  updateAllocation(): void {
    const form = this.allocationForm;

    this.resetErrors();
    if (!form.valid) {
      return this.compileErrors(this.allocationForm, true);
    }

    const allocation = this.selectedAllocation;
    const fund = this.originalFundValues.find(f => f.fundId === form.get('fund').value);
    allocation.fundId = fund.fundId;
    allocation.fundName = fund.fundName;
    allocation.percent = form.get('amount').value;
    this.syncTotal();
    this.cancelEdit();
  }

  removeAllocation(): void {
    const allocation = this.selectedAllocation;
    const index = this.allocations.indexOf(allocation);

    if (index !== -1) {
      this.allocations.splice(index, 1);
    }

    this.syncTotal();
    this.cancelEdit();
  }

  startEdit(allocation: ContractFund): void {
    this.submittedResponse = null;
    if (this.selectedAllocation === allocation) {
      return this.cancelEdit();
    }

    this.selectedAllocation = allocation;
    this.transactionForm.patchValue({
      allocation: allocation
    });
    this.allocationForm.setValue({
      fund: allocation.fundId,
      amount: allocation.percent
    });
  }

  cancelEdit(): void {
    this.selectedAllocation = null;
    this.allocationForm.reset();
  }

  syncTotal(): void {
    this.transactionForm.patchValue({ total: this.total });
  }

  resetTransaction(): void {
    this.cancelEdit();
    this.transactionForm.reset({ onlySelf: true });
    this.allocations.length = 0;
    this.submitted = false;
    this.submittedResponse = null;
  }

  submitTransaction(): void {
    this.submitted = false;
    this.submittedResponse = null;
    const form = this.transactionForm;
    const total = form.get('total').value;
    this.resetErrors();
    if ((!form.valid) && (total !== 100)) {
      return this.compileErrors(this.transactionForm, true);
    }

    this.firstSubmitClick = true;

    const transaction = new OnlineTransaction();
    transaction.contractId = this.contractId;
    transaction.userName = this.userService.user.profile.name;
    transaction.transactionType = OnlineTransactionType.Reallocation;
    transaction.applyFutureAllocation = form.get('applyFutureAllocation').value;
    transaction.productId = this.productId;
    transaction.ownerName = this.ownerName;

    // assumption is the asset source is the same for all funds for contract
    const fund = this.originalFundValues.find(f => f.fundId === this.allocations[0].fundId);
    transaction.assetSource = fund.assetSource;

    const ft = new Array<FundTransaction>();
    this.allocations.forEach(a => {
      const f = new FundTransaction();
      f.fundId = a.fundId;
      f.amountType = 'P';             // D/P : Dollar or Percent
      f.direction = 'T';           // T/F : To or From
      f.amount = a.percent;
      f.fundName = a.fundName;
      ft.push(f);
    });
    transaction.funds = ft;

    // Block transaction if a soft-closed fund is used
    const softCloseFunds = this.originalFundValues.filter(f => f.softClose === 1);

    if (softCloseFunds.some(f => {
      const transactionFund = transaction.funds.find(tf => tf.fundId === f.fundId);
      if (transactionFund != null) {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'Cannot use soft-closed fund:  ' + f.fundName;
        return true;
      }
    })) {
      return;
    }

    this.service.save(transaction).subscribe(res => {
      if (res.success && !res.hasErrors) {
        this.submittedResponse = 'The transaction has been submitted.';
        this.confirmNumber = res.confirmNumber;
        this.submitDateTimestamp = res.submitDateTime.toString();
        this.effectiveDate = res.effectiveDate.toString();
        if (res.hasWarnings && res.warnings.length > 0) {
          this.warnings = res.warnings;
        }
        this.submitted = true;
      } else {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'The transaction encountered the following problem(s): [' + res.errors + ']';
      }
    });
  }

  private getFundsWithFundValues(contractFunds: ContractFund[]) {
    return contractFunds.filter(f => f.amount && f.amount > 0);
  }

  private getTotalFundValue(contractFunds: ContractFund[]) {
    let total = 0;
    contractFunds.forEach(cf => {
      if (cf.amount && cf.amount > 0) {
        total += cf.amount;
      }
    });
    return total;
  }

}
