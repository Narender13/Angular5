import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystematicReallocationComponent } from './systematic-reallocation.component';

describe('SystematicReallocationComponent', () => {
  let component: SystematicReallocationComponent;
  let fixture: ComponentFixture<SystematicReallocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystematicReallocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystematicReallocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
