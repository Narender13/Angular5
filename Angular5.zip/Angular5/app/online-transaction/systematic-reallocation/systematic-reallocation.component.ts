import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { OnlineTransactionService } from 'app/online-transaction/shared/online-transaction.service';
import { Subject } from 'rxjs/Subject';
import { debounceTime, takeUntil } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { ContractFund } from '../../shared/models/contract-fund.model';
import { FundTransaction, OnlineTransaction, OnlineTransactionType } from '../../shared/models/online-transaction.model';
import { TenantTranslateService } from '../../shared/services/tenant-translate.service';
import { TransactionValidators } from '../shared/transaction-validator';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-systematic-reallocation',
  templateUrl: './systematic-reallocation.component.html',
  styleUrls: ['./systematic-reallocation.component.scss']
})
@AutoUnsubscribe()
@Configure('SystematicReallocationComponent')
export class SystematicReallocationComponent implements Configurable, OnInit {
  allocationForm: FormGroup;
  allocations: ContractFund[] = [];
  config: any;
  confirmNumber: string;
  contractId: string;
  contractNumber: string;
  currentDate: any;
  effectiveDate: string;
  errors = {
    frequency: '',
    startDate: '',
    endDate: '',
    duration: '',
    futureAllocation: '',
    fund: '',
    amount: '',
    total: ''
  };
  firstSubmitClick = false;
  frequency: string;
  frequencyOptions: string[] = ['Monthly', 'Quarterly', 'Semiannually', 'Annually'];
  futureAllocationTooltip: string;
  indefiniteDuration = true;
  localized: any;
  loadingFunds = true;
  originalFundValues: ContractFund[];
  ownerName: string;
  productId: string;
  selectedAllocation: ContractFund = null;
  submitDateTimestamp: string;
  submitted = false;
  submittedResponse = null;
  transactionForm: FormGroup;
  usable: boolean;
  warnings: string[];

  private ngUnsubscribe: Subject<void> = new Subject<void>();

  get availableFunds(): ContractFund[] {
    const selected = this.selectedAllocation;
    let usedFunds = this.allocations.map(f => new ContractFund(f));
    if (selected) {
      usedFunds = usedFunds.filter(f => f.fundId !== selected.fundId);
    }
    return (this.originalFundValues || [])
      .filter(item => !usedFunds.some(f => f.fundName === item.fundName));
  }

  get total(): number {
    return this.allocations
      .map(alloc => alloc.percent)
      .reduce((memo, amount) => memo + amount, 0);
  }

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private service: OnlineTransactionService,
    private datePipe: DatePipe,
    private tenantTranslateService: TenantTranslateService,
    private userService: UserService
  ) {
  }

  ngOnInit(): void {
    this.localized = this.config.translated;

    this.route.params.subscribe((params: { id: string }) => {
      if (params.id !== undefined) {
        this.contractId = params.id;
        // Temporarily hijacking ContractId constraint when it is coming in as LC~539~7100000950
        const contractParts = this.contractId.split('~');
        if (contractParts.length === 3) {
          this.contractNumber = contractParts[2];
        }
        this.service.types(params.id).subscribe(res => {
          this.service.funds(params.id)
            .subscribe(contractFunds => {
              this.loadingFunds = false;
              // clone fund values to preserve original
              this.originalFundValues = contractFunds.map(f => new ContractFund(f));
            });
          this.service.contract(this.contractId)
            .subscribe(c => { this.productId = c.productId; this.ownerName = c.personName; });
        });
      }
    });
    this.buildForms();
  }

  buildForms(): void {
    this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.futureAllocationTooltip = this.localized.applyfutureAllocationNote;
    this.allocationForm = this.fb.group({
      fund: [null, Validators.required],
      amount: [null, [Validators.required, Validators.min(1), Validators.max(100)]]
    });
    this.transactionForm = this.fb.group({
      frequency: [null, Validators.required],
      duration: [null, Validators.required],
      startDate: [this.currentDate, [Validators.required, TransactionValidators.date]],
      endDate: [null, [TransactionValidators.date, TransactionValidators.betweenDays]],
      applyReallocation: false,
      applyFutureAllocation: false,
      total: [0, [TransactionValidators.equal(100)]],
      allocationForm: this.allocationForm
    }, {
        validator: TransactionValidators.compareDates('startDate', 'endDate', 'duration')
      });
    this.transactionForm.valueChanges.pipe(
      debounceTime(500),
      takeUntil(this.ngUnsubscribe)
    ).subscribe(() => {
      const duration = this.transactionForm.get('duration').value;
      if (duration !== null) {
        this.indefiniteDuration = (duration === 'indefinite') ? true : false;
      }
    });
  }

  addAllocation(): void {
    this.resetErrors();
    if (!this.allocationForm.valid) {
      this.compileErrors(this.allocationForm, true);
      return;
    }
    const allocation = new ContractFund();
    const fund = this.originalFundValues.find(f => f.fundId === this.allocationForm.get('fund').value);
    allocation.fundId = fund.fundId;
    allocation.fundName = fund.fundName;
    allocation.percent = this.allocationForm.get('amount').value;
    this.allocations.push(allocation);
    this.syncTotal();
    this.allocationForm.reset();
  }

  syncTotal(): void {
    this.transactionForm.patchValue({ total: this.total });
  }

  startEdit(allocation: ContractFund): void {
    this.submittedResponse = null;
    if (this.selectedAllocation === allocation) {
      return this.cancelEdit();
    }
    this.selectedAllocation = allocation;
    this.transactionForm.patchValue({
      allocationForm: allocation
    });
    this.allocationForm.setValue({
      fund: allocation.fundId,
      amount: allocation.percent
    });
  }

  updateAllocation(): void {
    const form = this.allocationForm;
    this.resetErrors();
    if (!this.allocationForm.valid) {
      this.compileErrors(this.allocationForm, true);
      return;
    }
    const allocation = this.selectedAllocation;
    const fund = this.originalFundValues.find(f => f.fundId === form.get('fund').value);
    allocation.fundId = fund.fundId;
    allocation.fundName = fund.fundName;
    allocation.percent = form.get('amount').value;
    this.syncTotal();
    this.cancelEdit();
  }

  removeAllocation(): void {
    const allocation = this.selectedAllocation;
    const index = this.allocations.indexOf(allocation);

    if (index !== -1) {
      this.allocations.splice(index, 1);
    }

    this.syncTotal();
    this.cancelEdit();
  }

  cancelEdit(): void {
    this.selectedAllocation = null;
    this.allocationForm.reset();
  }

  submitTransaction() {
    this.submitted = false;
    this.submittedResponse = null;
    const form = this.transactionForm;
    const total = form.get('total').value;
    this.resetErrors();
    if ((!form.valid) && (total !== 100)) {
      return this.compileErrors(this.transactionForm, true);
    }

    this.firstSubmitClick = true;

    const transaction = new OnlineTransaction();
    transaction.contractId = this.contractId;
    transaction.userName = this.userService.user.profile.name;
    transaction.transactionType = OnlineTransactionType.SystematicReallocation;
    transaction.applyReallocation = form.get('applyReallocation').value;
    transaction.applyFutureAllocation = form.get('applyFutureAllocation').value;
    transaction.productId = this.productId;
    transaction.ownerName = this.ownerName;

    // assumption is the asset source is the same for all funds for contract
    const fund = this.originalFundValues.find(f => f.fundId === this.allocations[0].fundId);
    if (fund.assetSource === null) {
      transaction.assetSource = 'NANA';
    } else {
      transaction.assetSource = fund.assetSource;
    }

    transaction.frequency = form.get('frequency').value;
    transaction.startDate = form.get('startDate').value;
    transaction.endDate = form.get('endDate').value;
    transaction.totalAmount = form.get('total').value;
    transaction.duration = form.get('duration').value;

    const ft = new Array<FundTransaction>();
    this.allocations.forEach(a => {
      const f = new FundTransaction();
      f.fundId = a.fundId;
      f.amountType = 'P';             // D/P : Dollar or Percent
      f.direction = 'T';           // T/F : To or From
      f.amount = a.percent;
      f.fundName = a.fundName;
      ft.push(f);
    });
    transaction.funds = ft;

    // Block transaction if a soft-closed fund is used
    const softCloseFunds = this.originalFundValues.filter(f => f.softClose === 1);

    if (softCloseFunds.some(f => {
      const transactionFund = transaction.funds.find(tf => tf.fundId === f.fundId);
      if (transactionFund != null) {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'Cannot use soft-closed fund:  ' + f.fundName;
        return true;
      }
    })) {
      return;
    }

    this.service.save(transaction).subscribe(res => {
      if (res.success && !res.hasErrors) {
        this.submittedResponse = 'The transaction has been submitted.';
        this.confirmNumber = res.confirmNumber;
        this.submitDateTimestamp = res.submitDateTime.toString();
        this.effectiveDate = res.effectiveDate.toString();
        if (res.hasWarnings && res.warnings.length > 0) {
          this.warnings = res.warnings;
        }
        this.submitted = true;
      } else {
        this.firstSubmitClick = false;
        this.submitted = false;
        this.submittedResponse = 'The transaction encountered the following problem(s): [' + res.errors + ']';
      }
    });
  }

  resetErrors() {
    for (const field of Object.keys(this.errors)) {
      this.errors[field] = '';
    }
  }

  compileErrors(form: FormGroup, ignDirty?: boolean) {
    const ignoreDirty = ignDirty === null ? false : ignDirty;
    let count = 0;
    for (const field of Object.keys(this.errors)) {
      if (form.contains(field)) {
        const control = form.get(field);
        this.errors[field] = '';
        if (control.dirty || ignoreDirty) {
          if (!control.valid) {
            for (const key of Object.keys(control.errors)) {
              this.errors[field] += this.localized.messages[field][key];
              count++;
            }
          }
        }
      }
    }
    return count;
  }

  resetTransaction() {
    this.cancelEdit();
    this.transactionForm.reset({ onlySelf: true });
    this.allocations.length = 0;
    this.submitted = false;
    this.submittedResponse = null;
    this.transactionForm.get('startDate').setValue(this.currentDate);
    this.resetErrors();
  }

  syncDates() {
    // if duration is indefinite, the "end date" field is not displayed
    // validations fail and show no error on submit because end date is potentially uninitialized
    if ((this.transactionForm.get('duration').value === 'indefinite') || !(this.transactionForm.get('endDate').value)) {

      // Only set end date to startDate if the day is between 1-28
      const startDate = this.transactionForm.get('startDate').value;
      const today = new Date();
      if (startDate && today.getDate() <= 28) {
        this.transactionForm.get('endDate').setValue(startDate);
      } else {
        // Set end date to first day of next month to bypass 1-28 day additional validation check
        let found = false;
        let tempDay = today;
        while (!found) {
          tempDay = new Date(tempDay.getFullYear(), tempDay.getMonth(), tempDay.getDate() + 1);
          if (tempDay.getDate() === 1) {
            this.transactionForm.get('endDate').setValue(tempDay.toString());
            found = true;
          }
        }
      }
    }
  }
}
