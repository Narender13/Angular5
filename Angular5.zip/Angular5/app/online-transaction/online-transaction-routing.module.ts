import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { onlineTransactionRoutes } from 'app/online-transaction/shared/auth-transaction/auth-transaction-routes';
import { AuthGuardService } from 'app/shared/services/auth-guard.service';
import { OnlineTransactionSelectionComponent } from './shared/auth-transaction/auth-transaction.component';

export const routes: Routes = [
  {
    path: 'contracts/:contractId/online-transaction',
    component: OnlineTransactionSelectionComponent, canActivate: [AuthGuardService]
  }, ...onlineTransactionRoutes
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OnlineTransactionRoutingModule { }
