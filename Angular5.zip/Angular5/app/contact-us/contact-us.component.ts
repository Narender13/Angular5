import { Component, OnInit } from '@angular/core';
import { LoggingService } from '../shared/logging/logging.service';
import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../shared/decorators/configurable';


@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
@AutoUnsubscribe()
@Configure('ContactUsComponent')
export class ContactUsComponent implements Configurable, OnInit {
  config: any;
  contactUsHtml = 'no contact us information found';
  usable: boolean;

  constructor(private loggingService: LoggingService
  ) { }

  ngOnInit() {
    this.contactUsHtml = this.config.text;
  }

}
