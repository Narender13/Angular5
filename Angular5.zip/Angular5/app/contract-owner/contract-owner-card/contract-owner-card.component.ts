import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { ContractOwnerService } from '../shared/contract-owner.service';
import { ContractOwner } from '../../shared/models/contract-owner.model';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-contract-owner-card',
  templateUrl: './contract-owner-card.component.html',
  styles: []
})
@Configure('ContractOwnerCardComponent')
@AutoUnsubscribe()
export class ContractOwnerCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  limit = 5;
  contractOwners: Observable<ContractOwner[]>;
  usable: any;

  constructor(private service: ContractOwnerService) { }

  ngOnInit() {
    this.limit = this.config.cardLimit || this.limit;
    this.contractOwners = this.service.list(null, this.limit, 0, this.config.orderby).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
