import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { ContractOwner } from '../../shared/models/contract-owner.model';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { ContractOwnerService } from '../shared/contract-owner.service';
import { ToolbarActionHandlers, ToolbarActionable } from '../../shared/services/toolbar-action-handler';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { PageParams } from '../../shared/models/paginated.interface';

@Component({
  selector: 'app-contract-owner-grid',
  templateUrl: './contract-owner-grid.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ContractOwnerGridComponent')
export class ContractOwnerGridComponent implements Configurable, OnInit, ToolbarActionable {
  contractOwners: Observable<ContractOwner[]>;
  config: any;
  activeTool: string;
  usable: boolean;
  count: Observable<number>;
  loading = true;
  localized: any;
  sortFields: string[] = [
    'contractNumber Asc',
    'contractNumber Desc',
    'personName Asc',
    'personName Desc'
  ];
  tools = ['print', 'export'];

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: ContractOwnerService
  ) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.localized = this.config.translated;
    this.contractOwners = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: PageParams) => {
        const { q, limit = this.config.limit, offset = 0, orderby = this.config.orderby } = params;
        this.config.limit = limit;
        this.config.offset = offset;
        this.config.orderby = orderby || this.sortFields[0];
        return this.service.list(q, this.config.limit, this.config.offset, this.config.orderby);
      }),
      tap(() => this.loading = false)
    );
    ToolbarActionHandlers.handle(this);
  }

  onExport(): Observable<any> {
    return this.service.export();
  }
}
