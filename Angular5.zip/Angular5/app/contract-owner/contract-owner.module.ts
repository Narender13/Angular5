import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { ContractOwnerRoutingModule } from './contract-owner-routing.module';
import { ContractOwnerCardComponent } from './contract-owner-card/contract-owner-card.component';
import { ContractOwnerChipComponent } from './contract-owner-chip/contract-owner-chip.component';
import { ContractOwnerListComponent } from './contract-owner-list/contract-owner-list.component';
import { ContractOwnerGridComponent } from './contract-owner-grid/contract-owner-grid.component';
import { ContractOwnerService } from './shared/contract-owner.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ContractOwnerRoutingModule
  ],
  declarations: [
    ContractOwnerCardComponent,
    ContractOwnerChipComponent,
    ContractOwnerListComponent,
    ContractOwnerGridComponent
  ],
  exports: [
    ContractOwnerCardComponent,
    ContractOwnerChipComponent
  ],
  providers: [
    ContractOwnerService
  ]
})
export class ContractOwnerModule { }
