import { Component, Input } from '@angular/core';
import { ContractOwner } from '../../shared/models/contract-owner.model';

@Component({
  selector: 'app-contract-owner-chip',
  templateUrl: './contract-owner-chip.component.html',
  styles: [':host{width:100%;}']
})
export class ContractOwnerChipComponent {
  @Input() contractOwner: ContractOwner;

  constructor() { }
}
