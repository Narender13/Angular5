import { Injectable } from '@angular/core';
import { Response, ResponseContentType, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { map } from 'rxjs/operators';

import { ContractOwner } from '../../shared/models/contract-owner.model';
import { Paginated } from '../../shared/models/paginated.interface';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ContractOwnerService {
  private apiUrl = 'contractowner/';
  private lastCount = new Subject<number>();

  constructor(
    private http: UWHttp) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, limit: number, offset: number, orderby: string): Observable<ContractOwner[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('searchvalue', search);
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this)
    );
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.apiUrl}export?format=csv`, 'client-report.csv', options);
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<ContractOwner>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }
}
