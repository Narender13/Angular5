import { Component, OnInit, Input } from '@angular/core';

import { ProductAsset } from '../../shared/models/product-asset.model';

@Component({
  selector: 'app-product-asset-list',
  templateUrl: './product-asset-list.component.html',
  styles: []
})
export class ProductAssetListComponent implements OnInit {
  @Input() productAssets: ProductAsset[];

  constructor() { }

  ngOnInit() { }
}
