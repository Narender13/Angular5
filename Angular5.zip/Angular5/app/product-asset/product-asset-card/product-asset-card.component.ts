import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AssetValueService } from '../shared/asset-value.service';
import { ProductAsset } from '../../shared/models/product-asset.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-product-asset-card',
  templateUrl: './product-asset-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ProductAssetCardComponent')
export class ProductAssetCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  productAssets: Observable<ProductAsset[]>;
  usable: any;

  constructor(
    private service: AssetValueService
  ) { }

  ngOnInit() {
    this.productAssets = this.service.list(null, null, null).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
