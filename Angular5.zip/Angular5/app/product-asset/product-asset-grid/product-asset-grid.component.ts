import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map, tap, share } from 'rxjs/operators';

import { AssetValueService } from '../shared/asset-value.service';
import { ToolbarActionHandlers, ToolbarActionable } from 'app/shared/services/toolbar-action-handler';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { ProductAsset } from '../../shared/models/product-asset.model';

@Component({
  selector: 'app-product-asset-grid',
  templateUrl: './product-asset-grid.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ProductAssetGridComponent')
export class ProductAssetGridComponent implements Configurable, OnInit, ToolbarActionable {
  config: any;
  count: Observable<number>;
  totalValue: Observable<number>;
  productAssets: Observable<ProductAsset[]>;
  tools = ['print', 'export'];
  activeTool: string;
  usable: boolean;
  loading = true;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: AssetValueService
  ) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.totalValue = this.service.totalValue().pipe(share());
    this.productAssets = this.service.list().pipe(
      tap(() => this.loading = true),
      map(list => list),
      tap(() => this.loading = false),
      share()
    );
    ToolbarActionHandlers.handle(this);
  }

  onExport(): Observable<any> {
    return this.service.export();
  }
}
