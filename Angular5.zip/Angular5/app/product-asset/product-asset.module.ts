import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { ProductAssetChartComponent } from './product-asset-chart/product-asset-chart.component';
import { ProductAssetCardComponent } from './product-asset-card/product-asset-card.component';
import { ProductAssetChipComponent } from './product-asset-chip/product-asset-chip.component';
import { ProductAssetGridComponent } from './product-asset-grid/product-asset-grid.component';
import { ProductAssetListComponent } from './product-asset-list/product-asset-list.component';
import { ProductAssetDetailComponent } from './product-asset-detail/product-asset-detail.component';
import { ProductAssetRoutingModule } from './product-asset-routing.module';
import { AssetValueService } from './shared/asset-value.service';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    ProductAssetCardComponent,
    ProductAssetChipComponent,
    ProductAssetListComponent,
    ProductAssetGridComponent,
    ProductAssetChartComponent,
    ProductAssetDetailComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ProductAssetRoutingModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [ProductAssetChartComponent, ProductAssetCardComponent],
  providers: [AssetValueService]
})
export class ProductAssetModule { }
