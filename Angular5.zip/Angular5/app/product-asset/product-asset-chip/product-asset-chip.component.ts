import { Component, OnInit, Input } from '@angular/core';
import { ProductAsset } from '../../shared/models/product-asset.model';

@Component({
  selector: 'app-product-asset-chip',
  templateUrl: './product-asset-chip.component.html',
  styles: [':host{width:100%;}']
})
export class ProductAssetChipComponent implements OnInit {
  @Input() product: ProductAsset;
  constructor() { }

  ngOnInit() {
  }
}
