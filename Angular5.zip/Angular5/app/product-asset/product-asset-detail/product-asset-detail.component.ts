import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AssetValueService } from '../shared/asset-value.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { FundAsset } from '../../shared/models/fund-asset.model';

@Component({
  selector: 'app-product-asset-detail',
  templateUrl: './product-asset-detail.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ProductAssetDetailComponent')
export class ProductAssetDetailComponent implements Configurable, OnInit {
  config: any;
  fundAssets: Observable<FundAsset[]>;
  productName: Observable<string>;
  totalValue: Observable<number>;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: AssetValueService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    const productId = routeParams.id;
    this.fundAssets = this.service.getDetails(productId).pipe(share());
    this.productName = this.fundAssets.map(assets => assets[0].productName);
    this.totalValue = this.fundAssets.map(assets => assets.reduce((memo, f) => memo + f.amount, 0));
  }
}
