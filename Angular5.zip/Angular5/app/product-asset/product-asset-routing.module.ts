import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { ProductAssetGridComponent } from './product-asset-grid/product-asset-grid.component';
import { ProductAssetDetailComponent } from './product-asset-detail/product-asset-detail.component';

const routes: Routes = [{
  path: 'assets/action/:action',
  component: ProductAssetGridComponent,
  canActivate: [AuthGuardService]
}, {
  path: 'assets/:id',
  component: ProductAssetDetailComponent,
  canActivate: [AuthGuardService]
}, {
  path: 'assets',
  component: ProductAssetGridComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductAssetRoutingModule { }
