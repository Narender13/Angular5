import { Injectable } from '@angular/core';
import { Response, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { FundAsset } from '../../shared/models/fund-asset.model';
import { LoggingService } from '../../shared/logging/logging.service';
import { Paginated } from '../../shared/models/paginated.interface';
import { ProductAsset } from '../../shared/models/product-asset.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class AssetValueService {
  private apiUrl = 'ProductAssets/';
  private lastCount = new Subject<number>();
  private total = new Subject<number>();

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  totalValue(): Observable<number> {
    return this.total.asObservable();
  }

  list(search?: string, limit?: number, offset?: number): Observable<ProductAsset[]> {
    return this.http.authGet(this.apiUrl).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError));
  }

  getDetails(productId): Observable<FundAsset[]> {
    return this.http.authGet(this.apiUrl + productId + '/detail').pipe(
      map(res => res.json() as FundAsset[]),
      catchError(this.loggingService.handleError));
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.apiUrl}export?format=csv`, 'product-assets.csv', options);
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<ProductAsset>;
    this.lastCount.next(body.totalCount);
    this.total.next(body.items.reduce((memo, p) => memo + p.cashValue, 0));
    return body.items || [];
  }
}
