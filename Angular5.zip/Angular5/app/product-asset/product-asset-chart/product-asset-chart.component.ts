import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';
import { of } from 'rxjs/observable/of';

import { AssetValueService } from '../shared/asset-value.service';
import { TenantTranslateService } from '../../shared/services/tenant-translate.service';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { UsdCurrencyPipe } from '../../shared/locale/usd-currency.pipe';
import { ProductAsset } from '../../shared/models/product-asset.model';

@Component({
  selector: 'app-product-asset-chart',
  templateUrl: './product-asset-chart.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ProductAssetChartComponent')
export class ProductAssetChartComponent implements Configurable, OnInit {
  config: any;
  @Input() productAssets: ProductAsset[];
  @Input() legendPosition: string;
  @Input() hideFooter: boolean;
  productAssetsObs: Observable<ProductAsset[]>;
  pieChartData: Observable<number[]>;
  pieChartLabels: Observable<string[]>;
  pieChartOptions: any;
  usable: any;

  constructor(
    private service: AssetValueService,
    private tenantTranslateService: TenantTranslateService,
    private usdPipe: UsdCurrencyPipe
  ) { }

  ngOnInit() {
    if (this.config.pieChartOptions) {
      this.pieChartOptions = this.config.pieChartOptions;
    } else {
      this.pieChartOptions = {
        layout: {
          padding: 10
        },
        legend: {
          position: this.legendPosition || 'right',
          labels: {
            boxWidth: 10,
            fontSize: 10
          }
        }
      };
    }
    this.initChart();

    if (typeof (this.productAssets) === 'undefined') {
      this.productAssetsObs = this.service.list(null, null, null).pipe(share());
    } else {
      this.productAssetsObs = of(this.productAssets);
    }

    this.pieChartData = this.productAssetsObs.map(assets => assets.map(f => f.cashValue));
    this.pieChartLabels = this.productAssetsObs.map(assets => assets.map(f => this.tenantTranslateService.getInstant(f.productName)));
  }

  initChart() {
    this.pieChartOptions = Object.assign({}, this.pieChartOptions, {
      tooltips: {
        callbacks: {
          label: (tooltipItem, data) => {
            const amount = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
            return this.usdPipe.transform(amount);
          }
        }
      }
    });
  }
}
