import { Component, OnInit, Input } from '@angular/core';
import { UserService } from 'app/shared/services/user.service';
import { Portfolio } from '../../shared/models/portfolio.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';

@AutoUnsubscribe()
@Component({
  selector: 'app-contract-portfolio-list',
  templateUrl: './contract-portfolio-list.component.html',
  styles: []
})
export class ContractPortfolioListComponent implements OnInit {
  @Input() portfolios: Array<Portfolio>;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.userPreferencesObs
    .subscribe(() => {
      if (!this.portfolios) {
        const unSorted = (this.userService.userPreferences.get('portfolio') as Array<Portfolio>);
        if (unSorted) {
          this.portfolios = unSorted.sort((a: Portfolio, b: Portfolio) => 0 - (a.name.toLowerCase() > b.name.toLowerCase() ? -1 : 1));
        } else {
          this.portfolios = [];
        }
      }
    });
  }
}
