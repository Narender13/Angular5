import { Component, Input } from '@angular/core';

import { Contract } from '../../shared/models/contract.model';

@Component({
  selector: 'app-contract-list',
  templateUrl: './contract-list.component.html',
  styleUrls: []
})
export class ContractListComponent {
  @Input() contracts: Contract[];

  constructor() { }
}
