import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { AssetAllocationModule } from '../asset-allocation/asset.allocation.module';
import { BillingModule } from '../billing/billing.module';
import { CashValueModule } from '../cash-value/cash-value.module';
import { ContractCardComponent } from './contract-card/contract-card.component';
import { ContractChipComponent } from './contract-chip/contract-chip.component';
import { ContractDashboardComponent } from './contract-dashboard/contract-dashboard.component';
import { ContractDetailComponent } from './contract-detail/contract-detail.component';
import { ContractGridComponent } from './contract-grid/contract-grid.component';
import { ContractListComponent } from './contract-list/contract-list.component';
import { ContractPortfolioCardComponent } from './contract-portfolio-card/contract-portfolio-card.component';
import { ContractPortfolioDetailComponent } from './contract-portfolio-detail/contract-portfolio-detail.component';
import { ContractPortfolioGridComponent } from './contract-portfolio-grid/contract-portfolio-grid.component';
import { ContractPortfolioListComponent } from './contract-portfolio-list/contract-portfolio-list.component';
import { ContractPortfolioWidgetComponent } from './contract-portfolio-widget/contract-portfolio-widget.component';
import { ContractRoutingModule } from './contract-routing.module';
import { ContractService } from './shared/contract.service';
import { ContractPortfolioService } from './shared/contract-portfolio.service';
import { DocumentModule } from '../document/document.module';
import { FundValueModule } from '../fund-value/fund-value.module';
import { OnlineTransactionModule } from '../online-transaction/online-transaction.module';
import { PeopleModule } from '../people/people.module';
import { SharedModule } from '../shared/shared.module';
import { TaxFormModule } from 'app/tax-form/tax-form.module';
import { TransactionModule } from '../transaction/transaction.module';

@NgModule({
  declarations: [
    ContractCardComponent,
    ContractChipComponent,
    ContractDashboardComponent,
    ContractDetailComponent,
    ContractGridComponent,
    ContractListComponent,
    ContractPortfolioCardComponent,
    ContractPortfolioDetailComponent,
    ContractPortfolioGridComponent,
    ContractPortfolioListComponent,
    ContractPortfolioWidgetComponent
  ],
  imports: [
    AssetAllocationModule,
    BillingModule,
    CashValueModule,
    CommonModule,
    ContractRoutingModule,
    DocumentModule,
    FundValueModule,
    OnlineTransactionModule,
    PeopleModule,
    ReactiveFormsModule,
    SharedModule,
    TaxFormModule,
    TransactionModule
  ],
  exports: [
    ContractCardComponent,
    ContractChipComponent,
    ContractPortfolioCardComponent
  ],
  providers: [
    ContractService,
    ContractPortfolioService
  ]
})
export class ContractModule { }
