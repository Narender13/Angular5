import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { ContractGridComponent } from './contract-grid/contract-grid.component';
import { ContractDashboardComponent } from './contract-dashboard/contract-dashboard.component';
import { ContractPortfolioGridComponent } from './contract-portfolio-grid/contract-portfolio-grid.component';
import { ContractPortfolioDetailComponent } from './contract-portfolio-detail/contract-portfolio-detail.component';

const routes: Routes = [
  { path: 'contracts/:contractId', component: ContractDashboardComponent, canActivate: [AuthGuardService] },
  { path: 'contracts', component: ContractGridComponent, canActivate: [AuthGuardService] },
  { path: 'portfolios', component: ContractPortfolioGridComponent, canActivate: [AuthGuardService] },
  { path: 'portfolios/:portfolioName', component: ContractPortfolioDetailComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractRoutingModule { }
