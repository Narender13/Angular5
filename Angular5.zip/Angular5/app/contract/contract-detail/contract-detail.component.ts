import { ActivatedRoute } from '@angular/router';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Component, OnInit, Input } from '@angular/core';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { Contract } from '../../shared/models/contract.model';
import { ContractService } from '../shared/contract.service';

@Component({
  selector: 'app-contract-detail',
  templateUrl: './contract-detail.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ContractDetailComponent')
export class ContractDetailComponent implements Configurable, OnInit {
  @Input() contract: Contract;
  @Input() hideContextMenu = false;
  config: any;
  contextMenuAvailable: boolean;
  currentProduct: any;
  localized: any;
  usable: boolean;
  showOneTimePaymentLink = false;

  constructor(
    private route: ActivatedRoute,
    private service: ContractService
  ) { }

  ngOnInit() {
    this.contextMenuAvailable = !this.hideContextMenu && this.config.contextMenu && this.config.contextMenu.length > 0;
    const routeParams = this.route.snapshot.params as { contractId: string };
    const contractId = routeParams.contractId;

    if (this.contract) {
      this.updateContextMenu();
    } else if (contractId) {
      this.service.find(contractId).subscribe(item => {
        this.contract = item;
        this.currentProduct = item.productId;
        this.updateContextMenu();
      });
    }
    if (this.contract && this.contract.contractStatus.toLowerCase() === 'lapse pending') {
      this.showOneTimePaymentLink = true;
    }
    this.localized = this.config.translated;
    console.log("loading");
    console.log(this.localized);
  }

  private updateContextMenu() {
    if (this.contextMenuAvailable) {
      this.config.contextMenu = this.config.contextMenu.map(item => {
        item.route = item.route.replace(':contractId', this.contract.id);
        return item;
      });
    }
  }
}
