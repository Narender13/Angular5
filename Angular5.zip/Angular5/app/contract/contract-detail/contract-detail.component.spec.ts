
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';


import { By } from '@angular/platform-browser';
import { Component, DebugElement, Pipe, PipeTransform } from '@angular/core';
import { Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ContractService } from '../shared/contract.service';
import { Contract } from '../../shared/models/contract.model';

import { ContractDetailComponent } from './contract-detail.component';

import { ReflectiveInjector } from '@angular/core';
import { BaseRequestOptions, ConnectionBackend, Http, RequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

@Component({
  template: ''
})
class DummyComponent {
}

const contractRoutes: Routes = [{
  path: 'contracts/:id',
  component: DummyComponent
},
{
  path: 'contracts',
  component: DummyComponent
}
];

const sampleContracts = [
  {
    'id': 1,
    'contractNumber': '7200000512',
    'accountNumber': '7200000512',
    'productID': 700,
    'ownerName': 'SALTS, DEBRA D',
    'firstName': 'Debra',
    'lastName': 'Salts',
    'taxCategory': '401A',
    'productCode': '557',
    'policyStatus': 'C',
    'isSuspended': '0',
    'productName': 'Industrial Centrifuge Index',
    'accountValue': 308346.69,
    'asOfDate': null,
    'inforceFlag': 'A',
    'planCode': '557',
    'issueState': 'KS',
    'issueDate': null,
    'isMorningStarEnrolled': 'Y',
    'isMorningStarEligible': '',
    'productCategory': 'FIA',
    'sourceSystem': '6',
    'masterNumber': 'MA92311887',
    'qualificationType': 'QUAL',
    'servicingAgent': 'John Jacob',
    'applicationStatus': 'Pending',
    'paymentsExpected': '250000.0',
    'paymentsApplied': '0.0',
    'applicationDateSigned': null,
    'applicationPendingReason': 'NIGO',
    'planID': 0,
    'planNumber': '',
    'status': '',
    'electronicAuthorization': '',
    'contributionType': '',
    'applicationDate': null,
    'contractIssueDate': null,
    'modifiedEndowmentStatus': '',
    'marketSegment': '',
    'productLine': '',
    'productBusinessLine': '',
    'personId': null,
    'createdDate': null,
    'lastUpdatedDate': null,
    'policyNumber': null,
    'watchStatus': null,
    'comissionOption': null,
    'taxCategoryDescription': null,
    'maturityDate': null,
    'nextPayoutDate': null,
    'payoutEndDate': null,
    'payoutCommencementDate': null
  }
  ,
  {
    'id': 2,
    'contractNumber': '7200000512', 'accountNumber': '7200000512', 'productID': 700, 'ownerName': 'SALTS, DEBRA D',
    'firstName': 'Debra', 'lastName': 'Salts', 'taxCategory': '401A', 'productCode': '557',
    'policyStatus': 'C', 'isSuspended': '0', 'productName': 'Industrial Centrifuge Index', 'accountValue': 308346.69,
    'asOfDate': null, 'inforceFlag': 'A', 'planCode': '557', 'issueState': 'KS',
    'issueDate': null, 'isMorningStarEnrolled': 'Y', 'isMorningStarEligible': '', 'productCategory': 'FIA',
    'sourceSystem': '6', 'masterNumber': 'MA92311887', 'qualificationType': 'QUAL', 'servicingAgent': 'John Jacob',
    'applicationStatus': 'Pending', 'paymentsExpected': '250000.0', 'paymentsApplied': '0.0', 'applicationDateSigned': null,
    'applicationPendingReason': 'NIGO', 'planID': 0, 'planNumber': '', 'status': '',
    'electronicAuthorization': '', 'contributionType': '', 'applicationDate': null, 'contractIssueDate': null,
    'modifiedEndowmentStatus': '', 'marketSegment': '', 'productLine': '', 'productBusinessLine': '',
    'personId': null, 'createdDate': null, 'lastUpdatedDate': null, 'policyNumber': null,
    'watchStatus': null, 'comissionOption': null, 'taxCategoryDescription': null, 'maturityDate': null,
    'nextPayoutDate': null, 'payoutEndDate': null, 'payoutCommencementDate': null
  }
];

class ContractServiceStub {
  contracts: Contract[];
  contract: Contract;
  constructor(contracts: Contract[]) { this.contracts = contracts; this.contract = contracts[0]; }
  list(): Observable<Contract[]> {
    const injector = ReflectiveInjector.resolveAndCreate([
      { provide: ConnectionBackend, useClass: MockBackend },
      { provide: RequestOptions, useClass: BaseRequestOptions },
      Http,
    ]);
    const http = injector.get(Http);
    return http.get(JSON.stringify(this.contracts)).map(res => res.json().data as Contract[]);
  }
};

describe('ContractDetailComponent', () => {
  let component: ContractDetailComponent;
  let fixture: ComponentFixture<ContractDetailComponent>;
  const contractService: ContractServiceStub = new ContractServiceStub(sampleContracts);

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(contractRoutes)],
      declarations: [
        ContractDetailComponent,
        MockPipe,
        DummyComponent
      ],
      providers: [{ provide: Pipe, useValue: mockPipe },
      { provide: ContractService, useValue: contractService }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractDetailComponent);
    component = fixture.componentInstance;
    component.contract = contractService.contract;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a header', () => {
    let de: DebugElement;
    let el: HTMLElement;
    de = fixture.debugElement;
    // query for the title
    de = fixture.debugElement.query(By.css('.card-title'));
    el = de.nativeElement;
    expect(el.textContent).toEqual('0.0 for 0.0');
    fixture.detectChanges();
  });

});
