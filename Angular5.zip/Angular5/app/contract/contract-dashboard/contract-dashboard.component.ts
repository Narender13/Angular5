import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-dashboard',
  templateUrl: './contract-dashboard.component.html',
  styles: []
})
export class ContractDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
