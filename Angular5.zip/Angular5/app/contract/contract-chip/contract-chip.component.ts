import { Component, Input } from '@angular/core';

import { Contract } from '../../../app/shared/models/contract.model';

@Component({
  selector: 'app-contract-chip',
  templateUrl: './contract-chip.component.html',
  styles: [':host{width:100%;}']
})
export class ContractChipComponent {
  @Input() contract: Contract;

  constructor() { }
}
