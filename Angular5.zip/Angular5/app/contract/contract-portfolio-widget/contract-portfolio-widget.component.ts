import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { ContractPortfolioService } from '../shared/contract-portfolio.service';
import { ContractService } from '../../contract/shared/contract.service';
import { UserService } from '../../shared/services/user.service';

import { Contract } from '../../shared/models/contract.model';
import { Portfolio } from '../../shared/models/portfolio.model';

declare var $: Function;

@AutoUnsubscribe()
@Component({
  selector: 'app-contract-portfolio-widget',
  templateUrl: './contract-portfolio-widget.component.html',
  styleUrls: ['./contract-portfolio-widget.component.scss']
})
export class ContractPortfolioWidgetComponent implements OnInit {
  @Input() type: string; // add, remove
  selectedContracts: Contract[] = [];
  portfolios: Array<Portfolio>;
  formModel: FormGroup;
  showNewPortfolioInput = false;

  constructor(
    private fb: FormBuilder,
    private contractService: ContractService,
    private service: ContractPortfolioService,
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.selectedContracts = this.contractService.selectedContracts;

    this.userService.userPreferencesObs
    .subscribe(() => {
      const unSorted = (this.userService.userPreferences.get('portfolio') as Array<Portfolio>);
      if (unSorted) {
        this.portfolios = unSorted.sort((a: Portfolio, b: Portfolio) => 0 - (a.name.toLowerCase() > b.name.toLowerCase() ? -1 : 1));
      } else {
        this.portfolios = [];
      }
    });

    this.formModel = this.fb.group({
      'name': [null, [Validators.required]]
    });
  }

  addToPortfolio(name: string) {
    const pf = this.portfolios.find(p => p.name === name);
    if (pf) {
      this.selectedContracts.forEach((contract) => {
        const found = pf.contracts.find(c => c.contractNumber === contract.contractNumber);
        if (!found) {
          pf.contracts.push({ contractNumber: contract.contractNumber, id: contract.id, owner: contract.personName });
        }
      });
      this.userService.setPreference({ portfolio: this.portfolios }).subscribe(() => {
        this.router.navigate(['portfolios', name]);
      });
      this.selectedContracts = this.contractService.resetSelectedContracts();
    } else {
      console.log('Could not find portfolio. Please try again.');
    }
  }

  createNewPortfolio(name: string) {
    // If no name, don't hide dropdown and show error
    if (!name) {
      $('#addPortfolioDropdown').on('hide.bs.dropdown', () => false);
      this.formModel.get('name').markAsDirty();
      return;
    }

    const pf = this.portfolios.find(p => p.name === name);
    const newPortfolio = [];
    if (!pf) {
      this.selectedContracts.forEach((contract) => {
        newPortfolio.push({ contractNumber: contract.contractNumber, id: contract.id, owner: contract.personName });
      });

      const newPf: Portfolio = { name: name.trim(), contracts: newPortfolio };
      this.portfolios.push(newPf);
      this.userService.setPreference({ portfolio: this.portfolios }).subscribe(() => {
        this.router.navigate(['portfolios', name]);
      });
      this.formModel.reset();
      this.selectedContracts = this.contractService.resetSelectedContracts();
    } else {
      const allPortfolios = this.portfolios.filter(p => p.name === name || (p.name.includes(name) && p.name.includes('(')));

      // If more than 1 with the same name, find the highest number and add 1. Otherwise set it to 2
      let num: number;
      if (allPortfolios.length > 1) {
        let highestNum = 1;
        allPortfolios.forEach((port) => {
          const checkNum = port.name.match(/\d+/) ? port.name.match(/\d+/)[port.name.match(/\d+/).length - 1] : '1';
          highestNum = parseInt(checkNum, 10) > highestNum ? parseInt(checkNum, 10) : highestNum;
        });
        num = highestNum + 1;
      } else {
        num = 2;
      }

      this.selectedContracts.forEach((contract) => {
        newPortfolio.push({ contractNumber: contract.contractNumber, id: contract.id, owner: contract.personName });
      });

      const finalName = `${name.trim()} (${num})`;
      const newPf: Portfolio = { name: finalName, contracts: newPortfolio };
      this.portfolios.push(newPf);
      this.userService.setPreference({ portfolio: this.portfolios }).subscribe(() => {
        this.router.navigate(['portfolios', finalName]);
      });
      this.formModel.reset();
      this.selectedContracts = this.contractService.resetSelectedContracts();
    }
  }

  removeFromPortfolio() {
    let pf: Portfolio;
    this.route.params.subscribe(params => pf = this.portfolios.find(p => p.name === params.portfolioName));

    if (pf) {
      this.selectedContracts.forEach((contract) => {
        const index = pf.contracts.findIndex(c => c.contractNumber === contract.contractNumber);
        if (index !== -1) {
          pf.contracts.splice(index, 1);
        }
      });
      this.userService.setPreference({ portfolio: this.portfolios }).subscribe();
      this.selectedContracts = this.contractService.resetSelectedContracts();
      this.service.removePortfolio(pf);
    } else {
      console.log('Could not find portfolio. Please try again.');
    }
  }
}
