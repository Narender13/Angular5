import { Component, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/user.service';
import { Portfolio } from '../../shared/models/portfolio.model';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-contract-portfolio-card',
  templateUrl: './contract-portfolio-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ContractPortfolioCardComponent')
export class ContractPortfolioCardComponent implements OnInit {
  portfolios: Array<Portfolio>;
  count: number;
  usable: any;

  constructor(
    private userService: UserService
  ) { }

  ngOnInit() {
    this.userService.userPreferencesObs
    .subscribe(() => {
      const unSorted = (this.userService.userPreferences.get('portfolio') as Array<Portfolio>);
      if (unSorted) {
        this.portfolios = unSorted.sort((a: Portfolio, b: Portfolio) => 0 - (a.name.toLowerCase() > b.name.toLowerCase() ? -1 : 1));
        this.count = this.portfolios.length;
      } else {
        this.portfolios = [];
        this.count = 0;
      }
    });
  }

}
