import { URLSearchParams, ResponseContentType } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { map, tap, mergeMap, first } from 'rxjs/operators';

import { Paginated } from '../../shared/models/paginated.interface';
import { Contract } from '../../shared/models/contract.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ContractService {
  private apiUrl = 'contracts/';
  private count$ = new Subject<number>();
  private contract$ = new Subject<Contract>();
  private selectedContractsArr: Contract[] = [];

  constructor(
    private http: UWHttp) {
  }

  get count(): Observable<number> {
    return this.count$.asObservable();
  }

  get contract(): Observable<Contract> {
    return this.contract$.asObservable();
  }

  get selectedContracts(): Contract[] {
    return this.selectedContractsArr;
  }

  resetSelectedContracts() {
    this.selectedContractsArr = [];
    return this.selectedContractsArr;
  }

  isSelected(contractNumber: string) {
    return this.selectedContractsArr.some(contract => contract.contractNumber == contractNumber);
  }

  select(contract: Contract) {
    var foundIndex = this.selectedContractsArr.findIndex((el) => {
      return el.contractNumber === contract.contractNumber;
    });
    if (foundIndex > -1) {
      this.selectedContractsArr.splice(foundIndex, 1);
    } else {
      this.selectedContractsArr.push(contract);
    }
  }

  list(search: string, limit: number, offset: number, orderby: string): Observable<Contract[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('searchvalue', search);
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => res.json() as Paginated<Contract>),
      tap(data => this.count$.next(data.totalCount)),
      map(data => data.items || [])
    );
  }

  find(id: string): Observable<Contract> {
    const MAX_LIMIT = '5000';
    const params = new URLSearchParams();

    params.set('searchvalue', id.split('~')[2]);
    params.set('take', MAX_LIMIT);

    // todo: remove extra call for cashvalue when daily cashvalues is implemented.
    const contractWithCashValue = this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(res => res.json() as Paginated<Contract>),
      mergeMap(data => data.items),
      first(c => c.id === id)
    );

    const contract = this.http.authGet(this.apiUrl + id).pipe(
      map(res => res.json() as Contract)
    );

    // todo: remove when daily cashvalues is implemented.
    return forkJoin(contract, contractWithCashValue).pipe(
      map(contracts => Object.assign({}, contracts[0], contracts[1])),
      tap(data => this.contract$.next(data))
    );
  }

  export(format: any) {
    const options = {
      responseType: ResponseContentType.Blob
    };
    return this.http.authDownload(`${this.apiUrl}export?format=${format}`, `contracts.${format}`, options);
  }
}
