import { Injectable } from '@angular/core';
import { URLSearchParams, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';
import { UWHttp } from '../../UWHttp';
import { LoggingService } from '../../shared/logging/logging.service';
import { Subject } from 'rxjs/Subject';

import { Portfolio, PortfolioResponse } from '../../shared/models/portfolio.model';

@Injectable()
export class ContractPortfolioService {
  private apiUrl = 'contracts/';
  private count$ = new Subject<number>();
  private portfolio$ = new Subject<Portfolio>();

  constructor(
    private http: UWHttp,
    private loggingService: LoggingService
  ) { }

  get count(): Observable<number> {
    return this.count$.asObservable();
  }

  get portfolio(): Observable<Portfolio> {
    return this.portfolio$.asObservable();
  }

  getList(portfolio: Portfolio, limit: number, offset: number, orderby: string): Observable<PortfolioResponse[]> {
    const params = new URLSearchParams();

    if (limit) {
      params.set('take', limit.toString());
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (orderby) {
      params.set('orderby', orderby);
    }

    const contractIdList = portfolio.contracts.map(c => c.id);
    return this.http.authPost(this.apiUrl, contractIdList, { search: params }).pipe(map(res => this.extractsave(res)),
      catchError(this.loggingService.handleError));
  }

  removePortfolio(pf: Portfolio) {
    this.portfolio$.next(pf);
  }

  private extractsave(res: Response): PortfolioResponse[] {
    const body = res.json();
    this.count$.next(body.totalCount);
    return body.items as PortfolioResponse[];
  }
}
