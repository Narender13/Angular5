import { Injectable } from '@angular/core';
import { ResponseContentType, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Subject } from 'rxjs/Subject';
import { share, tap, catchError, map } from 'rxjs/operators';
import { from } from 'rxjs/observable/from';

import { Contract } from '../../shared/models/contract.model';
import { LoggingService } from '../../shared/logging/logging.service';
import { Paginated } from '../../shared/models/paginated.interface';
import { StorageService } from '../../shared/services/storage.service';
import { TenantTranslateService } from '../../shared/services/tenant-translate.service';
import { UserService } from '../../shared/services/user.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ContractRepoService {

  private readonly path = 'contracts/';
  private defaultSort = 'contractNumber';
  private readonly batchSize = 500;
  // one contract is about this big
  // {"id":"7100000017","agentName":"AVERO, HERALDO R","cashValue":172447.54,"contractNumber":"7100000017","contractStatus":"ACTIVE","issueDate":"2011-11-21T00:00:00","issueState":"MO","personName":"HOUSER, DICK","productName":"MNL LiveWell Variable Annuity","qualificationType":"Non-Qualified"}
  // about 300 chars in the above example.
  // So lets be conservative and call the avg 500 chars long.
  // Since localstorage stores strings as utf16 each char takes two bytes.
  // So our average in bytes is 1000 (1 kb).
  // Since chrome has localStorage size set at 5MB (per origin), we could store 5000 contracts
  // if we had all the localStorage reserved for just ContractRepo.
  // lets go with half that for our simpleStorageThreshold.
  private simpleStorageThreshold = 2500;
  private storageKey: string;
  private storageExpiryInHours = .25;
  private contractCollection: Paginated<Contract>;
  private lastCount = new ReplaySubject<number>(1);
  private localCollectionCompleteSub = new ReplaySubject<boolean>();
  private collectionComplete = false;
  private lastContractSub = new Subject<Contract>();

  constructor(
    private userService: UserService,
    private storageService: StorageService,
    private http: UWHttp,
    private loggingService: LoggingService,
    private tenantTranslateService: TenantTranslateService
  ) {
    if (!storageService.localStorageIsAvailable) { return; };
    this.userService.userLoaded()
      .subscribe(user => {
        this.storageKey = `${this.userService.user.profile.tenant_code}${this.userService.user.profile.backend_key}contracts`;
        this.init();
      });
  }

  get count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  get contract(): Observable<Contract> {
    return this.lastContractSub.asObservable();
  }

  get localCollectionComplete(): Observable<boolean> {
    return this.localCollectionCompleteSub.asObservable().pipe(share());
  }

  list(search: string, limit: number, offset: number, orderby: string, contractIdFilter?: Array<string>): Observable<Contract[]> {
    const take = +offset + +limit;
    const baseCollection = contractIdFilter ? this.contractCollection.items.filter(c => contractIdFilter.includes(c.contractNumber)) : this.contractCollection.items;
    // Begin: Comment out this section locally to prevent contract caching(interferes with InMemory for JH)
    if (search && this.collectionComplete) {
      const filterAndSort = this.applyFilter(search, this.appySort(orderby, baseCollection));
      this.lastCount.next(filterAndSort.length);
      return Observable.of(this.applyPage(offset, limit, filterAndSort));
    } else if (!search && (this.collectionComplete || this.defaultSort === orderby)) {
      // check if storage contains what they are looking for
      // is the offset out of range
      if (this.contractCollection && this.contractCollection.totalCount >= take) {
        // does the range actually contain data
        const result = this.applyPage(offset, limit, this.appySort(orderby, baseCollection));
        if (result.every(c => c != null)) {
          console.info(`requested contracts fetched from storage`);
          this.lastCount.next(baseCollection.length);
          return Observable.of(result);
        }
      }
    }
    // End: Comment out this section locally to prevent contract caching (interferes with InMemory for JH)

    // get 'em from the server...
    return this.serverFetch(search, limit, offset, orderby).map(pc => {
      if (!search && this.defaultSort === orderby && !this.collectionComplete) {
        this.buildLocalCollection(pc.items, limit, offset);
      }
      console.info(`requested contracts fetched from server`);
      return pc.items;
    });
  }

  find(id): Observable<Contract> {
    let localCont = this.contractCollection && this.contractCollection.items ? this.contractCollection.items.find(c => c.id === id) : null;
    if (localCont && localCont.maturityDate) {
      console.info(`requested contract detail fetched locally`);
      this.lastContractSub.next(localCont);
      return from([localCont]);
    }
    return this.http.authGet(this.path + id).pipe(
      map(res => {
        const cont = res.json() as Contract;
        if (localCont) {
          Object.assign(localCont, cont);
          // TODO: Maybe persist in local storage?
        } else {
          localCont = cont;
        }
        this.lastContractSub.next(localCont);
        console.info(`requested contract detail fetched from server`);
        return localCont;
      })
    );
  }

  export() {
    const options = {
      responseType: ResponseContentType.Blob
    };

    return this.http.authDownload(`${this.path}export?format=csv`, 'contracts.csv', options);
  }

  private applyFilter(search: string, contracts: Contract[]) {
    return contracts.filter(c => c.contractNumber.includes(search) ||
      (c.personName && c.personName.toLowerCase().includes(search.toLowerCase())));
  }

  private applyPage(offset: number, limit: number, contracts: Contract[]) {
    return contracts.slice(+offset, +offset + +limit);
  }

  private appySort(orderBy: string, contracts: Contract[]) {
    if (!orderBy || orderBy.trim() === '') { return contracts; }
    const sortParts = orderBy.split(' ');
    const field = sortParts[0];
    const desc = sortParts[1] && sortParts[1].toLowerCase().startsWith('desc');

    return (typeof field === 'string' ? this.stringSort(field, contracts, desc) : this.numberSort(field, contracts, desc));
  }

  private stringSort(orderBy: string, contracts: Contract[], desc: boolean = false) {
    return contracts.sort((a, b) => {
      return 0 - (desc ? (b[orderBy] > a[orderBy] ? -1 : 1) : (b[orderBy] < a[orderBy] ? -1 : 1));
    });
  }

  private numberSort(orderBy: string, contracts: Contract[], desc: boolean = false) {
    return contracts.sort((a, b) => {
      return (desc ? b[orderBy] - a[orderBy] : a[orderBy] - b[orderBy]);
    });
  }

  private init() {
    // check for local collection, initialize if not.
    this.contractCollection = this.storageService.get<Paginated<Contract>>(this.storageKey) || { items: [], totalCount: 0 };
    // Now, if the users contract count does not exceed the threshold
    // check to see that we have ALL the contracts locally,
    // and that we don't have a partial collection for whatever reason.
    if (this.contractCollection.totalCount === 0 ||
      (!this.thresholdExceeded && this.contractCollection.items.length !== this.contractCollection.totalCount)) {
      // reset collection array and retry
      this.contractCollection = { items: [], totalCount: 0 };
      this.serverFetch(null, this.batchSize, 0, this.defaultSort)
        .subscribe(pc => {
          if (pc.totalCount === 0) {
            console.info('this user has no book of business.');
            return;
          }
          this.contractCollection.totalCount = pc.totalCount;
          this.buildLocalCollection(pc.items, this.batchSize, 0);

        });

    } else if (this.contractCollection.items.length === this.contractCollection.totalCount) {
      this.collectionComplete = true;
      this.localCollectionCompleteSub.next(true);
      console.info(`local contract collection is complete, it will not be built`);
    }
    this.lastCount.next(this.contractCollection.totalCount);
  }

  private buildLocalCollection(chunk: Contract[], limit: number, offset: number) {
    this.contractCollection.items = [...this.contractCollection.items, ...chunk];
    // If we're not dealing with a huge book of business, keep going if there are more to get
    if (!this.thresholdExceeded && offset + limit < this.contractCollection.totalCount) {
      const newOffset = offset + this.batchSize;
      this.serverFetch(null, limit, newOffset)
        .subscribe(c => {
          this.buildLocalCollection(c.items, limit, newOffset);
        });
    } else {
      try {
        // tslint:disable-next-line:max-line-length
        this.storageService.set(this.storageKey, this.contractCollection, { inSessionStorage: false, expiresInHours: this.storageExpiryInHours });
      } catch (e) {
        if (e.code === 22) {
          // aw crap, storage is full...
          // reduce threshold, reset and retry?
          this.simpleStorageThreshold = this.simpleStorageThreshold / 2;
          this.contractCollection = { items: [], totalCount: 0 };
          this.init();
        }
        throw e;
      }
      // this.lastCount.next(this.contractCollection.items.length);
      if (this.contractCollection.items.length === this.contractCollection.totalCount &&
        this.contractCollection.items.every(c => c != null)) {
        this.collectionComplete = true;
        console.info(`local contract collection complete.`);
      } else {
        this.collectionComplete = false;
        console.info(`local contract collection expanded.`);
      }
    }
  }

  private serverFetch(search: string, limit: number, offset: number, orderby?: string) {
    const params = new URLSearchParams();
    if (search) {
      if (search.match(/\d+/g)) {
        // match string above is to indicate if there is an integer is the search results
        params.set('contractnumber', search);
      } else {
        params.set('personname', search);
      }
    }
    if (orderby) {
      params.set('orderby', orderby);
    }
    params.set('skip', offset.toString());
    params.set('take', limit.toString());
    return this.http.authGetType<Paginated<Contract>>(this.path, { search: params }).pipe(
      tap(pc => this.lastCount.next(pc.totalCount)),
      catchError(this.loggingService.handleError)
    );
  }

  private get thresholdExceeded() {
    return this.contractCollection.totalCount > this.simpleStorageThreshold;
  }
}
