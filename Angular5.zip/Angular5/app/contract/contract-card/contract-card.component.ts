import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { share } from 'rxjs/operators';

import { Contract } from '../../shared/models/contract.model';
import { ContractService } from '../shared/contract.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-contract-card',
  templateUrl: './contract-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ContractCardComponent')
export class ContractCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  contracts: Observable<Contract[]>;
  limit = 5;
  localized: any;
  // hasMany = true;
  sort: string;
  usable: any;

  constructor(
    private service: ContractService
  ) { }

  ngOnInit() {
    this.limit = this.config.cardLimit || this.limit;
    this.sort = this.config.orderby || '';
    this.contracts = this.service.list(null, this.limit, 0, this.sort).pipe(share());
    this.count = this.service.count.pipe(share());
    this.localized = this.config.translated;
    // this.count.subscribe(count => {
    //   this.hasMany = count > 1;
    // });
  }
}
