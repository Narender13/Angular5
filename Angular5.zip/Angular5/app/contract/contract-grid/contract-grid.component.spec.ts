
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { By } from '@angular/platform-browser';
import { Component, DebugElement, Pipe, PipeTransform } from '@angular/core';
import { Routes } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { ContractGridComponent } from './contract-grid.component';

@Component({
  template: ''
})
class DummyComponent {
}

const contractRoutes: Routes = [{
  path: 'contracts/:id',
  component: DummyComponent
},
{
  path: 'contracts',
  component: DummyComponent
}
];

const localeLangStub = {
  'accountNumber': 'Account',
  'ownerName': 'Contract Holder Name'
};

const sampleContracts = [
  {
    'id': 1,
    'contractNumber': '7200000512',
    'accountNumber': '7200000512',
    'productID': 700,
    'ownerName': 'SALTS, DEBRA D',
    'firstName': 'Debra',
    'lastName': 'Salts',
    'taxCategory': '401A',
    'productCode': '557',
    'policyStatus': 'C',
    'isSuspended': '0',
    'productName': 'Industrial Centrifuge Index',
    'accountValue': 308346.69,
    'asOfDate': null,
    'inforceFlag': 'A',
    'planCode': '557',
    'issueState': 'KS',
    'issueDate': null,
    'isMorningStarEnrolled': 'Y',
    'isMorningStarEligible': '',
    'productCategory': 'FIA',
    'sourceSystem': '6',
    'masterNumber': 'MA92311887',
    'qualificationType': 'QUAL',
    'servicingAgent': 'John Jacob',
    'applicationStatus': 'Pending',
    'paymentsExpected': '250000.0',
    'paymentsApplied': '0.0',
    'applicationDateSigned': null,
    'applicationPendingReason': 'NIGO',
    'planID': 0,
    'planNumber': '',
    'status': '',
    'electronicAuthorization': '',
    'contributionType': '',
    'applicationDate': null,
    'contractIssueDate': null,
    'modifiedEndowmentStatus': '',
    'marketSegment': '',
    'productLine': '',
    'productBusinessLine': '',
    'personId': null,
    'createdDate': null,
    'lastUpdatedDate': null,
    'policyNumber': null,
    'watchStatus': null,
    'comissionOption': null,
    'taxCategoryDescription': null,
    'maturityDate': null,
    'nextPayoutDate': null,
    'payoutEndDate': null,
    'payoutCommencementDate': null
  }
  ,
  {
    'id': 2,
    'contractNumber': '7200000512',
    'accountNumber': '7200000512',
    'productID': 700,
    'ownerName': 'SALTS, DEBRA D',
    'firstName': 'Debra',
    'lastName': 'Salts',
    'taxCategory': '401A',
    'productCode': '557',
    'policyStatus': 'C',
    'isSuspended': '0',
    'productName': 'Industrial Centrifuge Index',
    'accountValue': 308346.69,
    'asOfDate': null, 'inforceFlag': 'A', 'planCode': '557', 'issueState': 'KS',
    'issueDate': null, 'isMorningStarEnrolled': 'Y', 'isMorningStarEligible': '', 'productCategory': 'FIA',
    'sourceSystem': '6', 'masterNumber': 'MA92311887', 'qualificationType': 'QUAL', 'servicingAgent': 'John Jacob',
    'applicationStatus': 'Pending', 'paymentsExpected': '250000.0', 'paymentsApplied': '0.0', 'applicationDateSigned': null,
    'applicationPendingReason': 'NIGO', 'planID': 0, 'planNumber': '', 'status': '',
    'electronicAuthorization': '', 'contributionType': '', 'applicationDate': null, 'contractIssueDate': null,
    'modifiedEndowmentStatus': '', 'marketSegment': '', 'productLine': '', 'productBusinessLine': '',
    'personId': null, 'createdDate': null, 'lastUpdatedDate': null, 'policyNumber': null,
    'watchStatus': null, 'comissionOption': null, 'taxCategoryDescription': null, 'maturityDate': null,
    'nextPayoutDate': null, 'payoutEndDate': null, 'payoutCommencementDate': null
  }
];

describe('ContractGridComponent', () => {
  let component: ContractGridComponent;
  let fixture: ComponentFixture<ContractGridComponent>;
  const contractService = {
    contracts: sampleContracts
  };

  beforeEach(async(() => {

    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(contractRoutes)],
      declarations: [
        ContractGridComponent,
        MockPipe,
        DummyComponent
      ],
      providers: [{ provide: Pipe, useValue: mockPipe }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractGridComponent);
    component = fixture.componentInstance;
    component.contracts = contractService.contracts;

    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should find rows', () => {
    const len = sampleContracts.length;
    let de: DebugElement;
    de = fixture.debugElement;
    expect(de.queryAll(By.css('tr')).length).toBe(len + 1);
  });

});
