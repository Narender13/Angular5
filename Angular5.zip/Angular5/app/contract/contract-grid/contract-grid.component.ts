import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { Contract } from '../../shared/models/contract.model';
import { ContractService } from '../shared/contract.service';
import { ToolbarActionHandlers, ToolbarActionable } from 'app/shared/services/toolbar-action-handler';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-contract-grid',
  templateUrl: './contract-grid.component.html',
  styleUrls: []
})
@AutoUnsubscribe()
@Configure('ContractGridComponent')
export class ContractGridComponent implements Configurable, OnInit, ToolbarActionable {
  config: any;
  usable: boolean;
  contracts: Observable<Contract[]>;
  count: Observable<number>;
  loading = true;
  sortFields: any[] = [
    'contractNumber Asc',
    'contractNumber Desc',
    'personName Asc',
    'personName Desc',
    'cashValue Asc',
    'cashValue Desc'
  ];
  tools = ['print', 'excel', 'pdf'];
  activeTool: string;
  isAgent = false;
  localized: any;
  params: any;

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    public service: ContractService,
    private userService: UserService
  ) { }

  ngOnInit() {
    if (this.userService.isInRole('agent')) {
      this.isAgent = true;
    }
    this.service.resetSelectedContracts();
    this.count = this.service.count.pipe(share());
    this.contracts = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { q: string, limit: number, offset: number, orderby: string }) => {
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        this.config.orderby = params.orderby || this.config.orderby || this.sortFields[0];

        return this.service.list(params.q, this.config.limit, this.config.offset, this.config.orderby);
      }),
      tap(_ => this.loading = false),
      share()
    );

    this.localized = this.config.translated;
    ToolbarActionHandlers.handle(this);
  }

  onExport(format: string): Observable<any> {
    return this.service.export(format);
  }

  isSelected(contractNumber) {
    return this.service.isSelected(contractNumber);
  }

  selectContract(contract: Contract) {
    this.service.select(contract);
  }
}
