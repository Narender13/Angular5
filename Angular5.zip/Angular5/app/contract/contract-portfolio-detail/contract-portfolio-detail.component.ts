import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, tap, switchMap } from 'rxjs/operators';
import { UserService } from '../../shared/services/user.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { ContractPortfolioService } from '../shared/contract-portfolio.service';
import { ContractService } from '../shared/contract.service';

import { Portfolio, PortfolioResponse } from '../../shared/models/portfolio.model';
import { Contract } from '../../shared/models/contract.model';
import { Configure } from '../../shared/decorators/configurable';

@AutoUnsubscribe()
@Configure('ContractPortfolioDetailComponent')
@Component({
  selector: 'app-contract-portfolio-detail',
  templateUrl: './contract-portfolio-detail.component.html',
  styles: []
})
export class ContractPortfolioDetailComponent implements OnInit {
  config: any;
  portfolio: Portfolio;
  contracts: Observable<PortfolioResponse[]>;
  count: Observable<number>;
  loading = true;

  constructor(
    private service: ContractPortfolioService,
    private contractService: ContractService,
    public route: ActivatedRoute,
    public router: Router,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.contractService.resetSelectedContracts();
    this.count = this.service.count.pipe(share());
    this.contracts = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { portfolioName: string, limit: number, offset: number, orderby: string }) => {
        console.log(params);
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        this.config.orderby = params.orderby || this.config.orderby;

        const portfolios = (this.userService.userPreferences.get('portfolio') as Array<Portfolio>);
        this.portfolio = portfolios.find(p => p.name === params.portfolioName);

        return this.service.getList(this.portfolio, this.config.limit, this.config.offset, this.config.orderby);
      }),
      tap(() => this.loading = false)
    );

    // subscribe to contract removals and refresh list
    this.service.portfolio.pipe(
      tap(() => this.loading = true),
      switchMap((name) => {
        // if offset is greater than new contract length, it returns empty array, so resetting offset
        if (this.config.offset > this.portfolio.contracts.length) {
          // lengthy way of finding the next lowest offset. I could be bad at math
          // if 20 offset and 15 contracts (aka 6 or more were removed)
          // 20 - 15 = 5 % 10 = 5 + 15 = 20 - 10 = 10 offset
          // another example 30 offset - 9 contracts = 21 % 10 = 1 + 9 = 10 - 10 = 0 offset
          this.config.offset = ((this.config.offset - this.portfolio.contracts.length) % 10) + this.portfolio.contracts.length - 10;
        }
        this.contracts = this.service.getList(name, this.config.limit, this.config.offset, this.config.orderby).share();
        return this.contracts;
      }),
      tap(() => this.loading = false)
    ).subscribe();
  }

  isSelected(contractNumber) {
    return this.contractService.isSelected(contractNumber);
  }

  selectContract(contract: Contract) {
    this.contractService.select(contract);
  }
}
