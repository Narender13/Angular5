import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AuthGuardService } from '../../shared/services/auth-guard.service';
import { ContractActivity } from '../../shared/models/contract-activity.model';
import { ContractActivityService } from '../shared/contract-activity.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-contract-activity-card',
  templateUrl: './contract-activity-card.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ContractActivityCardComponent')
export class ContractActivityCardComponent implements OnInit {
  activity: Observable<ContractActivity[]>;
  config: any;
  count: Observable<number>;
  limit: number;
  usable: any;

  constructor(
    private service: ContractActivityService,
    private guardService: AuthGuardService) { }

  ngOnInit() {
    this.limit = this.config.cardLimit || this.limit;
    this.activity = this.service.list(null, this.limit, 0, this.config.orderby).pipe(share());
    this.count = this.service.count().pipe(share());

  }
}
