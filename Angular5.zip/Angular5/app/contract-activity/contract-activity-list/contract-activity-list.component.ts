import { Component, OnInit, Input } from '@angular/core';
import { ContractActivity } from '../../shared/models/contract-activity.model';

@Component({
  selector: 'app-contract-activity-list',
  templateUrl: './contract-activity-list.component.html',
  styles: []
})
export class ContractActivityListComponent {
  @Input() activity: ContractActivity[];

  constructor() { }
}
