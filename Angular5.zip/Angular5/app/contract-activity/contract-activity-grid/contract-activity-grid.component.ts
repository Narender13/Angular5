import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { ContractActivity } from '../../shared/models/contract-activity.model';
import { ContractActivityService } from '../shared/contract-activity.service';
import { ToolbarActionHandlers, ToolbarActionable } from '../../shared/services/toolbar-action-handler';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';

@Component({
  selector: 'app-contract-activity-grid',
  templateUrl: './contract-activity-grid.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ContractActivityGridComponent')
export class ContractActivityGridComponent implements Configurable, OnInit, ToolbarActionable {
  activeTool: string;
  config: any;
  count: Observable<number>;
  list: Observable<ContractActivity[]>;
  loading = true;
  sortFields: string[] = [
    'contractNumber Asc',
    'contractNumber Desc',
    'personName Asc',
    'personName Desc',
    'transactionDate Asc',
    'transactionDate Desc',
    'grossAmount Asc',
    'grossAmount Desc'
  ];
  tools = ['print', 'export'];

  constructor(
    public route: ActivatedRoute,
    public router: Router,
    private service: ContractActivityService
  ) { }

  ngOnInit() {
    this.count = this.service.count().pipe(share());
    this.list = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { q: string, limit: number, offset: number, orderby: string }) => {
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        this.config.orderby = params.orderby || this.config.orderby;
        return this.service.list(params.q, this.config.limit, this.config.offset, this.config.orderby);
      }),
      tap(() => this.loading = false),
      share());

    ToolbarActionHandlers.handle(this);
  }

  onExport(): Observable<any> {
    return this.service.export();
  }
}
