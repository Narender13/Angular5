import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ContractActivityRoutingModule } from './contract-activity-routing.module';
import { ContractActivityService } from './shared/contract-activity.service';
import { SharedModule } from '../shared/shared.module';
import { ContractActivityCardComponent } from './contract-activity-card/contract-activity-card.component';
import { ContractActivityChipComponent } from './contract-activity-chip/contract-activity-chip.component';
import { ContractActivityListComponent } from './contract-activity-list/contract-activity-list.component';
import { ContractActivityGridComponent } from './contract-activity-grid/contract-activity-grid.component';

@NgModule({
  declarations: [
    ContractActivityGridComponent,
    ContractActivityCardComponent,
    ContractActivityChipComponent,
    ContractActivityListComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ContractActivityRoutingModule
  ],
  exports: [ContractActivityCardComponent],
  providers: [ContractActivityService]
})
export class ContractActivityModule { }
