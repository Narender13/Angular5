import { Component, OnInit, Input } from '@angular/core';
import { ContractActivity } from '../../shared/models/contract-activity.model';

@Component({
  selector: 'app-contract-activity-chip',
  templateUrl: './contract-activity-chip.component.html',
  styles: [':host{width:100%;}']
})
export class ContractActivityChipComponent implements OnInit {

  @Input() activity: ContractActivity;
  constructor() { }

  ngOnInit() {
  }

}
