import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { ContractActivityGridComponent } from './contract-activity-grid/contract-activity-grid.component';

const routes: Routes = [{
  path: 'contract-activity/action/:action',
  component: ContractActivityGridComponent,
  canActivate: [AuthGuardService]
}, {
  path: 'contract-activity',
  component: ContractActivityGridComponent,
  canActivate: [AuthGuardService]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContractActivityRoutingModule { }
