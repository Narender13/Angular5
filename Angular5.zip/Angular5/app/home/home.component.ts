import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { ComponentConfigService } from '../shared/services/component-config.service';
import { UserService } from '../shared/services/user.service';
import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../shared/decorators/configurable';

@Component({
  templateUrl: './home.component.html',
  styleUrls: []
})
@AutoUnsubscribe()
@Configure('HomeComponent')
export class HomeComponent implements Configurable, OnInit {
  user: any;
  identityHost: string;
  tenantCode: string;
  currentHost: string;
  config: any;
  tenantName: string;
  usable: boolean;

  constructor(
    public userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private componentConfigService: ComponentConfigService
  ) { }

  ngOnInit() {
    this.identityHost = this.componentConfigService.globals.get('identityHost');
    this.tenantName = this.componentConfigService.globals.get('tenantName');
    this.tenantCode = this.componentConfigService.globals.get('tenantCode');
    this.currentHost = this.componentConfigService.globals.get('hostName');
    this.user = this.userService.user;
    this.userService.userLoaded()
      .subscribe(user => {
        this.user = user;
        // There must be a more elegant way...
        this.router.navigate(['home']);
      });
  }
}
