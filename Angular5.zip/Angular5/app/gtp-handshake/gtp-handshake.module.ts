import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { GTPHandshakeComponent } from './gtp-handshake.component';
import { GTPHandshakeRoutingModule } from './gtp-handshake-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    GTPHandshakeRoutingModule,
    SharedModule
  ],
  declarations: [GTPHandshakeComponent]
})
export class GTPHandshakeModule { }
