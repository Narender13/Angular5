import { ActivatedRoute, Router } from '@angular/router';
import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { Component, OnInit } from '@angular/core';
import { Configure, Configurable } from '../shared/decorators/configurable';
import { environment } from '../../environments/environment';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-gtp-handshake',
  templateUrl: './gtp-handshake.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('GTPHandshakeComponent')
export class GTPHandshakeComponent implements Configurable, OnInit {
  config: any;
  firstSubmitClick = false;
  handshakeUrl: string;
  idsEnvironment: string;
  localized: any;
  usable: boolean;
  userAccessKey: string;
  userLogoutKey: string;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.handshakeUrl = environment.gtpHandshake.url + 'Home/FromUnifiedWeb';
    this.idsEnvironment = environment.gtpHandshake.idsEnvironment;
    this.localized = this.config.translated;
    this.userAccessKey = this.userService.user.access_token;
    this.userLogoutKey = this.userService.user.id_token;
  }

  disableSubmitButton() {
    this.firstSubmitClick = true;
  }
}
