import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from '../shared/services/auth-guard.service';
import { GTPHandshakeComponent } from './gtp-handshake.component';

const routes: Routes = [
  { path: 'gtp-handshake', component: GTPHandshakeComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GTPHandshakeRoutingModule { }
