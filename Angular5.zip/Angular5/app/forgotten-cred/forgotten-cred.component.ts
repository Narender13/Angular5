import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { ComponentConfigService } from '../shared/services/component-config.service';
import { Router, ActivatedRoute } from '@angular/router';
// import { SendCodeService } from './shared/send-code.service';
import { userNameValidator } from '../register/shared/user-name.validator';

@Component({
  templateUrl: './forgotten-cred.html',
  styleUrls: ['./forgotten-cred.component.scss']

})
export class ForgottenCredComponent implements OnInit {
  currentHost: string;
  tenantCode: string;
  identityHost: string;
  forgottenCredForm: FormGroup;
  tenantName: string;
  private unType = { 'val': null };  // object so it can be passed by ref

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private componentConfigService: ComponentConfigService) { }

  ngOnInit() {
    console.info('Initing forgotten-cred.component.');
    this.identityHost = this.componentConfigService.globals.get('identityHost');
    this.tenantName = this.componentConfigService.globals.get('tenantName');
    this.tenantCode = this.componentConfigService.globals.get('tenantCode');
    this.currentHost = this.componentConfigService.globals.get('hostName');
    this.route.queryParams.subscribe((params: { type: string }) => {
      if (params.type !== undefined) {
        console.info('type=' + params.type);
      } else {
        this.router.navigate(['/login']);
      }
    });
    this.createForm();
  }

  createForm() {
    this.forgottenCredForm = this.fb.group({
      userName: ['',
        [
          Validators.required,
          userNameValidator(this.unType)
        ]
      ]
    });

    this.forgottenCredForm.reset();
  }

  // send(identifier: string, identifierType: string) {
  //   this.sendCodeService.send(identifier, identifierType)
  //     .subscribe((u) => {
  //       console.debug('response received from sendCodeService.reset()');
  //     });
  // }
}