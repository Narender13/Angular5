import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

// import { SendCodeService } from './shared/send-code.service';
import { ForgottenCredRoutingModule } from './forgotten-cred-routing.module';
import { ForgottenCredComponent } from './forgotten-cred.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [ForgottenCredComponent],
  imports: [CommonModule, SharedModule, ReactiveFormsModule, ForgottenCredRoutingModule],
  exports: [ForgottenCredComponent],
  // providers: [SendCodeService]
})
export class ForgottenCredModule { }
