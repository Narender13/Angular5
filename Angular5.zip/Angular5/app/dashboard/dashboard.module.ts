import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { ContractOwnerModule } from '../contract-owner/contract-owner.module';
import { ContractActivityModule } from '../contract-activity/contract-activity.module';
import { ContractAssetModule } from '../contract-asset/contract-asset.module';
import { ContractModule } from '../contract/contract.module';
import { DocumentModule } from '../document/document.module';
import { PurchaseModule } from '../purchase/purchase.module';
import { DashboardComponent } from './dashboard.component';
import { MessageModule } from '../message/message.module';
import { PendingNewBusinessModule } from '../pending-new-business/pending-new-business.module';
import { PricesModule } from '../prices/prices.module';
import { ProductAssetModule } from '../product-asset/product-asset.module';
import { SharedModule } from '../shared/shared.module';
import { SurrenderModule } from '../surrender/surrender.module';
import { TerminatedContractModule } from '../terminated-contract/terminated-contract.module';
import { WelcomeSlidesModule } from '../welcome-slides/welcome-slides.module';

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    ContractOwnerModule,
    ContractActivityModule,
    ContractAssetModule,
    CommonModule,
    ContractModule,
    DocumentModule,
    MessageModule,
    PendingNewBusinessModule,
    PricesModule,
    ProductAssetModule,
    PurchaseModule,
    ReactiveFormsModule,
    SharedModule,
    SurrenderModule,
    TerminatedContractModule,
    WelcomeSlidesModule
  ],
  exports: [DashboardComponent]
})
export class DashboardModule { }
