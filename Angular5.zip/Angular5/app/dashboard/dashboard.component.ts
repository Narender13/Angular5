import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

import { UserService } from '../shared/services/user.service';
import { StorageService } from '../shared/services/storage.service';
import { AuthGuardService } from 'app/shared/services/auth-guard.service';
import { Configurable, Configure } from '../shared/decorators/configurable';
import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { ComponentConfigService } from '../shared/services/component-config.service';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
@AutoUnsubscribe()
@Configure('DashboardComponent')
export class DashboardComponent implements Configurable, OnInit {
  form: FormGroup;
  title = 'Agent Summary';
  config: any;
  pinable: string[] = [];
  usable: boolean;

  get pinableOptions() {
    return this.form.get('pinableOptions') as FormArray;
  }

  get pinnedOptions() {
    return this.form.get('pinnedOptions') as FormArray;
  }

  constructor(
    private componentConfigService: ComponentConfigService,
    private userService: UserService,
    private storageService: StorageService,
    private router: Router,
    private fb: FormBuilder,
    private authGuard: AuthGuardService
  ) { }

  ngOnInit() {
    this.buildForm();

    if (this.showWelcomeScreen() && !this.alreadyShownInThisSession() && this.componentConfigService.components.has('WelcomeSlidesComponent')) {
      this.router.navigate([`/welcome`]);
    }
  }

  buildForm() {
    // sort in display order for proper order in the customize menu
    this.config.pinned2 = this.config.pinned2.sort((a, b) => a.displayOrder - b.displayOrder);
    this.form = this.fb.group({
      pinableOptions: this.buildPinableOptions(),
      pinnedOptions: this.buildPinnedOptions()
    });
    this.form.valueChanges.pipe(
      debounceTime(500)
    ).subscribe((data) => this.dashboardOptionsChanged(data));
  }

  buildPinableOptions() {
    this.pinable = [];
    this.componentConfigService.components.forEach((v, k) => {
      if (v.pinable && this.authGuard.canUse(v) && !(this.config.pinned2 as any[]).some(p => p.componentName == k)) {
        this.pinable.push(k);
      }
    });
    const pinableControls = this.pinable.map(s => this.fb.control(false));
    return this.fb.array(pinableControls);
  }

  buildPinnedOptions() {
    const pinnedControls = this.config.pinned2.map(c => this.fb.control(true));
    return this.fb.array(pinnedControls);
  }

  isPinned(componentName: string): boolean {
    const pinned = this.config.pinned2 as any[];
    return pinned.some(c => c.componentName == componentName);
  }

  displayOrder(componentName: string): number {
    const pinned = this.config.pinned2 as any[];
    const pinnedComp = pinned.find(c => c.componentName == componentName);
    return pinnedComp ? pinnedComp.displayOrder : 0;
  }

  colSpan(componentName: string): number {
    const pinned = this.config.pinned2 as any[];
    const pinnedComp = pinned.find(c => c.componentName == componentName);
    return pinnedComp ? pinnedComp.cols : 1;
  }

  dashboardOptionsChanged(data) {
    const pinableOptions = data.pinableOptions as boolean[];
    const pinnedOptions = data.pinnedOptions as boolean[];

    pinableOptions.forEach((p, idx) => {
      // if its checked add it to the config.pinned collection
      if (p) {
        // Add the component the user selected to the pinned collection
        // with displayOrder=1 and cols=1.
        // In preperation for the newly selected component getting displayOrder=1
        // increment all existing components displayOrder.
        (this.config.pinned2 as any[]).forEach(comp => {
          comp.displayOrder = comp.displayOrder + 1;
        });
        const nameOfNewlySelected = this.pinable[idx];
        this.config.pinned2.push({ componentName: nameOfNewlySelected, displayOrder: 1, cols: 1 });
      }
    });

    pinnedOptions.forEach((p, idx) => {
      // if it is unchecked remove it from config.pinned
      if (!p) {
        (this.config.pinned2 as any[]).splice(idx, 1);
        // fix displayOrders
        (this.config.pinned2 as any[]).forEach(comp => {
          if (comp.displayOrder > idx + 1) {
            comp.displayOrder = comp.displayOrder - 1;
          }
        });
      }
    });
    // this will re-swizzle the dropdown form
    this.buildForm();
    this.userService.setPreference({ DashboardComponent: { pinned2: this.config.pinned2 } }).subscribe();
  }

  alreadyShownInThisSession() {
    return this.storageService.get<boolean>('shownThisSession');
  }

  showWelcomeScreen() {
    return this.userService.userPreferences.has('WelcomeComponent') ?
      this.userService.userPreferences.get('WelcomeComponent').showMeAgain : true;
  }

  // only implemented to handle offset of -1,0,1 (-1 means move up, 1 means move down, 0 means don't move)
  setOrder($event: MouseEvent, componentName: string, offset: number) {
    $event.stopPropagation();
    const comp = this.config.pinned2.find(c => c.componentName == componentName);
    console.info(`${comp.componentName} changing display order to ${offset}`);
    if (comp) {
      const ctrls = this.pinnedOptions.controls;

      if (offset < 0) { // move up
        // get the comp before and move it down
        const compBefore = this.config.pinned2.find(c => c.displayOrder == comp.displayOrder - 1);
        compBefore.displayOrder = compBefore.displayOrder - offset;
      } else if (offset > 0) { // move down
        // get the comp after and move it up
        const compAfter = this.config.pinned2.find(c => c.displayOrder == comp.displayOrder + 1);
        compAfter.displayOrder = compAfter.displayOrder - offset;
      }
      // move the component
      comp.displayOrder = comp.displayOrder + offset;

      // this.buildForm() will cause the pinned2 collection to be sorted in display order
      // we then save the prefs so pinned2 will be saved in sorted order.
      // if we save prefs before sorting then the pinned2 will be saved before re-sort
      // then this.buildForm() will sort the collection, then config.service will detect
      // user prefs have changed (as a result of being saved) and reset the this.config.pinned2
      // to what was saved undoing any sort that was performed after the save.
      this.buildForm();
      // save user prefs
      console.info('saving pinned2', this.config.pinned2);
      this.userService.setPreference({ DashboardComponent: { pinned2: this.config.pinned2 } });
    }
  }
}
