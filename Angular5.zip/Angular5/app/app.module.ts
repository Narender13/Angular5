import { AliasService } from './shared/services/alias.service';
import { APP_INITIALIZER, Injectable, NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthGuardService } from './shared/services/auth-guard.service';
import { BrowserModule, Title } from '@angular/platform-browser';
import { BusyService } from './shared/services/busy.service';
import { ConfigService } from './shared/services/config.service';
import { FeedbackModule } from './feedback/feedback.module';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { LayoutModule } from './layout/layout.module';
import { LocationStrategy, PathLocationStrategy } from '@angular/common';
import { LoginModule } from './login/login.module';
import { NgIdleModule } from '@ng-idle/core';
import { RegisterModule } from './register/register.module';
import { SendCodeModule } from './send-code/send-code.module';
import { SessionTimeoutService } from './shared/services/sessionTimeout.service';
import { SharedModule } from './shared/shared.module';
import { StorageService } from './shared/services/storage.service';
import { TranslateModule, TranslateLoader, MissingTranslationHandler } from '@ngx-translate/core';
import { HttpLoaderFactory, UWMissingTranslationHandler, TenantTranslateService } from './shared/services/tenant-translate.service';
import { UserAccountModule } from './user-account/user-account.module';
import { UserService } from './shared/services/user.service';
import { UWHttp } from './UWHttp';
import { VerifyCodeModule } from './verify-code/verify-code.module';
import { WebApiService } from './web-api.service';
import { WildcardRoutingModule } from './wildcard-routing.module';
import { XHRBackend, RequestOptions } from '@angular/http';
import { InjectorModule } from './shared/injector.module';
import { ReportBuilderModule } from './report-builder/report-builder.module';

@Injectable()
export class ConfigLoader {
  constructor(private service: ConfigService, private userService: UserService) { }

  load(): Promise<any> {
    return this.service.discover().then((disco) => this.userService.init());
  }
}
// tslint:disable-next-line:only-arrow-functions
export function initConfig(loader: ConfigLoader): Function {
  return () => loader.load();
}

// tslint:disable-next-line:only-arrow-functions
export function UWHttpFactory(
  backend: XHRBackend,
  defaultOptions: RequestOptions,
  configService: ConfigService,
  userService: UserService,
  busyService: BusyService) {
  return new UWHttp(backend, defaultOptions, configService, userService, busyService);
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    FeedbackModule,
    LayoutModule,
    LoginModule,
    NgIdleModule.forRoot(),
    RegisterModule,
    SharedModule,
    InjectorModule,
    UserAccountModule,
    SendCodeModule,
    ReportBuilderModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      },
      missingTranslationHandler: { provide: MissingTranslationHandler, useClass: UWMissingTranslationHandler }
    }),
    VerifyCodeModule,
    WildcardRoutingModule, // Must be after all modules that have "forChild" routes
    // order matters here, InMemoryWebApiModule must be last so that it can override Http
    InMemoryWebApiModule.forRoot(WebApiService, { passThruUnknownUrl: true })
  ],
  providers: [
    AuthGuardService,
    BusyService,
    ConfigLoader,
    ConfigService,
    Title,
    SessionTimeoutService,
    StorageService,
    AliasService,
    TenantTranslateService,
    UserService,
    {
      provide: APP_INITIALIZER,
      useFactory: initConfig,
      deps: [ConfigLoader],
      multi: true
    },
    {
      provide: UWHttp,
      useFactory: UWHttpFactory,
      deps: [XHRBackend, RequestOptions, ConfigService, UserService, BusyService]
    },
    {
      provide: LocationStrategy,
      useClass: PathLocationStrategy
    }
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
