import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { debounceTime, filter, switchMap } from 'rxjs/operators';

import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { ComponentConfigService } from '../shared/services/component-config.service';
import { Configurable, Configure } from '../shared/decorators/configurable';
import { DateValidator } from './shared/date.validator';
import { matchingFieldsValidator } from './shared/matching-field-values.validator';
import { PasswordValidator } from './password-validator';
import { regexMatchValidator } from './shared/regex-match.validator';
import { regexValidator } from './shared/regex.validator';
import { RegisterService } from './shared/register.service';
import { UserService } from '../shared/services/user.service';

@Component({
  templateUrl: './register.html',
  styleUrls: ['./register.component.scss']
})
@AutoUnsubscribe()
@Configure('RegisterComponent')
export class RegisterComponent implements Configurable, OnInit {
  config: any;
  registerForm: FormGroup;
  unType = { 'val': 'email' };  // object so it can be passed by ref
  currentHost: string;
  personNotFound = true;
  personFindAttempted = false;
  tenantCode: string;
  identityHost: string;
  busy = false;
  siteKey: string;
  recaptchaSatisfied = false;
  private passwordValidator = new PasswordValidator();
  private recaptchaResponse: string;

  constructor(
    private componentConfigService: ComponentConfigService,
    private fb: FormBuilder,
    private router: Router,
    private registerService: RegisterService,
    private userService: UserService
  ) {
  }

  ngOnInit() {
    this.identityHost = this.componentConfigService.globals.get('identityHost');
    this.tenantCode = this.componentConfigService.globals.get('tenantCode');
    this.currentHost = this.componentConfigService.globals.get('hostName');
    this.siteKey = this.componentConfigService.globals.get('recaptchaKey');
    this.createForm();
  }

  createForm() {
    this.registerForm = this.fb.group({
      userType: ['consumer', Validators.required],
      phoneNumberConfirm: ['',
        [
          // Validators.required,
          Validators.minLength(6)
        ]
      ],
      user: this.fb.group({
        userName: ['',
          [
            Validators.required,
            regexValidator(/(^.+@.+\..+$)|^$/, 'userName', 'Must be a valid email address.')
          ]
        ],
        confirmUserName: ['', Validators.required],
        email: ['',
          []
        ],
        firstName: ['',
          [
            Validators.required,
            Validators.minLength(2)
          ]
        ],
        lastName: ['',
          [
            Validators.required,
            Validators.minLength(2)
          ]
        ],
        dob: ['', [Validators.required, DateValidator(1900, 2010, 'dob', 'invalid date')]],
        backendKey: 'test',
        last4: ['',
          [
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(4),
            Validators.pattern(/^[0-9]+$/)
          ]
        ]
      }, {
          validator: matchingFieldsValidator('userName', 'confirmUserName', 'userNamesMatch', 'User name and Confirm user name must match.')
        }),
      pw: this.fb.group({
        password: ['',
          [
            Validators.required,
            Validators.minLength(this.passwordValidator.minLength.value),
            Validators.maxLength(this.passwordValidator.maxLength.value),
            regexValidator(this.passwordValidator.hasLowerCase.regEx,
              'passwordHasLowerCase', this.passwordValidator.hasLowerCase.description),
            regexValidator(this.passwordValidator.hasUpperCase.regEx,
              'passwordHasUpperCase', this.passwordValidator.hasUpperCase.description),
            regexValidator(this.passwordValidator.hasNumber.regEx,
              'passwordHasNumber', this.passwordValidator.hasNumber.description),
            regexValidator(this.passwordValidator.hasNonAlpha.regEx,
              'passwordHasNonAlpha', this.passwordValidator.hasNonAlpha.description),
            regexMatchValidator(this.passwordValidator.invalidChars.regEx,
              'passwordInvalidChars', this.passwordValidator.invalidChars.description)
          ]
        ],
        confirmPassword: ['',
          [
            Validators.required
          ]
        ],
      }, {
          validator: matchingFieldsValidator('password', 'confirmPassword', 'passwordsMatch', 'Password and Confirm Password must match.')
        })
    });

    this.last4Field.valueChanges.pipe(
      filter(val => val.length === 4),
      debounceTime(300)
    ).subscribe(val => this.personFindAttempted = false);

    this.dobField.valueChanges.pipe(
      debounceTime(300)
    ).subscribe(val => this.personFindAttempted = false);

    this.lastNameField.valueChanges.pipe(
      debounceTime(300)
    ).subscribe(val => this.personFindAttempted = false);

    this.userNameField.valueChanges.pipe(
      filter(val => {
        return this.userNameField.valid;
      }),
      debounceTime(1000),
      switchMap(val => {
        this.busy = true;
        return this.registerService.dupCheck(val, null, val);
      })
    ).subscribe(dups => {
      this.onDupCheck(this.userNameField, dups);
      this.busy = false;
    });

    const phoneNumberConfirmField = this.registerForm.get('phoneNumberConfirm');
    phoneNumberConfirmField.valueChanges.pipe(
      filter(val => val.length > 5),
      debounceTime(300)
    ).subscribe(res => this.onValidatePhoneNumberCode(res, phoneNumberConfirmField));
  }

  get last4Field() {
    return this.registerForm.get('user.last4')
  }
  get dobField() {
    return this.registerForm.get('user.dob');
  }
  get lastNameField() {
    return this.registerForm.get('user.lastName');
  }
  get confirmUserNameField() {
    return this.registerForm.get('user.confirmUserName');
  }
  get phoneField() {
    return this.registerForm.get('user.phoneNumber');
  }
  get userNameField() {
    return this.registerForm.get('user.userName');
  }

  personLookup(last4: string, dob: string, lastName: string) {
    this.busy = true;
    // Right now in IE and Chrome parameter dob that is passed in from the UI
    // does not contain any time information (assuming no molestation).
    // 1. Mulesoft requires the date to be in ISO format (yyyy-mm-dd) with or without the time part.
    // 2. If we provide the time part and provide anything other than "T00:00:00Z" we run the risk of making the birthdate
    //    match in mulesoft fail.
    // 3. So we will NOT provide the time part (since it is not required) and therefore not run the risk of F'ing up.
    // 4. Because IE 11 and lower don't know what an <input type="date" is and therefore the dob string could be anything.
    //    In the case of IE 11 the DateValidator attached to the form field ensures
    //    proper formatting (mm/dd/yyyy) and the new Date(dob) below is used to coalesce the two
    //    different formats (mm/dd/yyyy when the <input type="date" acts as type="text" (the IE case) and yyyy-mm-dd
    //    when <input type="date" acts as it should (the Chrome case))
    // 5. In doing the new Date(dob) bit we've introduced a time part... %$#@&!!!
    //    Here's where it is REALLY AWESOME, IE javascript engine sets the time offset using local time
    //    so it's "...T06:00:00" (CST, for me), BUT Chrome doesn't!!!! (leaves it as "T00:00:00")
    // 6. Get rid of the time part, and move back to safety.
    const bdate = new Date(dob);
    const yearStr = bdate.getUTCFullYear().toString();
    const monthStr = ('0' + (bdate.getUTCMonth() + 1).toString()).slice(-2);
    const dateStr = ('0' + (bdate.getUTCDate()).toString()).slice(-2);
    const dateStringWithoutTime = `${yearStr}-${monthStr}-${dateStr}`;
    this.registerService.lookupBackendKey(lastName, last4, dateStringWithoutTime, this.recaptchaResponse)
      .subscribe(person => {
        this.personNotFound = true;
        this.personFindAttempted = true;
        if (person && person.length > 0) {
          const ppl = person
            .filter((p) => {
              const personDob = Date.parse(p.dateOfBirth); // from mulesoft this date will have timepart like 'T00:00:00' notice no 'Z' on the end
              const searchDob = Date.parse(dateStringWithoutTime + 'T00:00:00'); // ...so no 'Z' here either
              return p.taxIdLast4 === last4 &&
                p.lastName.toLowerCase() === lastName.toLowerCase() &&
                searchDob === personDob;
            });
          if (ppl) {
            // found at least one match!
            // We'll assume agent is preferred for now...
            // check for consumer
            const consumer = ppl.find(p => p.role.toLowerCase() === 'prim owner' && p.roleStatus.toLowerCase() === 'active');
            if (consumer) {
              this.personNotFound = false;
              this.registerForm.get('user.backendKey').setValue(consumer.taxId, { emitEvent: false });
              this.registerForm.get('user.firstName').setValue(consumer.firstName, { emitEvent: false });
              this.registerForm.get('userType').setValue('consumer', { emitEvent: false });
            }
            // check for agent
            const agent = ppl.find(p => p.role.toLowerCase() === 'serv rep' && p.roleStatus.toLowerCase() === 'active');
            if (agent) {
              this.personNotFound = false;
              this.registerForm.get('user.backendKey').setValue(agent.masterAgentNumber, { emitEvent: false });
              this.registerForm.get('user.firstName').setValue(agent.firstName, { emitEvent: false });
              this.registerForm.get('userType').setValue('agent', { emitEvent: false });
            }
          }
        }
        this.busy = false;
      });
  }

  public resolved(captchaResponse: string) {
    this.recaptchaSatisfied = true;
    this.recaptchaResponse = captchaResponse;
  }

  onDupCheck(userNameField: AbstractControl, dups: string[]) {
    const errs = userNameField.errors;
    if (errs && errs['userNameExists']) delete errs['userNameExists'];
    if (errs && errs['emailExists']) delete errs['emailExists'];

    if (dups.find(s => s.toLowerCase() === 'username')) {
      userNameField.setErrors({ 'userNameExists': 'A user with this user name already exists.' });
    }
    if (dups.find(s => s.toLowerCase() === 'email')) {
      userNameField.setErrors({ 'emailExists': 'A user with this email already exists.' });
    }

    this.registerForm.get('user.email').setValue(this.registerForm.get('user.userName').value, { emitEvent: false });
  }

  onValidatePhoneNumberCode(isValid: boolean, phoneConfirmField: AbstractControl) {
    console.info('onValidatePhoneNumberCode: isValid: ' + isValid);
    if (!isValid) {
      phoneConfirmField.setErrors({ 'badCode': 'Invalid code.' });
    }
  }
}