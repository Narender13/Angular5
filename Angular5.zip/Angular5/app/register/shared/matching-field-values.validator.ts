import { FormGroup } from '@angular/forms';

// tslint:disable-next-line:only-arrow-functions
export function matchingFieldsValidator(field1Key: string, field2Key: string, errorKey: string, errorDesc: string, shouldMatch: boolean = true) {
  return (group: FormGroup): { [key: string]: any } => {
    const field1 = group.controls[field1Key];
    const field2 = group.controls[field2Key];
    // console.info(`field1: ${field1.value} == field2: ${field2.value} ? ${field1.value == field2.value}`);
    const errorObj = {};
    errorObj[errorKey] = errorDesc;
    // console.log(`${field1Key}(${field1.value}) should ${shouldMatch ? '' : 'not'} match ${field2Key}(${field2.value}) ; result: ` + (field1 && field2 && (shouldMatch === (field1.value === field2.value))).toString());
    return field1 && field2 && (shouldMatch === (field1.value === field2.value)) ? null : errorObj;
  };
}
