import { Injectable } from '@angular/core';
import { Http, Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { catchError, map } from 'rxjs/operators';

import { ComponentConfigService } from '../../shared/services/component-config.service';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class RegisterService {
  private pplUrl = 'people/search';

  constructor(
    private componentConfigService: ComponentConfigService,
    private http: UWHttp,
    private nativeHttp: Http
  ) { }

  lookupBackendKey(lastName: string, last4: string, dob: string, recaptcha: string): Observable<any> {
    const params = new URLSearchParams();
    params.set('lastname', lastName);
    params.set('taxidlast4', last4);
    params.set('dob', dob);
    params.set('recaptcharesponse', recaptcha)

    return this.http.get(this.pplUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.handleError)
    );
  }

  dupCheck(userName: string, phone: string, email: string): Observable<string[]> {
    const params = new URLSearchParams();
    params.set('username', userName);
    params.set('phone', phone);
    params.set('email', email);

    return this.nativeHttp.get(`${this.componentConfigService.globals.get('identityHost')}${this.componentConfigService.globals.get('tenantCode')}/account/criticaluserattributedups`, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.handleError)
    );
  }

  private extractData(res: Response) {
    const body = res.json();
    return body.data || body.items || body || {};
  }

  private handleError(error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

}
