import { ValidatorFn, AbstractControl } from '@angular/forms';

export function regexMatchValidator(regEx: RegExp, errorKey: string, errorDesc): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    // This field requires either a mobile number OR an email address
    if (control.value) {
      let wordValue = control.value as string;
      let errorObj = {};
      errorObj[errorKey] = errorDesc;

      let iv = wordValue.match(regEx);
      if (iv) {
        // de-dup
        let ivd = [];
        for (var i = 0; i < iv.length; i++) if (!ivd.find(c => c == iv[i])) ivd.push(iv[i]);
        if (iv) errorObj[errorKey] = (errorDesc + " '" + ivd.join("', '") + "'");
      }

      return iv && iv.length > 0 ? errorObj : null;
    }
    return null;
  };
}
