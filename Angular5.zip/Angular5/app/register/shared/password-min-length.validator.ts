import { ValidatorFn, AbstractControl } from '@angular/forms';

export function passwordMinLengthValidator(minLen: number, errorDesc: string): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const pw = control.value;
    return (pw && pw.length < minLen) ? { 'passwordMinLen': errorDesc } : null;
  };
}
