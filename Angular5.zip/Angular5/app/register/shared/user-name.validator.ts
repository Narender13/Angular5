import { ValidatorFn, AbstractControl } from '@angular/forms';

// tslint:disable-next-line:only-arrow-functions
export function userNameValidator(unType: any): ValidatorFn {
  // tslint:disable-next-line:cyclomatic-complexity
  return (control: AbstractControl): { [key: string]: any } => {
    // This field requires either a mobile number OR an email address
    if (control.value) {
      const errorObj = { 'userName': null };
      const userNameValue = control.value as string;
      const cleanCellNumber = userNameValue.replace(/[^\d]/g, '');
      const notMobileNumber = !/^\d{10}$/.test(cleanCellNumber);
      // don't get too restrictive with the email regex;
      // 1. you won't believe how "odd" a valid email can look.
      // 2. we are doing email confirmation so that ensures we get a valid one,
      //    else the user won't be able to log in.
      const notEmail = !/^.+@.+\..+/.test(userNameValue);

      if (notMobileNumber && notEmail) {
        errorObj.userName = 'must be a valid mobile number or email address.';
      }
      if (!notMobileNumber && notEmail && userNameValue !== cleanCellNumber) {
        control.setValue(cleanCellNumber, { emitEvent: false });
      }
      if (notMobileNumber && !notEmail) { unType.val = 'email'; }
      if (!notMobileNumber && notEmail) { unType.val = 'phone'; }
      // making sure userName does not already exist is done in the register component

      return errorObj.userName ? errorObj : null;
    }
    return null;
  };
}
