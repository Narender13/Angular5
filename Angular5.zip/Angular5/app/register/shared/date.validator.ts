// tslint:disable:only-arrow-functions
import { ValidatorFn, AbstractControl } from '@angular/forms';

const ISO_DATE_REGEX = /^(\d{4})-(\d{2})-(\d{2})$/;
const COMMON_DATE_REGEX = /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/;

export function DateValidator(minYear: number, maxYear: number, errorKey: string, errorDesc: string): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    if (control.value == null) {
      return null;
    }

    const ts = Date.parse(control.value);
    const iso = ISO_DATE_REGEX.test(control.value);
    const common = COMMON_DATE_REGEX.test(control.value);
    const err = {};
    err[errorKey] = errorDesc;

    // date could not be parsed or was not in expected formats
    if (isNaN(ts) || !(iso || common)) {
      return err;
    } else {
      const regexp = common ? COMMON_DATE_REGEX : ISO_DATE_REGEX;
      const parts = regexp.exec(control.value);
      const inputDayOfMonth = common ? +parts[2] : +parts[3];
      // note: date.parse will coerce an invalid date into a valid one
      const parsedDate = new Date(ts);
      // note: given an iso format, date.parse will assume a time zone of utc
      const parsedDayOfMonth = common ? parsedDate.getDate() : parsedDate.getUTCDate();

      // date coerced, parsed and input day of month are different
      if (parsedDayOfMonth !== inputDayOfMonth) {
        return err;
      }
      return null;
    }
  };
}
