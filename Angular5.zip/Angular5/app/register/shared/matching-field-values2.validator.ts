import { ValidatorFn, AbstractControl } from '@angular/forms';

export function matchingFields2Validator(field2Key: string, errorKey: string, errorDesc: string): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {

    if (!control) return null;
    let field2 = control.parent.controls[field2Key];
    if (!field2) return null;
    let errorObj = {};
    errorObj[errorKey] = errorDesc;
    return control.value == field2.value ? null : errorObj;
  };
}
