import { ValidatorFn, AbstractControl } from '@angular/forms';

export function passwordMaxLengthValidator(maxLen: number, errorDesc: string): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const pw = control.value;
    return (pw && pw.length > maxLen) ? { 'passwordMaxLen': errorDesc } : null;
  };
}
