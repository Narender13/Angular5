import { ValidatorFn, AbstractControl } from '@angular/forms';

// tslint:disable-next-line:only-arrow-functions
export function mobileNumberValidator(doValidate: boolean): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    if (!doValidate || !control.value || control.value === '') { return null; }
    if (control.value) {
      const errorObj = { 'phoneNumber': null };
      const inp = control.value as string;
      const cleanCellNumber = inp.replace(/[^\d]/g, '');
      const notMobileNumber = !/^1\d{10}$|^$/.test(cleanCellNumber);

      if (notMobileNumber) {
        errorObj.phoneNumber = 'Must be a eleven digit U.S. mobile number (including country code).';
      }
      if (!notMobileNumber && inp !== cleanCellNumber) {
        control.setValue(cleanCellNumber, { emitEvent: false });
      }
      return errorObj.phoneNumber ? errorObj : null;
    }
    return null;
  };
}
