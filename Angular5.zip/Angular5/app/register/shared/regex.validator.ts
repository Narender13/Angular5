import { ValidatorFn, AbstractControl } from '@angular/forms';

export function regexValidator( regEx: RegExp,errorKey: string, errorDesc, shouldMatch: boolean = true): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    if (control.value) {
      let wordValue = control.value as string;
      let errorObj = {};
      errorObj[errorKey] = errorDesc;
      let regExResult = regEx.test(wordValue);
      return shouldMatch && regExResult ? null : errorObj;
    }
    return null;
  };
}
