export class RegisterModel {
    userType: string;
    backendKey: string;
    userName: string;
    email: string;
    phoneNumber: string;
    firstName: string;
    lastName: string;
    street: string;
    city: string;
    stateOrProvince: string;
    postalCode: string;
    password: string;
    confirmPassword: string;
    delegateCode: string;
    aliasId: string;
}
