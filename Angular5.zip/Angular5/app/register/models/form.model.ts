


export class Address {
    street = '';
    city = '';
    stateOrProvince = '';
    postalCode = '';
}