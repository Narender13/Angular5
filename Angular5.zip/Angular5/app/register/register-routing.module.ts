import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent } from './register.component';
import { RegisterDelegateComponent } from './register-delegate.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const loginRoutes: Routes = [
    { path: 'register', component: RegisterComponent, canActivate: [AuthGuardService] },
    { path: 'register-delegate/:id/:email', component: RegisterDelegateComponent}
];

@NgModule({
    imports: [RouterModule.forChild(loginRoutes)],
    exports: [RouterModule]
})
export class RegisterRoutingModule { }
