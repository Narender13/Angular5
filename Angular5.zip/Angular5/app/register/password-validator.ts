

export class PasswordValidator {
  minLength: { value: number, description: string };
  maxLength: { value: number, description: string };
  hasUpperCase: { 'regEx': RegExp, 'description': string };
  hasLowerCase: { 'regEx': RegExp, 'description': string };
  hasNumber: { 'regEx': RegExp, 'description': string };
  hasNonAlpha: { 'regEx': RegExp, 'description': string };
  invalidChars: { 'regEx': RegExp, 'description': string };
  description: string;

  constructor() {
    let minLen = 8;
    let maxLen = 16;

    this.minLength = {
      value: minLen,
      description: 'Must be at least ' + minLen + ' characters in length.'
    };
    this.maxLength = {
      value: maxLen,
      description: 'Must be less than ' + (maxLen + 1) + ' characters in length.'
    };
    this.hasUpperCase = {
      regEx: /[A-Z]/,
      description: 'Must contain at least one upper case letter.'
    };
    this.hasLowerCase = {
      regEx: /[a-z]/,
      description: 'Must contain at least one lower case letter.'
    };
    this.hasNumber = {
      regEx: /\d/,
      description: 'Must contain at least one number.'
    };
    let naRegEx = '!@#$%^&*()_';
    this.hasNonAlpha = {
      regEx: new RegExp('[' + naRegEx + ']'),
      description: 'Must contain at least one character from the group ' +
      naRegEx.toString()
    };
    this.invalidChars = {
      regEx: /[^A-Za-z\d!@#$%^&*()_]/g,
      description: 'Cannot contain invalid character'
    };
    this.description = this.minLength.description + ' ' +
      this.maxLength.description + ' ' +
      this.hasUpperCase.description + ' ' +
      this.hasLowerCase.description + ' ' +
      this.hasNumber.description + ' ' +
      this.hasNonAlpha.description + ' ';
  }

  validate(pw: string): string[] {
    let errorDesc = [];
    if (pw.length < this.minLength.value)
      errorDesc.push(this.minLength.description);
    if (pw.length > this.maxLength.value)
      errorDesc.push(this.maxLength.description);
    if (!this.hasUpperCase.regEx.test(pw))
      errorDesc.push(this.hasUpperCase.description);
    if (!this.hasLowerCase.regEx.test(pw))
      errorDesc.push(this.hasLowerCase.description);
    if (!this.hasNumber.regEx.test(pw))
      errorDesc.push(this.hasNumber.description);
    if (!this.hasNonAlpha.regEx.test(pw))
      errorDesc.push(this.hasNonAlpha.description);
    let iv = pw.match(this.invalidChars.regEx);
    if (iv) {
      // de-dup
      let ivd = [];
      for (var i = 0; i < iv.length; i++) if (!ivd.find(c => c == iv[i])) ivd.push(iv[i]);
      if (iv) errorDesc.push(this.invalidChars.description + " '" + ivd.join("', '") + "'");
    }
    return errorDesc;
  }
}