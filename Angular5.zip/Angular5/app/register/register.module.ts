import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

// import { UserLookupService } from './shared/user-lookup.service';
import { RegisterService } from './shared/register.service';
import { RegisterRoutingModule } from './register-routing.module';
import { RegisterComponent } from './register.component';
import { SharedModule } from '../shared/shared.module';
import { RecaptchaModule } from 'ng-recaptcha';
import { RegisterDelegateComponent } from './register-delegate.component';

@NgModule({
  declarations: [RegisterComponent, RegisterDelegateComponent],
  imports: [CommonModule, SharedModule, ReactiveFormsModule, RegisterRoutingModule, RecaptchaModule.forRoot()],
  exports: [RegisterComponent],
  providers: [RegisterService]
})
export class RegisterModule { }
