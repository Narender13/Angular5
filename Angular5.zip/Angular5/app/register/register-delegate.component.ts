import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router/';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from './shared/register.service';
import { UserService } from '../shared/services/user.service';
import { regexValidator } from './shared/regex.validator';
import { PasswordValidator } from './password-validator';
import { regexMatchValidator } from './shared/regex-match.validator';
import { matchingFieldsValidator } from './shared/matching-field-values.validator';
import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../shared/decorators/configurable';
import { ComponentConfigService } from '../shared/services/component-config.service';

@Component({
  selector: 'app-register-delegate',
  templateUrl: './register-delegate.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('RegisterDelegateComponent')
export class RegisterDelegateComponent implements Configurable, OnInit {
  config: any;
  aliasId: string;
  registerDelegateForm: FormGroup;
  currentHost: string;
  tenantCode: string;
  identityHost: string;
  busy = false;
  email: string;
  usable: boolean;
  private passwordValidator = new PasswordValidator();

  constructor(
    private componentConfigService: ComponentConfigService,
    private fb: FormBuilder,
    private registerService: RegisterService,
    private route: ActivatedRoute,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.identityHost = this.componentConfigService.globals.get('identityHost');
    this.tenantCode = this.componentConfigService.globals.get('tenantCode');
    this.currentHost = this.componentConfigService.globals.get('hostName');
    const routeParams = this.route.snapshot.params as { id: string, email: string };
    this.aliasId = routeParams.id;
    this.email = routeParams.email;
    this.createForm();
  }

  createForm() {
    this.registerDelegateForm = this.fb.group({
      userType: ['delegatee', Validators.required],
      phoneNumberConfirm: ['',
        [
          // Validators.required,
          Validators.minLength(6)
        ]
      ],
      user: this.fb.group({
        userName: [this.email,
        [
          Validators.required,
          regexValidator(/(^.+@.+\..+$)|^$/, 'userName', 'Must be a valid email address.')
        ]
        ],
        email: [this.email,
        [
          // regexValidator(/(^.+@.+\..+$)|^$/, 'email', 'Must be a valid email address.')
        ]
        ],
        aliasId: this.aliasId,
        firstName: ['',
          [
            Validators.required,
            Validators.minLength(2)
          ]
        ],
        lastName: ['',
          [
            Validators.required,
            Validators.minLength(2)
          ]
        ],
        backendKey: 'delegate',
        delegateCode: ['',
          [
            Validators.required,
            Validators.minLength(5),
            Validators.maxLength(5)
          ]
        ]
      }),
      pw: this.fb.group({
        password: ['',
          [
            Validators.required,
            Validators.minLength(this.passwordValidator.minLength.value),
            Validators.maxLength(this.passwordValidator.maxLength.value),
            regexValidator(this.passwordValidator.hasLowerCase.regEx,
              'passwordHasLowerCase', this.passwordValidator.hasLowerCase.description),
            regexValidator(this.passwordValidator.hasUpperCase.regEx,
              'passwordHasUpperCase', this.passwordValidator.hasUpperCase.description),
            regexValidator(this.passwordValidator.hasNumber.regEx,
              'passwordHasNumber', this.passwordValidator.hasNumber.description),
            regexValidator(this.passwordValidator.hasNonAlpha.regEx,
              'passwordHasNonAlpha', this.passwordValidator.hasNonAlpha.description),
            regexMatchValidator(this.passwordValidator.invalidChars.regEx,
              'passwordInvalidChars', this.passwordValidator.invalidChars.description)
          ]
        ],
        confirmPassword: ['',
          [
            Validators.required
          ]
        ],
      }, {
          validator: matchingFieldsValidator('password', 'confirmPassword', 'passwordsMatch',
            'Password and Confirm Password must match.')
        })
    });
  }
}
