import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductFormRoutingModule } from './product-form-routing.module';
import { ProductFormGridComponent } from './product-form-grid.component';
import { SharedModule } from '../shared/shared.module';
import { ProductFormService } from './shared/product-form.service';

@NgModule({
  imports: [
    CommonModule,
    ProductFormRoutingModule,
    SharedModule
  ],
  declarations: [ProductFormGridComponent],
  providers: [ProductFormService]
})
export class ProductFormModule { }
