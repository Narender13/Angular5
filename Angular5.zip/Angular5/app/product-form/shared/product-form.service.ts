import { Injectable } from '@angular/core';
import { Response, ResponseContentType, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { LoggingService } from '../../shared/logging/logging.service';
import { Paginated } from '../../shared/models/paginated.interface';
import { ProductForm } from '../../shared/models/product-form.model';
import { UWHttp } from '../../UWHttp';

@Injectable()
export class ProductFormService {

  private apiUrl = 'Forms/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }
  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(category: string, limit: number, offset: number): Observable<ProductForm[]> {
    const params = new URLSearchParams();
    params.set('category', category);
    if (offset) {
      params.set('skip', offset.toString());
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError));
  }

  download(form: ProductForm): Observable<boolean> {
    const options = {
      responseType: ResponseContentType.Blob
    };
    return this.http.authDownload(`${this.apiUrl}${form.id}/download`, form.title, options).pipe(
      catchError(this.loggingService.handleError));
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<ProductForm>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }
}
