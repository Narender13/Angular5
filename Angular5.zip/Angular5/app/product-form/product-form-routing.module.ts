import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProductFormGridComponent } from './product-form-grid.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const routes: Routes = [
  { path: 'forms', component: ProductFormGridComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductFormRoutingModule { }
