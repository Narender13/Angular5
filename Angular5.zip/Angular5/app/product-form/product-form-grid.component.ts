import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

import { share, switchMap, tap } from 'rxjs/operators';

import { ProductFormService } from './shared/product-form.service';
import { ProductForm } from '../shared/models/product-form.model';
import { Configure, Configurable } from '../shared/decorators/configurable';
import { AutoUnsubscribe } from '../shared/decorators/autounsubscribe';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form-grid.component.html',
  styles: []
})
@AutoUnsubscribe()
@Configure('ProductFormGridComponent')
export class ProductFormGridComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  downloading: boolean;
  formCategories: any[];
  onChangeEvent: boolean;
  onChangeOffset: number; // need this to set offset to 0 when changing category
  productForm: Observable<ProductForm[]>;
  sortFields: string[] = ['title', 'category'];
  usable: boolean;
  loading = true;

  constructor(
    private service: ProductFormService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    // temp solution to get client specific form categories
    // to do: either get form categories from forms api or run distinct on categories in dataApi and make a new webapi call for the same
    this.formCategories = this.config.formCategories;
    this.productForm = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: { limit: number, offset: number }) => {
        this.config.limit = params.limit || this.config.limit;
        this.config.offset = params.offset || 0;
        return this.service.list('Service Form', params.limit || this.config.limit, params.offset);
      }),
      tap(() => this.loading = false)
    );
    this.count = this.service.count().pipe(share());
  }

  onChange(event, formCategory) {
    this.onChangeEvent = true;
    this.onChangeOffset = 0;
    this.getForms(formCategory);
  }

  getForms(formCategory: string) {
    this.productForm = this.route.params
      .switchMap((params: { limit: number, offset: number }) => {
        // if block is to get the new list of forms with offset set to 0
        if (this.onChangeEvent === true) {
          this.onChangeEvent = false;
          this.config.offset = this.onChangeOffset;
          this.config.limit = params.limit || this.config.limit;
          // this was the only way I could set url offset parameter back to 0 when switching between form categories
          this.router.navigate(['/forms'], { queryParams: { offset: 0 } });
          return this.service.list(formCategory, params.limit || this.config.limit, this.onChangeOffset);
        } else {
          this.config.limit = params.limit || this.config.limit;
          this.config.offset = params.offset || 0;
          return this.service.list(formCategory, params.limit || this.config.limit, params.offset);
        }
      });

  }
  download(form) {
    if (form.external) {
      this.downloadExt(form);
    } else {
      this.downloading = true;
      this.service.download(form).subscribe(() => this.downloading = false);
    }
  }

  downloadExt(form) {
    const a = document.createElement('a');
    a.hidden = true;
    a.href = form.fileName;
    a.download = form.title;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

}
