import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

import { CallEntryGridComponent } from './call-entry-grid/call-entry-grid.component';

const callEntryRoutes: Routes = [
    {path: 'callEntries/:id', component: CallEntryGridComponent}
];

@NgModule({
    imports: [RouterTestingModule.withRoutes(callEntryRoutes)],
    exports: [RouterTestingModule]
})
export class CallEntryRoutingTestModule { }