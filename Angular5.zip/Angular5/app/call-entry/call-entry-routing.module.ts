import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CallEntryGridComponent } from './call-entry-grid/call-entry-grid.component';
import { AuthGuardService } from '../shared/services/auth-guard.service';

const callEntryRoutes: Routes = [
  { path: 'contracts/:contractId/call-entries', component: CallEntryGridComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(callEntryRoutes)],
  exports: [RouterModule]
})
export class CallEntryRoutingModule { }
