import { Component, OnInit, Input } from '@angular/core';
import { CallEntry } from '../../shared/models/call-entry.model';

@Component({
  selector: 'app-call-entry-chip',
  templateUrl: './call-entry-chip.component.html',
  styles: [':host{width:100%;}']
})
export class CallEntryChipComponent implements OnInit {
  @Input() callEntry: CallEntry;

  constructor() { }

  ngOnInit() {
  }

}
