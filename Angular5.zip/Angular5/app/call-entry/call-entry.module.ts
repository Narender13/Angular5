import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import { CallEntryService } from './shared/call-entry.service';
import { CallEntryCardComponent } from './call-entry-card/call-entry-card.component';
import { CallEntryChipComponent } from './call-entry-chip/call-entry-chip.component';
import { CallEntryListComponent } from './call-entry-list/call-entry-list.component';
import { CallEntryGridComponent } from './call-entry-grid/call-entry-grid.component';

import { SharedModule } from '../shared/shared.module';
import { CallEntryRoutingModule } from './call-entry-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    CallEntryCardComponent,
    CallEntryChipComponent,
    CallEntryListComponent,
    CallEntryGridComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    CallEntryRoutingModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [
    CallEntryCardComponent,
    CallEntryChipComponent
  ],
  providers: [CallEntryService]
})
export class CallEntryModule { }
