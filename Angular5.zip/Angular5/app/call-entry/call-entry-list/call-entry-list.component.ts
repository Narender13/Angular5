import { Component, Input } from '@angular/core';

import { CallEntry } from '../../shared/models/call-entry.model';

@Component({
  selector: 'app-call-entry-list',
  templateUrl: './call-entry-list.component.html',
  styleUrls: ['./call-entry-list.component.scss']
})
export class CallEntryListComponent {
  @Input() callEntries: CallEntry[];

  constructor() { }
}
