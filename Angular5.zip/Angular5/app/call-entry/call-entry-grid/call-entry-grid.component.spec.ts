/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { CallEntryGridComponent } from './call-entry-grid.component';
import { SharedModule } from '../../shared/shared.module';
import { CallEntryRoutingTestModule } from '../call-entry-routing-test.module';
import { HttpModule } from '@angular/http';
import { CallEntryDetailComponent } from '../call-entry-detail/call-entry-detail.component';
import { CallEntryCardComponent } from '../call-entry-card/call-entry-card.component';
import { CallEntryService } from '../shared/call-entry.service';

describe('CallEntryGridComponent', () => {
  let component: CallEntryGridComponent;
  let fixture: ComponentFixture<CallEntryGridComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SharedModule,
        CallEntryRoutingTestModule,
        HttpModule
      ],
      declarations: [
        CallEntryGridComponent,
        CallEntryDetailComponent,
        CallEntryCardComponent
      ],
      providers: [{ provide: CallEntryService }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallEntryGridComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('h1'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
