import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share, switchMap, tap } from 'rxjs/operators';

import { CallEntry } from '../../shared/models/call-entry.model';
import { CallEntryService } from '../shared/call-entry.service';
import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configure, Configurable } from '../../shared/decorators/configurable';
import { PageParams } from '../../shared/models/paginated.interface';

@Component({
  selector: 'app-call-entry-grid',
  templateUrl: './call-entry-grid.component.html',
  styleUrls: ['./call-entry-grid.component.scss']
})
@AutoUnsubscribe()
@Configure('CallEntryGridComponent')
export class CallEntryGridComponent implements Configurable, OnInit {
  config: any;
  callEntries: Observable<CallEntry[]>;
  sortFields: string[] = ['createdDate', 'callType'];
  count: Observable<number>;
  loading = true;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: CallEntryService
  ) { }

  ngOnInit() {
    this.callEntries = this.route.params.pipe(
      tap(() => this.loading = true),
      switchMap((params: PageParams) => {
        const { q, limit = this.config.limit, offset = 0 } = params;
        this.config.limit = limit;
        this.config.offset = offset;
        return this.service.list(q, this.config.limit, this.config.offset);
      }),
      tap(() => this.loading = false),
      share()
    );

    this.service.count().pipe(share());
  }
}
