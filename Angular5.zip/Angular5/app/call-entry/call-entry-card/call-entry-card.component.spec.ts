/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';

import { CallEntryCardComponent } from './call-entry-card.component';
import { CallEntryDetailComponent } from '../call-entry-detail/call-entry-detail.component';
import { CallEntryGridComponent } from '../call-entry-grid/call-entry-grid.component';
import { CallEntryRoutingTestModule } from '../call-entry-routing-test.module';
import { CallEntryService } from '../shared/call-entry.service';
import { SharedModule } from '../../shared/shared.module';

describe('CallEntryCardComponent', () => {
  let component: CallEntryCardComponent;
  let fixture: ComponentFixture<CallEntryCardComponent>;
  let de: DebugElement;
  let el: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        SharedModule,
        CallEntryRoutingTestModule,
        HttpModule],
      declarations: [
        CallEntryCardComponent,
        CallEntryDetailComponent,
        CallEntryGridComponent
       ],
       providers: [CallEntryService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallEntryCardComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('.card-title'));
    el = de.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
