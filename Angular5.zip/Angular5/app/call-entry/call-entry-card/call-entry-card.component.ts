import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { share } from 'rxjs/operators';

import { AutoUnsubscribe } from '../../shared/decorators/autounsubscribe';
import { Configurable, Configure } from '../../shared/decorators/configurable';
import { CallEntry } from '../../shared/models/call-entry.model';
import { CallEntryService } from '../shared/call-entry.service';

@Component({
  selector: 'app-call-entry-card',
  templateUrl: './call-entry-card.component.html',
  styleUrls: ['./call-entry-card.component.scss']
})
@AutoUnsubscribe()
@Configure('CallEntryCardComponent')
export class CallEntryCardComponent implements Configurable, OnInit {
  config: any;
  count: Observable<number>;
  callEntries: Observable<CallEntry[]>;
  limit = 5;
  usable: boolean;

  constructor(
    private route: ActivatedRoute,
    private service: CallEntryService
  ) { }

  ngOnInit() {
    const routeParams = this.route.snapshot.params as { id: string };
    const contractId = routeParams.id;
    this.limit = this.config.cardLimit || this.limit;
    this.callEntries = this.service.list(contractId, this.limit, 0).pipe(share());
    this.count = this.service.count().pipe(share());
  }
}
