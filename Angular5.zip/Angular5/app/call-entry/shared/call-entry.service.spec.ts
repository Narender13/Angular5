
import { TestBed, inject } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { CallEntryService } from './call-entry.service';

describe('CallEntryService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [CallEntryService]
        });
    });

    it('should ...', inject([CallEntryService], (service: CallEntryService) => {
        expect(service).toBeTruthy();
    }));
});