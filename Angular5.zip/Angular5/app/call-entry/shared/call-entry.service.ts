import { Injectable } from '@angular/core';
import { Response, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { catchError, map } from 'rxjs/operators';

import { UWHttp } from '../../UWHttp';
import { LoggingService } from '../../shared/logging/logging.service';
import { CallEntry } from '../../shared/models/call-entry.model';
import { Paginated } from '../../shared/models/paginated.interface';

@Injectable()
export class CallEntryService {
  private apiUrl = 'callEntries/';
  private lastCount = new Subject<number>();

  constructor(private http: UWHttp, private loggingService: LoggingService) { }

  count(): Observable<number> {
    return this.lastCount.asObservable();
  }

  list(search: string, limit: number, offset: number): Observable<CallEntry[]> {
    const params = new URLSearchParams();

    if (search) {
      params.set('contractId', search);
    }

    if (offset) {
      params.set('skip', offset.toString());
    }

    if (limit) {
      params.set('take', limit.toString());
    }

    return this.http.authGet(this.apiUrl, { search: params }).pipe(
      map(this.extractData, this),
      catchError(this.loggingService.handleError)
    );
  }

  private extractData(res: Response) {
    const body = res.json() as Paginated<CallEntry>;
    this.lastCount.next(body.totalCount);
    return body.items || [];
  }
}
